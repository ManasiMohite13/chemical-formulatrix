import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, OnInit, TemplateRef } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { map, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs/internal/Observable';
import { RolePriority } from 'src/assets/config/authorizations';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { AuthService } from '../shared/services/auth.service';
import { SessionService } from '../shared/services/session.service';
import { ToasterService } from '../shared/services/toaster.service';
import { ConfirmDailogComponent } from './common/confirm-dailog/confirm-dailog.component';
import { UserService } from '../shared/services/user.service';
import { HttpService } from '../shared/services/http.service';
import { UserTypes } from 'src/assets/config/global-enums';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss'],
})
export class PagesComponent implements OnInit {
  supportForm!: FormGroup;
  userId: any;
  settingsData: any;
  isAdmin: boolean = false;
  role: any;
  title: string = '';
  passwordForm!: FormGroup;
  showNotification: boolean = false;
  notificationCount: number = 0;
  notificationList: any;
  hide: boolean = true;
  isnotificationdisabled: boolean = false;
  userType: any;
  userTypes = UserTypes;
  supports: boolean = false;

  priorityList: any = [
    { id: 1, priority: 'High' },
    { id: 2, priority: 'Medium' },
    { id: 3, priority: 'Low' },

  ];

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private breakpointObserver: BreakpointObserver,
    private authService: AuthService,
    private dialog: MatDialog,
    private sessionService: SessionService,
    private toasterService: ToasterService,
    private userService: UserService,
    private httpService: HttpService,
  ) {
    this.createForm();
    this.userType = Number(this.httpService.getDecryptedValue('userType'));
    this.role = Boolean(localStorage.getItem('roleId'));
    if (this.role != null && this.role == RolePriority.SuperAdmin) {
      this.isAdmin = true;
    } else {
      this.isAdmin = false;
    }
    this.userId = Number(this.httpService.getDecryptedValue('userId'));
    if (this.userType == 3 || this.userType == 4 || this.userType == 5) {
      this.supports = true;
    }
  }
  isHandset$: Observable<boolean> = this.breakpointObserver
    .observe(Breakpoints.Handset)
    .pipe(
      map((result) => result.matches),
      shareReplay()
    );
  ngOnInit(): void { }

  createForm() {
    this.supportForm = this.fb.group({
      title: new FormControl('', [Validators.required, Validators.pattern(ConstantsMessage.ONLY_LETTERS_WITH_SPACE)]),
      description: new FormControl('', [Validators.required, Validators.pattern(ConstantsMessage.ONLY_LETTERS_WITH_SPACE)]),
      priority: new FormControl('', [Validators.required]),
      assignedTo: new FormControl(),
      assignedBy: new FormControl(),

    })
  }
  submitSupportForm() {
    let obj = {
      title: this.supportForm.value.title,
      description: this.supportForm.value.description,
      priority: this.supportForm.value.priority,
      assignedTo: this.supportForm.value.assignedTo,
      assignedBy: this.supportForm.value.assignedBy
    }
    this.userService.craeteUserSupport(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.SUPPORT_CREATE, '');
      }
      else {
        this.toasterService.showError(res.errors, '');
      }
    })
  }

  manageHospital() {
    this.authService.encryptKey('isManageProfile', 0);
    this.router.navigate(['pages/admin/hospital/edit-hospital']);
  }

  manageForms() {
    this.router.navigate(['pages/admin/manage-forms']);
  }

  onConfirm() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      width: '420px',
      data: {
        title: ConstantsMessage.CONFIRM_POPUP_TITLE_LOGOUT,
        message: ConstantsMessage.CONFIRM_MESSAGE_LOGOUT,
      },
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.onLogout();
      }
    });
  }
  // support(templateRef: TemplateRef<any>){
  //   this.dialog.open(templateRef, {
  //     width: "550px",
  //     disableClose: true

  //   })
  //   this.supportForm.reset();
  // }
  support() {
    this.supportForm.reset();
    if (this.userType == 3) {
      this.router.navigate(['/pages/admin/add-support'])
    }
    else if (this.userType == 4) {
      this.router.navigate(['/pages/admin/add-patient-support'])
    }
    else {
      this.router.navigate(['/pages/admin/add-receptionist-support']);


    }

  }
  onLogout() {
    localStorage.clear();
    this.authService.logout();
    this.router.navigate(['/']);
  }
  getProfile() {
    this.router.navigate(['/pages/profile/']);
  }

  setHeader() {
    let path = this.router.url.split('/')[2];
    switch (
    decodeURIComponent(path)
    // case PageTitle.dashboard: {
    //   this.title = 'Dashboard';
    //   break;
    // }
    // case PageTitle.user: {
    //   this.title = 'Manage User';
    //   break;
    // }
    // case PageTitle.subscription: {
    //   this.title = 'Subscription Plan';
    //   break;
    // }
    // case PageTitle.supplier: {
    //   this.title = 'Supplier List';
    //   break;
    // }

    // case PageTitle.customer: {
    //   this.title = 'Customer List';
    //   break;
    // }
    // case PageTitle.tickets: {
    //   this.title = 'Support Ticket List';
    //   break;
    // }
    // case PageTitle.terms: {
    //   this.title = 'Terms & Conditions';
    //   break;
    // }
    // case PageTitle.profile: {
    //   this.title = 'Profile';
    //   break;
    // }
    // case PageTitle.rental: {
    //   this.title = 'Rental Management';
    //   break;
    // }
    // case PageTitle.linkbusiness: {
    //   this.title = 'Manage Linked Business';
    //   break;
    // }
    ) {
    }
  }
}
