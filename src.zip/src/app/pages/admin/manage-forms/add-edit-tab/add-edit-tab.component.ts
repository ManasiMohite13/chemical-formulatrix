import { Component, ViewChild, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ManageFormsComponent } from '../manage-forms.component';
import { TabServiceService } from 'src/app/shared/services/tab-service.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';

@Component({
  selector: 'app-add-edit-tab',
  templateUrl: './add-edit-tab.component.html',
  styleUrls: ['./add-edit-tab.component.scss']
})
export class AddEditTabComponent {
  tabForm: FormGroup;
  public dataSource = new MatTableDataSource(tabList);
  displayedColumns: string[] = ['tabName', 'description', 'Action',];
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  tabList: any = [];
  isEditing: boolean = false;
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private dialogRef: MatDialogRef<ManageFormsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private tabService: TabServiceService,
    private dialog: MatDialog
  ) {
    this.createForm();
    this.getTabMasterList();
  }

  createForm() {
    this.tabForm = this.fb.group({
      id: new FormControl(0),
      tabName: new FormControl('', [Validators.required, Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      defaultTab: new FormControl(false),
      description: new FormControl(''),
    });
  }

  getTabMasterList() {
    this.tabService.getTabMasterList().subscribe((res: any) => {
      if (res.success) {
        tabList = res.result;
        this.tabList = tabList;
        this.dataSource = new MatTableDataSource(this.tabList);
      }
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  resetTabForm() {
    this.tabForm.reset();
    this.getTabMasterList();
  }

  close() {
    this.dialogRef.close();
  }

  submitForm() {
    this.isEditing = false;
    var check = this.tabList.filter(a => a.tabName == this.tabForm.value.tabName);
    if (check.length > 0 && this.tabForm.value.id == 0) {
      this.toasterService.showError("This Tab Name is already added", '');
      return;
    }

    var obj = {
      id: this.tabForm.value.id == null ? 0 : this.tabForm.value.id,
      tabName: this.tabForm.value.tabName,
      description: this.tabForm.value.description,
      defaultTab: this.tabForm.value.defaultTab == null ? false : this.tabForm.value.defaultTab,
    }
    this.tabService.saveTab(obj).subscribe((res: any) => {
      if (res.success) {
        if (!obj.id) {
          this.toasterService.showSuccess(ConstantsMessage.CREATE_TAB, '');
        }
        else {
          this.toasterService.showSuccess(ConstantsMessage.UPDATE_TAB, '');
        }
        this.resetTabForm();
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }

  editTab(data) {
    this.isEditing = true;
    this.tabForm.patchValue(data);
  }

  deleteTab(data) {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.DELETE_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.DELETE_CONFIRMATION_Tab_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.tabService.deleteTab({ id: data.id }).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(ConstantsMessage.DELETE_TAB, '');
            this.resetTabForm();
          }
        });

      }
    });
  }
}

export interface displayedColumns {
  tabName: string;
  description: string;
}
let tabList: displayedColumns[];