import { Component, ViewChild, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ManageFormsComponent } from '../manage-forms.component';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { TabServiceService } from 'src/app/shared/services/tab-service.service';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import { MatChipEditedEvent, MatChipInputEvent } from '@angular/material/chips';

@Component({
  selector: 'app-add-edit-formfield',
  templateUrl: './add-edit-formfield.component.html',
  styleUrls: ['./add-edit-formfield.component.scss'],
})

export class AddEditFormfieldComponent {
  addOnBlur = true;
  readonly separatorKeysCodes = [ENTER, COMMA] as const;
  optionList: any = [];
  announcer = inject(LiveAnnouncer);
  showOptions: boolean = false;
  formFieldForm: FormGroup;
  public dataSource = new MatTableDataSource(formFieldData);
  displayedColumns: string[] = ['formFieldName', 'formFieldType', 'Action',];
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  formFieldList: any = [];
  groupTypeList = [];
  isEditing: boolean = false;
  snackBar: any;
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private dialogRef: MatDialogRef<ManageFormsComponent>,
    private dialog: MatDialog,
    private tabService: TabServiceService
  ) {
    this.createForm();
    this.getFormFieldTypeList();
    this.getFormFieldList();
  }

  createForm() {
    this.formFieldForm = this.fb.group({
      id: new FormControl(0),
      formFieldName: new FormControl('', [Validators.required]),
      formFieldType: new FormControl(null, [Validators.required]),
      formFieldDefaultValue: new FormControl(''),
      description: new FormControl(''),
      fieldHelpText: new FormControl(''),
      formFieldValue: new FormControl('')
    });
  }

  getFormFieldList() {
    this.tabService.getFormFieldList().subscribe((res: any) => {
      if (res.success) {
        formFieldData = res.result;
        this.formFieldList = formFieldData;
        this.dataSource = new MatTableDataSource(this.formFieldList);
      }
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  getFormFieldTypeList() {
    this.tabService.getFormFieldTypeList().subscribe((res: any) => {
      if (res.success) {
        this.groupTypeList = res.result;
      }
    });
  }

  resetformFieldForm() {
    this.showOptions = false;
    this.optionList = [];
    this.formFieldForm.reset();
    this.getFormFieldList();
  }

  close() {
    this.dialogRef.close();
  }
  

  submitForm() {
    this.isEditing = false;

    var check = this.formFieldList.filter(a => a.formFieldName == this.formFieldForm.value.formFieldName);
    if (check.length > 0 && !this.formFieldForm.value.id) {
      this.toasterService.showError("This Form Field is already added", '');
      return;
    }
      
    if (this.optionList.length === 0 && (this.formFieldForm.value.formFieldType === 'dropdown' || this.formFieldForm.value.formFieldType === 'radio' || this.formFieldForm.value.formFieldType === 'checkbox')) {
      this.toasterService.showError('Options are required !.', '');
      return;
    }

    if (this.optionList.length < 0 && (this.formFieldForm.value.formFieldType == 'dropdown' || this.formFieldForm.value.formFieldType == 'radio' || this.formFieldForm.value.formFieldType == 'checkbox')) {
      this.toasterService.showError("Option can not be empty!", '');
      return;
    }

    var obj = {
      id: this.formFieldForm.value.id == null ? 0 : this.formFieldForm.value.id,
      formFieldName: this.formFieldForm.value.formFieldName,
      formFieldType: this.formFieldForm.value.formFieldType,
      description: this.formFieldForm.value.description,
      formFieldDefaultValue: this.formFieldForm.value.formFieldDefaultValue,
      fieldHelpText: this.formFieldForm.value.fieldHelpText,
      formFieldValue: this.optionList.toString()
    }
    this.tabService.saveFormField(obj).subscribe((res: any) => {
      if (res.success) {
        if (!obj.id) {
          this.toasterService.showSuccess(ConstantsMessage.CREATE_FORMFIELD, '');
        }
        else {
          this.toasterService.showSuccess(ConstantsMessage.UPDATE_FORMFIELD, '');
        }
        this.resetformFieldForm();
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }

  onChangeType() {
    if (this.formFieldForm.value.formFieldType == 'dropdown' || this.formFieldForm.value.formFieldType == 'radio' || this.formFieldForm.value.formFieldType == 'checkbox') {
      //this.formFieldForm.get('formFieldValue').setValidators([Validators.required]);
      this.showOptions = true;
    } else {
      this.formFieldForm.get('formFieldValue').clearValidators();
      this.showOptions = false;
    }
    this.optionList = [];
    this.formFieldForm.patchValue({ formFieldValue: '' });
    this.formFieldForm.get('formFieldValue').updateValueAndValidity();

    
  }


  editFormField(data) {
    this.isEditing = true;
    this.formFieldForm.patchValue(data);
    this.onChangeType();
    if (this.formFieldForm.value.formFieldType == 'dropdown' || this.formFieldForm.value.formFieldType == 'radio' || this.formFieldForm.value.formFieldType == 'checkbox') {
      this.formFieldForm.patchValue({
        formFieldValue: data.formFieldValue
      });
      this.optionList = data.formFieldValue.split(',');
    }

  }

  deleteFormField(data) {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.DELETE_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.DELETE_CONFIRMATION_FORMFIELD_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.tabService.deleteFormField({ id: data.id }).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(ConstantsMessage.DELETE_FORMFIELD, '');
            this.resetformFieldForm();
          }
        });
      }
    });
  }

  addOption(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();
    if (value) {
      this.optionList.push(value);
    }
    event.chipInput!.clear();
  }

  removeOption(option: any): void {
    const index = this.optionList.indexOf(option);

    if (index >= 0) {
      this.optionList.splice(index, 1);
      this.announcer.announce(`Removed ${option}`);
    }
  }

  editOption(option: any, event: MatChipEditedEvent) {
    const value = event.value.trim();
    if (!value) {
      this.removeOption(option);
      return;
    }

    const index = this.optionList.indexOf(option);
    if (index >= 0) {
      this.optionList[index] = value;
    }
  }
}

export interface displayedColumns {
  formFieldName: string;
  formFieldType: string;
}
let formFieldData: displayedColumns[];