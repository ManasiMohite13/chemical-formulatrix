import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditFormfieldComponent } from './add-edit-formfield.component';

describe('AddEditFormfieldComponent', () => {
  let component: AddEditFormfieldComponent;
  let fixture: ComponentFixture<AddEditFormfieldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditFormfieldComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditFormfieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
