import { Component, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ManageFormsComponent } from '../manage-forms.component';
import { TabServiceService } from 'src/app/shared/services/tab-service.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-manage-tab',
  templateUrl: './manage-tab.component.html',
  styleUrls: ['./manage-tab.component.scss']
})
export class ManageTabComponent {
  tabForm: FormGroup;
  specialityName: string;
  tabList: any = [];
  copyTabList: any = [];
  specialityTabList: any = [];
  specialityId: any;
  tenantId: any;
  nextDisplayOrder: number;
  isEditing: boolean = false;
  displayedColumns: string[] = ['tabName', 'displayName', 'Action',];
  public dataSource = new MatTableDataSource(specialityTabList);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();

  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private dialogRef: MatDialogRef<ManageFormsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private tabService: TabServiceService,
    private dialog: MatDialog,
  ) {

    this.specialityId = data.specialityId;
    this.tenantId = data.tenantId;
    this.specialityName = data.specialityName;

    this.createForm();
    this.getTabMasterList();
    this.getTabListBySpecilityId();
  }

  createForm() {
    this.tabForm = this.fb.group({
      id: new FormControl(0),
      tabId: new FormControl('', [Validators.required]),
      displayOrder: new FormControl(this.nextDisplayOrder, [Validators.required]),
      displayName: new FormControl(''),
    });
  }

  getTabMasterList() {
    this.tabService.getTabMasterList().subscribe((res: any) => {
      if (res.success) {
        this.tabList = res.result;
        this.copyTabList = res.result;
      }
    });
  }

  getTabListBySpecilityId() {
    let obj = {
      id: this.specialityId,
      tenantId: this.tenantId
    }
    this.tabService.getTabListBySpecilityId(obj).subscribe((res: any) => {
      if (res.success) {
        this.specialityTabList = res.result;
        this.nextDisplayOrder = this.specialityTabList.length + 1;
        this.tabForm.patchValue({ displayOrder: this.nextDisplayOrder })
        this.dataSource = new MatTableDataSource(this.specialityTabList);
        // this.tabList = this.tabList.sort((a, b) => a.displayOrder - b.displayOrder); 
      }
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  resetTabForm() {
    this.tabForm.reset();
    this.tabForm.controls['tabId'].enable();
    this.getTabListBySpecilityId();
  }

  close() {
    this.dialogRef.close();
  }

  submitForm() {
    this.isEditing = false;
    let id = this.tabForm.value.id == null ? 0 : this.tabForm.value.id
    let check = this.specialityTabList.filter(a => a.tabId == this.tabForm.get('tabId').value);
    if (check.length > 0 && id == 0) {
      this.toasterService.showError("This Tab Name is already added", '');
      return;
    }

    let tabName = this.tabForm.value.displayName;
    if (!this.tabForm.value.displayName) {
      let getTab = this.tabList.filter(a => a.id == this.tabForm.get('tabId').value);
      if (getTab.length > 0) {
        tabName = getTab[0].tabName
      }
    }

    var obj = {
      id: id,
      tabId: this.tabForm.get('tabId').value,
      displayOrder: this.tabForm.value.displayOrder,
      displayName: tabName,
      specialityId: this.specialityId,
      tenantId: this.tenantId
    }
    this.tabService.saveSpecilityTab(obj).subscribe((res: any) => {
      if (res.success) {
        if (!obj.id) {
          this.toasterService.showSuccess(ConstantsMessage.CREATE_TAB_DETAIL, '');
        }
        else {
          this.toasterService.showSuccess(ConstantsMessage.UPDATE_TAB_DETAIL, '');
        }
        this.resetTabForm();
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }

  editTab(data) {
    this.isEditing = true;
    this.tabForm.controls['tabId'].disable();
    this.tabForm.patchValue(data);
  }

  deleteTab(data) {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.DELETE_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.DELETE_CONFIRMATION_Tab_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.tabService.deleteSpecilityTab({ id: data.id }).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(ConstantsMessage.DELETE_TAB_DETAIL, '');
            this.resetTabForm();
          }
        });

      }
    });
  }

  autoCompleteTab(data) {
    this.copyTabList = this.tabList.filter(option => option.tabName.toLowerCase().includes(data.target.value.toLowerCase()));
  }
}

export interface displayedColumns {
  tabName: string;
  displayName: string;
}
let specialityTabList: displayedColumns[];