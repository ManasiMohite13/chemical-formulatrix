import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageTabComponent } from './manage-tab.component';

describe('ManageTabComponent', () => {
  let component: ManageTabComponent;
  let fixture: ComponentFixture<ManageTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageTabComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
