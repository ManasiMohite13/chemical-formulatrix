import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageFormgroupComponent } from './manage-formgroup.component';

describe('ManageFormgroupComponent', () => {
  let component: ManageFormgroupComponent;
  let fixture: ComponentFixture<ManageFormgroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageFormgroupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageFormgroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
