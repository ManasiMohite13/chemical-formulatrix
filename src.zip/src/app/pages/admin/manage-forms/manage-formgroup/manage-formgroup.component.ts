import { Component, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ManageFormsComponent } from '../manage-forms.component';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { TabServiceService } from 'src/app/shared/services/tab-service.service';
import { GroupType, GroupTypeName } from 'src/assets/config/global-enums';

@Component({
  selector: 'app-manage-formgroup',
  templateUrl: './manage-formgroup.component.html',
  styleUrls: ['./manage-formgroup.component.scss']
})
export class ManageFormgroupComponent {
  tabName: string;
  tabId: any;
  specialityId: any;
  tenantId: any;
  formGroupForm: FormGroup;
  public dataSource = new MatTableDataSource(formGroupData);
  displayedColumns: string[] = ['tabGroupName', 'displayName', 'Action',];
  noRecordsFoundMsg: string | undefined;
  groupType = GroupType;
  groupTypeName = GroupTypeName;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  formGroupList: any = [];
  copyFormGroupList: any = [];
  tabFormGroupList: any = [];
  nextDisplayOrder: number;
  isEditing: boolean = false;
  groupTypeList = [{
    id: 1,
    name: "Dynamic Group"
  },
  {
    id: 2,
    name: "Document Group"
  },
  {
    id: 3,
    name: "Medicine Group"
  }]

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private dialogRef: MatDialogRef<ManageFormsComponent>,
    private dialog: MatDialog,
    private tabService: TabServiceService
  ) {
    this.specialityId = data.specialityId;
    this.tenantId = data.tenantId;
    this.tabId = data.tabId;
    this.tabName = data.tabName;

    this.createForm();
    this.getFormGroupList();
    this.getFormGroupListByTab();
  }

  createForm() {
    this.formGroupForm = this.fb.group({
      formGroupDetailId: new FormControl(0),
      formGroupId: new FormControl(null, [Validators.required]),
      displayOrder: new FormControl(this.nextDisplayOrder, [Validators.required]),
      displayName: new FormControl('')
    });
  }

  getFormGroupList() {
    this.tabService.getFormGroupList().subscribe((res: any) => {
      if (res.success) {
        this.formGroupList = res.result;
        this.copyFormGroupList = res.result;        
      }
    });
  }

  getFormGroupListByTab() {
    var obj = {
      tabId: this.tabId,
      specialityId: this.specialityId,
      tenantId: this.tenantId,
    }
    this.tabService.getFormGroupListByTab(obj).subscribe((res: any) => {
      if (res.success) {
        formGroupData = res.result;
        this.tabFormGroupList = formGroupData;
        this.nextDisplayOrder = this.tabFormGroupList.length + 1;
        this.formGroupForm.patchValue({ displayOrder: this.nextDisplayOrder })

        this.dataSource = new MatTableDataSource(this.tabFormGroupList);
      }
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  resetFormGroupForm() {
    this.formGroupForm.reset();
    this.formGroupForm.controls['formGroupId'].enable();
    this.getFormGroupListByTab();
  }

  close() {
    this.dialogRef.close();
  }

  submitForm() {
    this.isEditing = false;
    let id = this.formGroupForm.value.formGroupDetailId == null ? 0 : this.formGroupForm.value.formGroupDetailId
    let check = this.tabFormGroupList.filter(a => a.formGroupId == this.formGroupForm.get('formGroupId').value);
    if (check.length > 0 && id == 0) {
      this.toasterService.showError("This form group is already added", '');
      return;
    }

    let tabGroupName = this.formGroupForm.value.displayName;
    if (!this.formGroupForm.value.displayName) {
      let getGroup = this.formGroupList.filter(a => a.id == this.formGroupForm.get('formGroupId').value);
      if (getGroup.length > 0) {
        tabGroupName = getGroup[0].tabGroupName
      }
    }

    var obj = {
      id: id,
      formGroupId: this.formGroupForm.get('formGroupId').value,
      displayOrder: this.formGroupForm.value.displayOrder,
      displayName: tabGroupName,
      tabId: this.tabId,
      specialityId: this.specialityId,
      tenantId: this.tenantId
    }

    this.tabService.saveFormGroupDetail(obj).subscribe((res: any) => {
      if (res.success) {
        if (!obj.id) {
          this.toasterService.showSuccess(ConstantsMessage.CREATE_FORMGROUP_DETAIL, '');
        }
        else {
          this.toasterService.showSuccess(ConstantsMessage.UPDATE_FORMGROUP_DETAIL, '');
        }
        this.resetFormGroupForm();
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }

  editFormGroup(data) {
    this.isEditing = true;
    this.formGroupForm.controls['formGroupId'].disable();
    this.formGroupForm.patchValue(data);
  }

  deleteFormGroup(data) {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.DELETE_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.DELETE_CONFIRMATION_FORMGROUP_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.tabService.deleteFormGroupDetail({ id: data.formGroupDetailId }).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(ConstantsMessage.DELETE_FORMGROUP_DETAIL, '');
            this.resetFormGroupForm();
          }
        });

      }
    });
  }

  autoCompleteFormGroup(data) {
    this.copyFormGroupList = this.formGroupList.filter(option => option.tabGroupName.toLowerCase().includes(data.target.value.toLowerCase()));
  }
}

export interface displayedColumns {
  tabGroupName: string;
  displayName: string;
}
let formGroupData: displayedColumns[];
