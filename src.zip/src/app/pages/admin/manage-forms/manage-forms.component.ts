import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddEditTabComponent } from './add-edit-tab/add-edit-tab.component';
import { AddEditFormgroupComponent } from './add-edit-formgroup/add-edit-formgroup.component';
import { TabServiceService } from 'src/app/shared/services/tab-service.service';
import { AddEditFormfieldComponent } from './add-edit-formfield/add-edit-formfield.component';
import { ManageTabComponent } from './manage-tab/manage-tab.component';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { ManageFormgroupComponent } from './manage-formgroup/manage-formgroup.component';
import { ManageFormfieldComponent } from './manage-formfield/manage-formfield.component';

@Component({
  selector: 'app-manage-forms',
  templateUrl: './manage-forms.component.html',
  styleUrls: ['./manage-forms.component.scss']
})
export class ManageFormsComponent {
  specialityName: string;
  tenantId: number = 0;
  specialityId: number = 0;
  allSections: any = [];
  public dataSource = new MatTableDataSource();
  displayedColumns: string[] = ['documentName', 'Action'];
  selectedTabId = 0;
  tabList: any = [];
  allfieldsData: any[] = [];

  public currentFormGroup: FormGroup = this.fb.group({});
  currentTab: any;

  hospitalList: any = [];
  hospitalListCopy: any = [];
  specificationList: any;
  specificationListCopy: any = [];

  constructor(private dialogRef: MatDialog, private tabService: TabServiceService, private hospitalService: HospitalService, private doctorService: DoctorService, private fb: FormBuilder) {
    this.getHospitalList();
  }

  getHospitalList() {
    this.hospitalService.getHospitalListAsc().subscribe((res: any) => {
      this.hospitalList = res.result;
      this.hospitalListCopy = this.hospitalList;
    });
  }

  changeTenantId(event: any) {
    this.tenantId = event;
    this.getDoctorSpecification(event);
  }

  changeSpecialityId(event: any) {
    let speciality = this.specificationList.filter(a => a.specilityId == event);
    if (speciality.length > 0) {
      this.specialityName = speciality[0].doctorSpecialityName;
    }
    this.specialityId = event;
    this.getTabMasterList();
  }

  getDoctorSpecification(tenantId: any) {
    this.doctorService.getDoctorSpecility(tenantId).subscribe((res: any) => {
      if (res.success) {
        this.specificationList = res.result;
        this.specificationListCopy = this.specificationList;
      }
    });
  }
  
  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  autoCompleteSpciality(data) {
    this.specificationListCopy = this.specificationList.filter(option => option.doctorSpecialityName.toLowerCase().includes(data.target.value.toLowerCase()));
  }
  resetForm() {
     this.tenantId = 0;
     this.specialityId = 0;
   }

  onTabChangeEvent(event: any) {
    this.selectedTabId = event.tab.textLabel;
    this.tabGroupFieldDetails(this.selectedTabId).then((res) => {
      this.activateTab(this.selectedTabId);
    });
  }

  onTabClick() {
    const confirmDialog = this.dialogRef.open(AddEditTabComponent, {
      width: '900px',
      disableClose: true,
      //data: this.tabList
    });
    confirmDialog.afterClosed().subscribe((result) => { });
  }

  onFormGroupClick() {
    const confirmDialog = this.dialogRef.open(AddEditFormgroupComponent, {
      width: '1000px',
      disableClose: true,
      //data: tabData
    });
    confirmDialog.afterClosed().subscribe((result) => { });
  }

  onFormFieldClick() {
    const confirmDialog = this.dialogRef.open(AddEditFormfieldComponent, {
      width: '1000px',
      disableClose: true,
      //data: tabData
    });
    confirmDialog.afterClosed().subscribe((result) => { });
  }

  onManageTabClick() {
    const confirmDialog = this.dialogRef.open(ManageTabComponent, {
      width: '900px',
      disableClose: true,
      data: { specialityId: this.specialityId, tenantId: this.tenantId, specialityName: this.specialityName }
    });
    confirmDialog.afterClosed().subscribe((result) => { this.getTabMasterList(); });
  }

  getTabMasterList() {
    let obj = {
      id: this.specialityId,
      tenantId: this.tenantId
    }
    this.tabService.getTabListBySpecilityId(obj).subscribe((res: any) => {
      if (res.success) {
        this.tabList = res.result;
        this.tabList = this.tabList.sort((a, b) => a.displayOrder - b.displayOrder);
        this.activateTab(this.tabList[0].tabId);
      }
    })
  }

  onManageFormGroup(tab: any) {
    console.log(tab);
    const confirmDialog = this.dialogRef.open(ManageFormgroupComponent, {
      width: '900px',
      disableClose: true,
      data: { specialityId: this.specialityId, tenantId: this.tenantId, tabId: tab.tabId, tabName: tab.displayName }
    });
    confirmDialog.afterClosed().subscribe((result) => { this.tabGroupFieldDetails(this.selectedTabId).then((res) => { this.activateTab(this.selectedTabId); }); });
  }

  tabGroupFieldDetails(tabId: any) {
    return new Promise((resolve, reject) => {
      let obj = {
        tabId: tabId,
        specialityId: this.specialityId,
        tenantId: this.tenantId
      }
      this.tabService.tabGroupFieldsBySpecilityTabDetail(obj).subscribe((res: any) => {
        if (res.success) {
          this.allfieldsData = res.result;
          this.allfieldsData.sort((a: any, b: any) => a.displayOrder - b.displayOrder);
          resolve(true);
        }
      });
    });
  }

  activateTab(tabId: number) {
    this.currentFormGroup = this.fb.group({});
    this.currentTab = this.tabList.find((e) => e.tabId === tabId);
    let allSections = this.allfieldsData.filter(e => this.currentTab.tabId == tabId);
    allSections = allSections.map((section: any) => {
      section.formFields = section.formFields.sort((a: any, b: any) => a.fieldsDisplayOrder - b.fieldsDisplayOrder);
      return section;
    });
    this.createForm(allSections).then((e) => {
      this.allSections = allSections;
    });
  }

  createForm(sections: any[]) {
    return new Promise((resolve, reject) => {
      for (const section of sections) {
        for (const control of section.formFields) {
          if (control.type == 'table') {
            this.currentFormGroup.addControl(control.fieldName, this.fb.array([]));
          } else {
            this.currentFormGroup.addControl(
              control.fieldName,
              this.fb.control({ value: (control.fieldType == 'file' || control.fieldType == 'dropdown' || control.fieldType == 'number') ? null : (''), disabled: control.fieldType == 'dropdown' ? false : true })
            );
          }
        }
      }
      resolve(true)
    });
  }

  onManageFormField(group: any) {
    const confirmDialog = this.dialogRef.open(ManageFormfieldComponent, {
      width: '900px',
      disableClose: true,
      data: { tenantId: this.tenantId, formGroupId: group.tabGroupId, groupName: group.tabGroupDisplayName }
    });
    confirmDialog.afterClosed().subscribe((result) => { this.getTabMasterList(); });
  }
}

export interface displayedColumns {
  documentName: string;
}
let documentData: displayedColumns[];