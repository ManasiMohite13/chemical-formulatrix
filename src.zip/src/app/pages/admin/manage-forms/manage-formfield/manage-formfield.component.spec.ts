import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageFormfieldComponent } from './manage-formfield.component';

describe('ManageFormfieldComponent', () => {
  let component: ManageFormfieldComponent;
  let fixture: ComponentFixture<ManageFormfieldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageFormfieldComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageFormfieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
