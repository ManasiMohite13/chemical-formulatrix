import { Component, Inject, ViewChild, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ManageFormsComponent } from '../manage-forms.component';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { TabServiceService } from 'src/app/shared/services/tab-service.service';
import { MatChipEditedEvent, MatChipInputEvent } from '@angular/material/chips';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import { COMMA, ENTER } from '@angular/cdk/keycodes';

@Component({
  selector: 'app-manage-formfield',
  templateUrl: './manage-formfield.component.html',
  styleUrls: ['./manage-formfield.component.scss']
})
export class ManageFormfieldComponent {
  selectedValue = 2;
  addOnBlur = true;
  readonly separatorKeysCodes = [ENTER, COMMA] as const;
  announcer = inject(LiveAnnouncer);
  groupName: string;
  formGroupId: any;
  tenantId: any;
  selectedFieldType: any;
  formFieldForm: FormGroup;
  optionList: any = [];
  public dataSource = new MatTableDataSource(formFieldData);
  displayedColumns: string[] = ['formFieldName', 'displayName', 'Action',];
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  formFieldList: any = [];
  copyFormFieldList: any = [];
  formFieldDetailList: any = [];
  showOptions: boolean = false;
  nextDisplayOrder: number;
  isEditing: boolean = false;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private dialogRef: MatDialogRef<ManageFormsComponent>,
    private dialog: MatDialog,
    private tabService: TabServiceService
  ) {
    this.tenantId = data.tenantId;
    this.formGroupId = data.formGroupId;
    this.groupName = data.groupName;

    this.createForm();
    this.getFormFieldList();
    this.getFormFieldDetailList();
  }

  createForm() {
    this.formFieldForm = this.fb.group({
      id: new FormControl(0),
      formFieldId: new FormControl(null, [Validators.required]),
      displayOrder: new FormControl(this.nextDisplayOrder, [Validators.required]),
      displayName: new FormControl(''),
      formFieldValue: new FormControl(''),
      showOnPrescription: new FormControl(false)
    });
  }

  getFormFieldList() {
    this.tabService.getFormFieldList().subscribe((res: any) => {
      if (res.success) {
        this.formFieldList = res.result;
        this.copyFormFieldList = res.result;
      }
    });
  }

  getFormFieldDetailList() {
    let obj = {
      id: this.formGroupId,
      tenantId: this.tenantId,
    }
    this.tabService.getFormFieldDetailList(obj).subscribe((res: any) => {
      if (res.success) {
        formFieldData = res.result;
        this.formFieldDetailList = formFieldData;
        this.nextDisplayOrder = this.formFieldDetailList.length + 1;
        this.formFieldForm.patchValue({ displayOrder: this.nextDisplayOrder })
        this.dataSource = new MatTableDataSource(this.formFieldDetailList);
      }
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  resetformFieldForm() {
    this.selectedFieldType = null;
    this.showOptions = false;
    this.formFieldForm.reset({
      showOnPrescription: false
    });
    this.formFieldForm.controls['formFieldId'].enable();
    this.formFieldForm.patchValue({ id: 0 });
    this.getFormFieldDetailList();
  }

  close() {
    this.dialogRef.close();
  }

  submitForm() {
    debugger
    this.isEditing = false;
    let id = this.formFieldForm.value.id == null ? 0 : this.formFieldForm.value.id
    let check = this.formFieldDetailList.filter(a => a.formFieldId == this.formFieldForm.get('formFieldId').value);
    if (check.length > 0 && id == 0) {
      this.toasterService.showError("This form field is already added", '');
      return;
    }
    if (this.optionList.length === 0 && id == 0) {
      this.toasterService.showError('Options are required !', '');
      return;
    }

    let formFieldName = this.formFieldForm.value.displayName;
    if (!this.formFieldForm.value.displayName) {
      let getField = this.formFieldList.filter(a => a.id == this.formFieldForm.get('formFieldId').value);
      if (getField.length > 0) {
        formFieldName = getField[0].formFieldName
      }
    }

    if (this.optionList.length < 0 && (this.selectedFieldType == 'dropdown' || this.selectedFieldType == 'radio' || this.selectedFieldType == 'checkbox')) {
      this.toasterService.showError("Option can not be empty!", '');
      return;
    }

    var obj = {
      id: id,
      formFieldId: this.formFieldForm.get('formFieldId').value,
      displayOrder: this.formFieldForm.value.displayOrder,
      displayName: formFieldName,
      formFieldValue: this.optionList.toString(),
      formGroupId: this.formGroupId,
      tenantId: this.tenantId,
      showOnPrescription: this.formFieldForm.value.showOnPrescription
    }
    this.tabService.saveFormFieldDetail(obj).subscribe((res: any) => {
      if (res.success) {
        if (!obj.id) {
          this.toasterService.showSuccess(ConstantsMessage.CREATE_FORMFIELD_DETAIL, '');
        }
        else {
          this.toasterService.showSuccess(ConstantsMessage.UPDATE_FORMFIELD_DETAIL, '');
        }
        this.resetformFieldForm();
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }

  editFormField(data) {
    this.isEditing = true;
    this.formFieldForm.patchValue(data);
    this.onChangeField();
    this.formFieldForm.controls['formFieldId'].disable();
  }

  deleteFormField(data) {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.DELETE_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.DELETE_CONFIRMATION_FORMFIELD_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.tabService.deleteFormFieldDetail({ id: data.id }).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(ConstantsMessage.DELETE_FORMFIELD_DETAIL, '');
            this.resetformFieldForm();
          }
        });
      }
    });
  }

  autoCompleteFormField(data) {
    this.copyFormFieldList = this.formFieldList.filter(option => option.formFieldName.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  onChangeField() {
    this.selectedFieldType = null;
    let filter = this.formFieldList.filter(a => a.id == this.formFieldForm.value.formFieldId);
    if (filter.length > 0) {
      this.selectedFieldType = filter[0].formFieldType
      if (this.selectedFieldType == 'dropdown' || this.selectedFieldType == 'radio' || this.selectedFieldType == 'checkbox') {
        //this.formFieldForm.get('formFieldValue').setValidators([Validators.required]);
        this.showOptions = true;
        this.optionList = [];
        this.getFormFieldValuebyIdAndTenantId();
      } else {
        this.formFieldForm.get('formFieldValue').clearValidators();
        this.showOptions = false;
      }
      this.formFieldForm.patchValue({ formFieldValue: '' });
      this.formFieldForm.get('formFieldValue').updateValueAndValidity();

    }
  }

  getFormFieldValuebyIdAndTenantId() {
    let obj = {
      id: this.formFieldForm.value.formFieldId,
      tenantId: this.formFieldForm.value.id == 0 ? null : this.tenantId
    }
    this.tabService.getFormFieldValuebyIdAndTenantId(obj).subscribe((res: any) => {
      if (res.success) {
        if (res.result.length > 0) {
          // if(this.formFieldForm.value.id == 0){
          this.optionList = res.result.map(item => item.formFieldValue);
          // }else{
          //   this.optionList = res.result;        
          //   this.optionList = this.optionList.formFieldValue.split(',');
          // }        
        }
      }
    });
  }

  addOption(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();
    const existingOption = this.optionList.find(option => option.toLowerCase() === value.toLowerCase());
    if (existingOption) {
      this.toasterService.showError(value + ' ' + "name is already exist !", '');
      return;
    }

    if (value) {
      this.optionList.push(value);
    }
    event.chipInput!.clear();
  }

  isOptionDuplicate(value: string): boolean {
    return this.optionList.includes(value);
  }

  removeOption(option: any): void {
    const index = this.optionList.indexOf(option);

    if (index >= 0) {
      this.optionList.splice(index, 1);
      this.announcer.announce(`Removed ${option}`);
    }
  }

  editOption(option: any, event: MatChipEditedEvent) {
    const value = event.value.trim();
    if (!value) {
      this.removeOption(option);
      return;
    }

    const index = this.optionList.indexOf(option);
    if (index >= 0) {
      this.optionList[index] = value;
    }
  }
}

export interface displayedColumns {
  formFieldName: string;
  displayName: string;
}
let formFieldData: displayedColumns[];