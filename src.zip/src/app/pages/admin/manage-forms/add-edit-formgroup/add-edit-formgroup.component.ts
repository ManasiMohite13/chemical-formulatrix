import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ManageFormsComponent } from '../manage-forms.component';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { TabServiceService } from 'src/app/shared/services/tab-service.service';
import { GroupType, GroupTypeName } from 'src/assets/config/global-enums';

@Component({
  selector: 'app-add-edit-formgroup',
  templateUrl: './add-edit-formgroup.component.html',
  styleUrls: ['./add-edit-formgroup.component.scss']
})
export class AddEditFormgroupComponent {

  formGroupForm: FormGroup;
  public dataSource = new MatTableDataSource(formGroupData);
  displayedColumns: string[] = ['tabGroupName', 'groupType', 'Action',];
  noRecordsFoundMsg: string | undefined;
  groupType = GroupType;
  groupTypeName = GroupTypeName;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  formGroupList: any = [];
  isEditing: boolean = false;
  groupTypeList = [{
    id: 1,
    name: "Dynamic Group"
  },
  {
    id: 2,
    name: "Document Group"
  },
  {
    id: 3,
    name: "Medicine Group"
  }]

  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private dialogRef: MatDialogRef<ManageFormsComponent>,
    private dialog: MatDialog,
    private tabService: TabServiceService
  ) {
    this.createForm();
    this.getFormGroupList();
  }

  createForm() {
    this.formGroupForm = this.fb.group({
      id: new FormControl(0),
      tabGroupName: new FormControl('', [Validators.required, Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      groupType: new FormControl(null, [Validators.required]),
      description: new FormControl(''),
    });
  }

  getFormGroupList() {
    this.tabService.getFormGroupList().subscribe((res: any) => {
      if (res.success) {
        formGroupData = res.result;
        this.formGroupList = formGroupData;
        this.dataSource = new MatTableDataSource(this.formGroupList);
      }
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  resetFormGroupForm() {
    this.formGroupForm.reset();
    this.getFormGroupList();
  }

  close() {
    this.dialogRef.close();
  }

  submitForm() {
    this.isEditing = false;
    var check = this.formGroupList.filter(a => a.tabGroupName == this.formGroupForm.value.tabGroupName);
    if (check.length > 0 && !this.formGroupForm.value.id) {
      this.toasterService.showError("This Form Gorup is already added", '');
      return;
    }

    var obj = {
      id: this.formGroupForm.value.id == null ? 0 : this.formGroupForm.value.id,
      tabGroupName: this.formGroupForm.value.tabGroupName,
      groupType: this.formGroupForm.value.groupType,
      description: this.formGroupForm.value.description
    }
    this.tabService.saveFormGroup(obj).subscribe((res: any) => {
      if (res.success) {
        if (!obj.id) {
          this.toasterService.showSuccess(ConstantsMessage.CREATE_FORMGROUP, '');
        }
        else {
          this.toasterService.showSuccess(ConstantsMessage.UPDATE_FORMGROUP, '');
        }
        this.resetFormGroupForm();
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }

  editFormGroup(data) {
    this.isEditing = true;
    this.formGroupForm.patchValue(data);
  }

  deleteFormGroup(data) {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.DELETE_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.DELETE_CONFIRMATION_FORMGROUP_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.tabService.deleteFormGroup({ id: data.id }).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(ConstantsMessage.DELETE_FORMGROUP, '');
            this.resetFormGroupForm();
          }
        });

      }
    });
  }
}

export interface displayedColumns {
  tabGroupName: string;
  groupType: string;
}
let formGroupData: displayedColumns[];