import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditFormgroupComponent } from './add-edit-formgroup.component';

describe('AddEditFormgroupComponent', () => {
  let component: AddEditFormgroupComponent;
  let fixture: ComponentFixture<AddEditFormgroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditFormgroupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditFormgroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
