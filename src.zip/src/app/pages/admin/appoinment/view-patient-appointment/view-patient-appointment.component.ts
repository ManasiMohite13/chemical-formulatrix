import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { PeriodicElement } from '../../patient-card/patient-medicine/patient-medicine.component';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatSort } from '@angular/material/sort';
import { AppointmentSource, AppointmentSourceName, AppointmentStatus, AppointmentStatusName } from 'src/assets/config/global-enums';
import { ConstantsRoutes } from 'src/assets/config/constants-routes';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-view-patient-appointment',
  templateUrl: './view-patient-appointment.component.html',
  styleUrls: ['./view-patient-appointment.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ViewPatientAppointmentComponent {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  @ViewChild('printableContent') printableContent: ElementRef;
  columnsToDisplay = ['tabName'];
  selectedTab: number = 0;
  appointmentSource = AppointmentSource;
  appointmentSourceName = AppointmentSourceName;
  appointmentStatus = AppointmentStatus;
  appointmentStatusName = AppointmentStatusName;
  showDetailView: boolean = false;
  expandedElement: PeriodicElement | null = null;
  public dataSource = new MatTableDataSource(patientHistory);
  noRecordsFoundMsg: string | undefined;
  appointmentId: any = null;
  patientId: any = null;
  documentList: any;
  patientForm!: FormGroup;
  patientData: any = [];
  patientDetailData: any = [];
  displayedColumns: string[] = [
    'appointmentDateTime',
    'appointmentTime',
    'appointmentReason',
    'doctorName',
    'appointmentSource',
    'appointmentStatus'
  ];
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];
  id: any
  patientRelation: any = [
    { id: 1, relation: 'Father' },
    { id: 2, relation: 'Mother' },
    { id: 3, relation: 'son' }
  ];
  dyanamicHistory: any = [];
  patientAppointmentHistory: any = []
  constructor(
    private patientService: PatientService,
    private router: Router,
    private http: HttpService,
    public hospitalService: HospitalService
  ) {
    //this.updateForm();
    // if (this.id != '') {
    // let obj = {
    //   id: Number(this.http.getDecryptedValue('patientappointmentId')),
    // };
    this.patientId = Number(this.http.getDecryptedValue('patientId'));
    this.appointmentId = Number(this.http.getDecryptedValue('appointmentId'));
    if (this.patientId > 0 && this.appointmentId > 0) {
      this.getPatientHistroy();
    }
    //this.getPatientDetail(obj);
    // }
  }

  // updateForm() {
  //   this.patientForm = this.fb.group({
  //     id: new FormControl(),
  //     patientName: new FormControl({ value: null, disabled: true }),
  //     gender: new FormControl({ value: null, disabled: true }),
  //     contactNo: new FormControl({ value: null, disabled: true }),
  //     email: new FormControl({ value: null, disabled: true }),
  //     hospitalName: new FormControl({ value: null, disabled: true }),
  //     appointmentReason: new FormControl({ value: null, disabled: true }),
  //     bloodGroup: new FormControl({ value: null, disabled: true }),
  //     dateOfBirth: new FormControl({ value: null, disabled: true }),
  //     lastFollowupdate: new FormControl({ value: null, disabled: true }),
  //     familyMemberName: new FormControl({ value: null, disabled: true }),
  //     relationToPatient: new FormControl({ value: null, disabled: true }),
  //     familyPersonDateOfBirth: new FormControl({ value: null, disabled: true }),
  //     // gender: new FormControl({ value: null, disabled: true }),
  //     familyContactNo: new FormControl({ value: null, disabled: true }),
  //     appointmentDateTime: new FormControl({ value: null, disabled: true }),
  //     status: new FormControl({ value: null, disabled: true }),
  //   });
  // }

  // getPatientDetail(id: any) {
  //   this.patientService.getPatientHistroy(id).subscribe((res: any) => {
  //     this.patientData = res.result;
  //     console.log("P", this.patientData);
  //     this.patientForm.patchValue(this.patientData);

  //     this.patientForm.patchValue(this.patientData.patientFamilyDetailData);
  //     this.patientForm.patchValue(this.patientData.patientAppointmentHistory[0].patientDynamicHistory);
  //     this.dyanamicHistory = this.patientData.patientAppointmentHistory[0].patientDynamicHistory;
  //     console.log(this.patientData.patientAppointmentHistory);
  //     if (this.patientData.patientAppointmentHistory.length < 0) {
  //       this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
  //     }
  //     this.dataSource = new MatTableDataSource(this.patientData.patientAppointmentHistory);
  //     this.dataSource.sort = this.sort;
  //     // if (this.patientData.patientAppointmentHistory[0].patientDynamicHistory[4].tabDataList[0].fieldName === "Choose File") {
  //     //   const deserializedObject = {
  //     //     name:this.patientData.patientAppointmentHistory[0].patientDynamicHistory.fieldName
  //     //   }
  //     // }
  //   });
  // }

  rowClick(data: any) {
    let history = this.patientData?.patientAppointmentHistory.filter(a => a.id == data.id);
    this.dataSource = new MatTableDataSource(history[0].patientDynamicHistory);
  }

  back() {
    this.router.navigate(['/pages/admin/appointment']);
  }

  getPatientHistroy() {
    var obj = {
      patientId: this.patientId,
      appointmentId: this.appointmentId,
    }
    this.patientService.getPatientHistroy(obj).subscribe((res: any) => {
      if (res.success) {
        this.patientData = res.result;
        if (this.patientData.patientAppointmentHistory.length > 0) {
          patientHistory = this.patientData.patientAppointmentHistory;
          this.dataSource = new MatTableDataSource(patientHistory);
        } else {
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(patientHistory);
        }
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });
  }

  onTabChangeEvent(event: any) {
    this.selectedTab = event.index;
    this.showDetailView = false;
  }

  onHistoryClick(row: any, isshow: boolean) {
    this.documentList = null;
    this.patientDetailData = null;
    if (row) {
      this.patientDetailData = row;
      //for (let i = 0; i < this.patientDetailData.patientDynamicHistory.length; i++) {
      //const fieldData = this.patientDetailData.patientDynamicHistory[i];
      // if (fieldData.tabId == 5) {
      //   this.documentList = JSON.parse(fieldData.tabDataList[0].fieldValue);
      //   this.patientDetailData.patientDynamicHistory.splice(i, 1);
      // }
      //}
    }
    this.showDetailView = isshow;
  }

  download(path, name) {
    const a = document.createElement('a');
    var docPath = ConstantsRoutes.Main_URL + path;
    fetch(docPath)
      .then(response => response.blob())
      .then(blob => {
        const url = URL.createObjectURL(blob);
        a.href = url;
        a.download = name + '';
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
      })
      .catch(error => {
        console.error('Error fetching the file:', error);
      });
  }

  printPage() {
    const content = this.printableContent.nativeElement.innerHTML;
    const printWindow = window.open('', '', 'width=600,height=600');
    printWindow.document.open();
    printWindow.document.write('<html><head><title>Print</title></head><body>');
    printWindow.document.write(content);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
  }
}
export interface displayedColumns {
  appointmentDateTime: string;
  appointmentReason: string;
  doctorName: string;
  appointmentSource: string;
  appointmentTime: string;
  appointmentStatus: number;
}
let patientHistory: displayedColumns[];