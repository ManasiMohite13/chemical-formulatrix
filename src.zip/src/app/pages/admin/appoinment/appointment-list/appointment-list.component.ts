import { Component, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import {
  Calendar,
} from '@fullcalendar/core';

import { MatDialog } from '@angular/material/dialog';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { DatePipe, Time } from '@angular/common';
import { FullCalendarComponent } from '@fullcalendar/angular';
import { AuthService } from 'src/app/shared/services/auth.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-appointment-list',
  templateUrl: './appointment-list.component.html',
  styleUrls: ['./appointment-list.component.scss']
})
export class AppointmentListComponent {
  @ViewChild('calendar') calendarComponent!: FullCalendarComponent;
  calendarApi!: Calendar;
  cancelForm!: FormGroup
  appoinmentForm!: FormGroup;
  statusList: any = [
    { id: 3, status: 'Visited ' },
    { id: 2, status: 'Cancelled' },
    { id: 1, status: 'Booked' },
  ];
  totalRowCount = 0;

  isListView = true; // Initial view is the listing view
  userProfile: boolean = true;
  userChangePassword: boolean = false
  doctorData: any = [];
  public dataSource = new MatTableDataSource(doctorData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();

  weekStart!: Date;
  weekEnd!: Date;
  hospitalList: any;
  hospitalData: any;
  roleId: any;
  currentAppointmentId: any
  displayedColumns: string[] = [
    'title',
    'gender',
    'patientDateOfBirth',
    'start',
    'time',
    'doctorName',
    'purposeOfAppointment',
    'Action',
  ];
  convertedTime: any;
  constructor(
    private formBuilder: FormBuilder,
    private appoinmentService: AppoinmentService,
    private router: Router,
    public datepipe: DatePipe,
    private httpService: HttpService,
    private doctorService: DoctorService,
    private dialog: MatDialog,
    private fb: FormBuilder,
    private authservice: AuthService,
    private tosterService: ToasterService) {
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.cancelcreateForm()
    this.createForm();
    this.getHospitalList();
    this.getAppoinment()
  }

  resetForm() {
    this.appoinmentForm.reset();
    this.createForm();
  }

  cancelcreateForm() {
    this.cancelForm = this.fb.group({
      id: new FormControl(),
      appointmentReason: new FormControl('', [Validators.required, Validators.pattern(ConstantsMessage.ONLY_NUMBER_AND_CHARACTER_PATTERN), Validators.maxLength(50)]),
    })
  }
  submitCancelForm() {

    let obj = {
      id: this.currentAppointmentId,
      appointmentReason: this.cancelForm.value.appointmentReason,
    }
    this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
      if (res.success) {
        this.tosterService.showSuccess(ConstantsMessage.APPOINMENT_CANCEL, '');
        // this.router.navigate(['pages/admin/appointment/appointment-list']);
        this.getAppoinment();

      }
    })

  }

  getHospitalList() {
    let obj = {
      tenantId: '08db9fb7-9d0d-4cfe-8f9b-ffb485e75af7'
    }
    this.doctorService.getDoctorListByTenantId(obj).subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }

  createForm() {
    this.appoinmentForm = this.formBuilder.group({
      fromDate: [this.setDate(true), this.datepipe.transform(this.weekStart, 'yyyy-MM-dd')],
      toDate: [this.setDate(false), this.datepipe.transform(this.weekEnd, 'yyyy-MM-dd')],
      status: new FormControl(1),
      doctorId: new FormControl(),
    });
  }

  private setDate(isSunday): Date {
    const today = new Date();
    const dayOfWeek = today.getDay();
    var diff = null;
    if (isSunday) {
      diff = today.getDate() - dayOfWeek;
    } else {
      diff = today.getDate() + (6 - dayOfWeek);
    }
    return new Date(today.setDate(diff));
  }

  toggleView() {
    this.isListView = !this.isListView;
  }


  cancelAppointment(templateRef: TemplateRef<any>, id: any) {
    this.currentAppointmentId = id;
    const confirmDialog = this.dialog.open(templateRef, {
      width: '350px',
      disableClose: true,
      data: {
        id: id

      }
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.getAppoinment();
      }
    });
  }
  viewAppointment(data: any) {
    this.authservice.encryptKey('patientId', data.patientId);
    this.authservice.encryptKey('appointmentId', data.id);
    this.router.navigate(['pages/admin/appointment/view-patient-appointment'])

  }
  addAppoinment() {
    this.router.navigate(['pages/admin/appointment/add-appointment']);
  }

  changeHospital(event: any) {
    this.hospitalData = event;

  }

  getAppoinment(): void {
    let obj = {
      doctorId: this.appoinmentForm.value.doctorId,
      fromDate: this.datepipe.transform(
        this.appoinmentForm?.value.fromDate,
        'yyyy-MM-dd'
      ),
      toDate: this.datepipe.transform(
        this.appoinmentForm?.value.toDate,
        'yyyy-MM-dd'
      ),
      status: this.appoinmentForm.value.status || 1,
    };
    this.appoinmentService.getAppoinmentList(obj).subscribe((res: any) => {
      if (res.success) {
        let doctorData = res.result;
        // for (const appointment of doctorData) {
        //   const convertedTime = this.datepipe.transform(appointment.start, 'h:mm a');
        //   this.convertedTime = convertedTime ? convertedTime :appointment.start;
        // }
        if (res.result.length > 0) {
          this.dataSource = new MatTableDataSource(doctorData);
        } else {
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(doctorData);
        }
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;

      }

    });
  }

}



export interface displayedColumns {
  title: string;
  gender: string;
  patientDateOfBirth: Date;
  start: Date;
  time: Time;
  purposeOfAppointment: string;
  doctorName: string
}
let doctorData: displayedColumns[];
