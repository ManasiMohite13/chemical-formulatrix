import { ChangeDetectorRef, Component, Inject, Optional } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';

@Component({
  selector: 'app-view-appoinment',
  templateUrl: './view-appoinment.component.html',
  styleUrls: ['./view-appoinment.component.scss'],
})
export class ViewAppoinmentComponent {
  appoinmentForm!: FormGroup;
  appoinmentId: any;
  appoinmentDetail: any;
  constructor(
    private fb: FormBuilder,
    private appoinmentService: AppoinmentService,
    private router: Router,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    private dialog: MatDialog,
    public dialogRef: MatDialogRef<ViewAppoinmentComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.appoinmentId = data;
    this.createForm();
    if (this.appoinmentId) {
      this.getAppoinment();
    }
  }
  createForm() {
    this.appoinmentForm = this.fb.group({
      id: new FormControl(),
      doctorName: new FormControl({ value: null, disabled: true }),
      appointmentDate: new FormControl({ value: null, disabled: true }),
      appointmentSource: new FormControl({ value: null, disabled: true }),
      patientName: new FormControl({ value: null, disabled: true }),
    });
  }

  getAppoinment() {
    const obj = {
      id: Number(this.appoinmentId),
    };
    this.appoinmentService.getAppoinmentById(obj).subscribe((res: any) => {
      if (res.success) {
        this.appoinmentDetail = res.result;
        this.appoinmentForm.patchValue(this.appoinmentDetail);
      }
    });
  }

  cancelAppoinment() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CANCEL_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.CANCEL_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        let obj = {
          id: Number(this.appoinmentId),
        };
        this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(
              ConstantsMessage.APPOINMENT_CANCEL,
              ''
            );
          }
        });
        this.router
          .navigateByUrl('/', {
            skipLocationChange: true,
          })
          .then(() => {
            this.router.navigate(['pages/admin/appointment']);
          });
      }
    });
  }
}
