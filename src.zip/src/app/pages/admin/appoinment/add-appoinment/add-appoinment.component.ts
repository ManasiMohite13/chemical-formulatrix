import { DatePipe } from '@angular/common';
import { AfterViewInit, ChangeDetectorRef, Component, Input } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import * as moment from 'moment';
import { extendMoment } from 'moment-range';
import { HttpService } from 'src/app/shared/services/http.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-add-appoinment',
  templateUrl: './add-appoinment.component.html',
  styleUrls: ['./add-appoinment.component.scss'],
})
export class AddAppoinmentComponent implements AfterViewInit {
  rangeMoment = extendMoment(moment);
  appoinmentForm!: FormGroup;
  timeslots: any[] = [];
  doctorlist: any;
  patientList: any;
  drId: any;
  appTime: any;
  shiftType: boolean = true;
  doctorId: any;
  roleId: any;
  doctorSchedule: any = [];
  minDate = new Date();
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];

  appoinmentsSources: any = [
    { id: 1, source: 'Phone' },
    { id: 2, source: 'Web' },
    { id: 3, source: 'Personal Visit' },
  ];
  @Input() max: any;
  tomorrow = new Date();
  existingPatient: boolean = false;
  newPatientList: boolean = true;
  timesSlot: boolean = false;
  selectedDoctor: any;
  hospitalList: any
  hospitalData: any
  paginator: any;
  pageSizeTemp: number;
  doctorData: any;
  doctorlists: any;
  isMorningPanelOpen = false;
  isEveningPanelOpen = false;
  patientRelation: any = [
    { id: 1, relation: 'Father' },
    { id: 2, relation: 'Mother' },
    { id: 3, relation: 'son' },
    { id: 4, relation: 'Sister' },
    { id: 5, relation: 'Uncle' },
    { id: 6, relation: 'Aunty ' },
    { id: 7, relation: 'Brother ' },
    { id: 8, relation: 'Other ' },];

  statusList: any = [
    { id: 'O+', status: 'O+' },
    { id: 'A+', status: 'A+' },
    { id: 'A-', status: 'A-' },
    { id: 'O-', status: 'O-' },
    { id: 'B+', status: 'B+' },
    { id: 'AB+', status: 'AB+' },
    { id: 'AB-', status: 'AB-' },
 ];  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private doctorService: DoctorService,
    private patientService: PatientService,
    private httpService: HttpService,
    private appoinmentService: AppoinmentService,
    private router: Router,
    public datepipe: DatePipe,
    private cdr: ChangeDetectorRef,
    private hospitalService: HospitalService,
    private dialog: MatDialog) {
    this.updatePanelStates();
    this.tomorrow.setDate(this.tomorrow.getDate() + 0);
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.createForm();
    this.getPatientList();
    this.getHospitalList();
    this.getDoctorLists();
    this.getPatientLists();
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }

  getDoctorList() {
    this.doctorService.doctorListByHospital(this.hospitalData).subscribe((res: any) => {
      if (res.success) {
        this.doctorlist = res.result;
        // if (this.roleId == 3) {
        //   this.selectedDoctor = this.doctorlist[0].doctorId;
        //   this.drId = this.selectedDoctor;
        //   this.getAppoinment();
        // }
      }
    });
  }

  getDoctorLists() {
    this.doctorService.doctorListByHospitals().subscribe((res: any) => {
      if (res.success) {
        this.doctorlist = res.result;
        if (this.roleId == 3) {
          this.selectedDoctor = this.doctorlist[0].doctorId;
          this.drId = this.selectedDoctor;
          this.getAppoinment();
        }
      }
    });
  }

  getPatientList() {
    this.patientService.getPatientListByHospital(this.hospitalData || '00000000-0000-0000-0000-000000000000').subscribe((res: any) => {
      if (res.success) {
        this.patientList = res.result;
      }
    });
  }

  getPatientLists() {
    this.patientService.getPatientListByHospitals().subscribe((res: any) => {
      if (res.success) {
        this.patientList = res.result;
      }
    });
  }
  resetappoinmentForm() {
    const doctorId = this.appoinmentForm.get('doctorId')?.value
    this.appoinmentForm.reset();
    this.appoinmentForm.get('doctorId')?.setValue(doctorId);
  }
  back() {
    this.router.navigate(['/pages/admin/appointment'])
  }

  existing() {
    this.existingPatient = true;
    this.newPatientList = false;
    this.appoinmentForm.controls['firstName'].disable();
    this.appoinmentForm.controls['lastName'].disable();
    this.appoinmentForm.controls['primaryContactNo'].disable();
    this.appoinmentForm.controls['gender'].disable();
    this.appoinmentForm.controls['patientId'].enable();

    this.appoinmentForm.controls['dateOfBirth'].disable();
    this.appoinmentForm.controls['email'].disable();
    this.appoinmentForm.controls['bloodGroup'].disable();
    this.appoinmentForm.controls['address1'].disable();
    this.appoinmentForm.controls['city'].disable();

    this.appoinmentForm.controls['district'].disable();
    this.appoinmentForm.controls['state'].disable();
    this.appoinmentForm.controls['zipCode'].disable();
    this.appoinmentForm.controls['familyMemberName'].disable();
    this.appoinmentForm.controls['contactNumber'].disable();

    this.appoinmentForm.controls['familyPersonDOB'].disable();
    this.appoinmentForm.controls['familyMemberGender'].disable();
    this.appoinmentForm.controls['relationToPatient'].disable();

  }

  new() {
    this.existingPatient = false;
    this.newPatientList = true;
    this.appoinmentForm.controls['firstName'].enable();
    this.appoinmentForm.controls['lastName'].enable();
    this.appoinmentForm.controls['primaryContactNo'].enable();
    this.appoinmentForm.controls['gender'].enable();
    this.appoinmentForm.controls['patientId'].disable();

    this.appoinmentForm.controls['dateOfBirth'].enable();
    this.appoinmentForm.controls['email'].enable();
    this.appoinmentForm.controls['bloodGroup'].enable();
    this.appoinmentForm.controls['address1'].enable();

    this.appoinmentForm.controls['city'].enable();
    this.appoinmentForm.controls['district'].enable();
    this.appoinmentForm.controls['state'].enable();

    this.appoinmentForm.controls['zipCode'].enable();
    this.appoinmentForm.controls['familyMemberName'].enable();
    this.appoinmentForm.controls['contactNumber'].enable();

    this.appoinmentForm.controls['familyPersonDOB'].enable();
    this.appoinmentForm.controls['familyMemberGender'].enable();
    this.appoinmentForm.controls['relationToPatient'].enable();



    
  }

  changeTime(event: any) {
    this.drId = event;
    this.getAppoinment();
  }
  changeHospital(event: any) {
    this.hospitalData = event;
    this.getDoctorList();
    this.getPatientList();
  }

  onChangeAppDate(event: any) {
    this.appTime = event.value;
    this.isMorningPanelOpen = true; 
    this.getAppoinment();
  }
  
  getAppoinment() {
    if (this.drId && this.appTime) {
      let obj = {
        doctorId: this.drId,
        appointmentDate: this.datepipe.transform(this.appTime, 'yyyy-MM-dd'),
      };
      this.doctorService.getDoctorScheduleList(obj).subscribe((res: any) => {
        if (res.success) {
          this.doctorSchedule = res.result;
          this.updatePanelStates();
          this.doctorSchedule.sort((a, b) => a.shift - b.shift);
        }
      });
    }
  }

  updatePanelStates(): void {
    const currentHour = new Date().getHours();
    if (new Date().getDate() !== new Date(this.appTime).getDate()) {
      this.doctorSchedule[0]?.doctorSchedules.concat(this.doctorSchedule[1]?.doctorSchedules)
      return;
    }
    if (currentHour >= 12) {
      this.doctorSchedule.splice(0, 1);
    }
    
  }

  onSelectSlot(shift: any) {
    if (shift == 1) {
      this.shiftType = true;
      this.isMorningPanelOpen = true;
      this.isEveningPanelOpen = false;
      this.appoinmentForm.controls['appointmentTime_2'].reset();
    } else {
      this.shiftType = false;
      this.isMorningPanelOpen = false;
      this.isEveningPanelOpen = true;
      this.appoinmentForm.controls['appointmentTime_1'].reset();
    }
  }

  createForm() {
    this.appoinmentForm = this.fb.group({
      doctorId: new FormControl(null, [Validators.required]),
      appointmentDate: new FormControl(new Date(), [Validators.required]),
      appointmentTime_1: new FormControl(),
      appointmentTime_2: new FormControl(),
      appoinmentSource: new FormControl(null, [Validators.required]),
      patientId: new FormControl(),
      firstName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      lastName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      primaryContactNo: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      dateOfBirth: new FormControl('',[]),
      email: new FormControl('', [Validators.email
      ]),
      gender: new FormControl('', [Validators.required]),
      discription: new FormControl(''),
      appointmentReason: new FormControl('', [ Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      bloodGroup: new FormControl('', [ Validators.pattern(ConstantsMessage.BLOOD_GROUP)]),
      address1: new FormControl('', [ Validators.pattern(ConstantsMessage.ONLY_ADDRESS)]),
      address2: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_ADDRESS)]),
      city: new FormControl('', [ Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      district: new FormControl('', [,Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      state: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      zipCode: new FormControl('', [Validators.pattern(ConstantsMessage.ZIP_CODE_PATTERN)]),
      familyMemberName: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      contactNumber: new FormControl('', [Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN)]),
      familyPersonDOB: new FormControl('',[]),
      familyMemberGender: new FormControl('', []),
      relationToPatient: new FormControl('', []),
    });
    this.appTime = new Date();
  }

  submitappoinmentForm() {
    if (
      this.appoinmentForm.value.appointmentTime_1 == null &&
      this.appoinmentForm.value.appointmentTime_2 == null
    ) {
      this.toasterService.showError('Error', 'Plese select time slot.');
      return;
    }
    var obj = {
      doctorId: this.appoinmentForm.value.doctorId,
      appointmentDate: this.datepipe.transform(
        this.appoinmentForm?.value.appointmentDate,
        'yyyy-MM-dd'
      ),
      appointmentTime: (this.appoinmentForm.value.appointmentTime_1 == null ? this.appoinmentForm.value.appointmentTime_2.slice(0, 8) : this.appoinmentForm.value.appointmentTime_1.slice(0, 8)),
      appoinmentSource: this.appoinmentForm.value.appoinmentSource,
      patientId: this.appoinmentForm.value.patientId || 0,
      firstName: this.appoinmentForm.value.firstName,
      lastName: this.appoinmentForm.value.lastName,
      primaryContactNo: this.appoinmentForm.value.primaryContactNo,
      dateOfBirth:
        this.datepipe.transform(
          this.appoinmentForm?.value.dateOfBirth,
          'yyyy-MM-dd'
        ) || null,
      email: this.appoinmentForm.value.email,
      gender: Number(this.appoinmentForm.value.gender) || 0,
      discription: this.appoinmentForm.value.discription,
      appointmentReason: this.appoinmentForm.value.appointmentReason,
      bloodGroup: this.appoinmentForm.value.bloodGroup,
      address1: this.appoinmentForm.value.address1,
      address2: this.appoinmentForm.value.address2,
      city: this.appoinmentForm.value.city,
      district: this.appoinmentForm.value.district,
      state: this.appoinmentForm.value.state,
      zipCode: this.appoinmentForm.value.zipCode,
      familyMemberName: this.appoinmentForm.value.familyMemberName,
      contactNumber: this.appoinmentForm.value.contactNumber,
      familyPersonDOB:
        this.datepipe.transform(
          this.appoinmentForm?.value.familyPersonDOB,
          'yyyy-MM-dd'
        ) || null,
      familyMemberGender: Number(this.appoinmentForm.value.familyMemberGender) || 0,
      relationToPatient: Number(this.appoinmentForm.value.relationToPatient) || 0,
    };
    this.appoinmentService.createAppoinment(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(
          ConstantsMessage.APPOINMENT_CONFIRM,
          ''
        );
        this.router.navigate(['pages/admin/appointment']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }

  submitManageForm() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CONFIRM,
        message: ConstantsMessage.CREATE_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
    });
  }
}

