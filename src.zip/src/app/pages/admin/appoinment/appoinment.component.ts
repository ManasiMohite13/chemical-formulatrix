import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import dayGridPlugin from '@fullcalendar/daygrid';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import {
  CalendarOptions,
  DateSelectArg,
  EventClickArg,
  EventApi,
  Calendar,
} from '@fullcalendar/core';
import interactionPlugin from '@fullcalendar/interaction';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { DatePipe } from '@angular/common';
import { FullCalendarComponent } from '@fullcalendar/angular';
import { AuthService } from 'src/app/shared/services/auth.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { el } from 'date-fns/locale';
@Component({
  selector: 'app-appoinment',
  templateUrl: './appoinment.component.html',
  styleUrls: ['./appoinment.component.scss'],
})
export class AppoinmentComponent {
  @ViewChild('calendar') calendarComponent!: FullCalendarComponent;
  calendarApi!: Calendar;

  appoinmentForm!: FormGroup;
  statusList: any = [
    { id: 3, status: 'Visited ' },
    { id: 2, status: 'Cancelled' },
    { id: 1, status: 'Booked' },
  ];
  isListView = true; // Initial view is the listing view
  userProfile: boolean = true;
  userChangePassword: boolean = false
  myFlagForSlideToggle: boolean = false;

  tooltipMessage = 'purposeOfAppointment';
  showTooltip = true;
  weekStart!: Date;
  weekEnd!: Date;
  hospitalList: any;
  hospitalData: any;
  roleId: any
  constructor(
    private formBuilder: FormBuilder,
    private appoinmentService: AppoinmentService,
    private authservice: AuthService,
    private router: Router,
    private dialog: MatDialog,
    private toasterService: ToasterService,
    public datepipe: DatePipe,
    private hospitalService: HospitalService,
    private httpService: HttpService,
    private doctorService: DoctorService
  ) {
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));

    this.createForm();
    this.getHospitalList();
  }

  calendarOptions: CalendarOptions = {
    plugins: [interactionPlugin, dayGridPlugin, timeGridPlugin, listPlugin],
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'timeGridWeek,dayGridMonth,timeGridDay,listWeek',
    },
    initialView: 'timeGridWeek',
    contentHeight: 'auto',
    weekends: true,
    editable: true,
    selectable: true,
    selectMirror: true,
    dayMaxEvents: true,
    // select: this.handleDateSelect.bind(this),
    eventClick: this.handleEventClick.bind(this),
    //eventsSet: this.handleEvents.bind(this),

    customButtons: {
      prev: {
        click: this.prevWeek.bind(this),
      },
      next: {
        click: this.nextWeek.bind(this),
      }
    },
  };

  handleErrorMessage() {
    this.tooltipMessage = 'Error: Something went wrong!';
    this.showTooltip = true;
  }

  prevWeek() {
    var startDate = new Date();
    this.calendarApi = this.calendarComponent.getApi();
    this.calendarApi.prev();

    var start = this.appoinmentForm.controls['fromDate'].value;
    var end = this.appoinmentForm.controls['toDate'].value;

    var newWeekStart = new Date(start);
    var newWeekEnd = new Date(end);

    if (this.calendarApi.view.type === 'timeGridDay') {

      newWeekStart.setDate(newWeekStart.getDate() - 1);
      newWeekEnd = newWeekStart;

      if (new Date(newWeekStart.getFullYear(), newWeekStart.getMonth(), newWeekStart.getDate()) >= new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate())) {
        this.appoinmentForm.controls['fromDate'].setValue(newWeekStart);
        this.appoinmentForm.controls['toDate'].setValue(newWeekEnd);
      }

    } else if (this.calendarApi.view.type === 'timeGridWeek' || this.calendarApi.view.type === 'listWeek') {

      newWeekStart.setDate(newWeekStart.getDate() - 1);
      newWeekStart.setFullYear(newWeekStart.getFullYear());
      newWeekStart.setMonth(newWeekStart.getMonth());
      newWeekStart.setDate(newWeekStart.getDate() - newWeekStart.getDay());
      newWeekEnd.setDate(newWeekStart.getDate() + (6 - newWeekStart.getDay()));

      if (new Date(newWeekEnd.getFullYear(), newWeekEnd.getMonth(), newWeekEnd.getDate()) >= new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate())) {
        this.appoinmentForm.controls['fromDate'].setValue(newWeekStart);
        this.appoinmentForm.controls['toDate'].setValue(newWeekEnd);
      }

    } else if (this.calendarApi.view.type === 'dayGridMonth') {

      var y = newWeekStart.getFullYear(), m = newWeekStart.getMonth() - 1;
      newWeekStart = new Date(y, m, 1);
      newWeekEnd = new Date(y, m + 1, 0);

      if (new Date(newWeekEnd.getFullYear(), newWeekEnd.getMonth(), newWeekEnd.getDate()) >= new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate())) {
        this.appoinmentForm.controls['fromDate'].setValue(newWeekStart);
        this.appoinmentForm.controls['toDate'].setValue(newWeekEnd);
      }
    }
    this.getAppoinment();
  }

  nextWeek() {
    var startDate = new Date();
    this.calendarApi = this.calendarComponent.getApi();

    var start = this.appoinmentForm.controls['fromDate'].value;
    var end = this.appoinmentForm.controls['toDate'].value;

    var newWeekStart = new Date(start);
    var newWeekEnd = new Date(end);

    if (this.calendarApi.view.type === 'timeGridDay') {

      newWeekStart.setDate((newWeekStart > startDate ? newWeekStart.getDate() : startDate.getDate()) + 1);
      newWeekEnd = newWeekStart;

    } else if (this.calendarApi.view.type === 'timeGridWeek' || this.calendarApi.view.type === 'listWeek') {

      newWeekEnd.setDate(newWeekEnd.getDate() + 1);
      newWeekStart.setFullYear(newWeekEnd.getFullYear());
      newWeekStart.setMonth(newWeekEnd.getMonth());
      newWeekStart.setDate(newWeekEnd.getDate() - newWeekEnd.getDay());
      newWeekEnd.setDate(newWeekEnd.getDate() + (6 - newWeekEnd.getDay()));

    } else if (this.calendarApi.view.type === 'dayGridMonth') {

      var y = newWeekStart.getFullYear(), m = newWeekStart.getMonth() + 1;
      newWeekStart = new Date(y, m, 1);
      newWeekEnd = new Date(y, m + 1, 0);

    }

    if (newWeekStart >= startDate) {
      this.appoinmentForm.controls['fromDate'].setValue(newWeekStart);
      this.appoinmentForm.controls['toDate'].setValue(newWeekEnd);
    }
    this.calendarApi.gotoDate(newWeekStart);
    this.getAppoinment();
  }

  ngAfterViewInit() {
    this.calendarApi = this.calendarComponent.getApi();
    this.weekStart = new Date();
    this.weekEnd = new Date();
    this.weekStart.setDate(this.weekStart.getDate() - this.weekStart.getDay());
    this.weekEnd.setDate(this.weekStart.getDate() + (6 - this.weekStart.getDay()));
    this.appoinmentForm.controls['fromDate'].setValue(this.weekStart);
    this.appoinmentForm.controls['toDate'].setValue(this.weekEnd);
    this.getAppoinment();
  }

  resetForm() {
    this.appoinmentForm.reset();
    this.createForm();
  }

  onTabChange(tabNo: any) {
    if (tabNo == 0) {
      this.userProfile = true;
      this.userChangePassword = false;
    } else if (tabNo == 1) {
      this.userChangePassword = true;
      this.userProfile = false;
    }

  }

  createForm() {
    this.appoinmentForm = this.formBuilder.group({
      fromDate: [this.datepipe.transform(this.weekStart, 'yyyy-MM-dd')],
      toDate: [this.datepipe.transform(this.weekEnd, 'yyyy-MM-dd')],
      status: new FormControl(1),
      doctorId: new FormControl(),
    });
  }

  toggleView() {
    this.isListView = !this.isListView;
  }

  addAppoinment() {
    this.router.navigate(['pages/admin/appointment/add-appointment']);
  }

  changeHospital(event: any) {
    this.hospitalData = event;

  }

  getHospitalList() {
    let obj = {
      tenantId: '08db9fb7-9d0d-4cfe-8f9b-ffb485e75af7'
    }
    this.doctorService.getDoctorListByTenantId(obj).subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }

  getAppoinment(): void {
    var startDate = new Date();
    if (this.appoinmentForm?.value.fromDate > startDate) {
      startDate = this.appoinmentForm?.value.fromDate;
    }

    let obj = {
      doctorId: this.appoinmentForm.value.doctorId,
      fromDate: this.datepipe.transform(startDate, 'yyyy-MM-dd'),
      toDate: this.datepipe.transform(this.appoinmentForm?.value.toDate, 'yyyy-MM-dd'),
      status: this.appoinmentForm.value.status || 1,
    };
    this.appoinmentService.getAppoinmentList(obj).subscribe((res: any) => {
      if (res.success) {
        this.calendarOptions.events = res.result.map((evt: any) => {
          let backgroundColor = evt.status === 1 ? 'var(--fc-event-border-color)' : 'red';
          let tooltipMessage = evt.purposeOfAppointment;

          if (evt.status === 2) {
            tooltipMessage = evt.purposeOfAppointment;
          }

          return {
            id: evt.id,
            patientId: evt.patientId,
            date: evt.start,
            title: evt.title,
            specilityId:evt.specilityId,
            backgroundColor: backgroundColor,
            extendedProps: { doctorName: evt.doctorName, tooltipMessage: tooltipMessage }
          };
        });
        this.calendarApi.gotoDate(obj.fromDate || '');
      }
    });
  }

  openCancelConfirmation() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CANCEL_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.CANCEL_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        let obj = {
          id: this.appoinmentForm.value.fromDate,
        };
        this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(
              ConstantsMessage.APPOINMENT_CANCEL,
              ''
            );
          }
        });
        this.router.navigate(['pages/admin/appointment']);
      }
    });
  }

  handleCalendarToggle() { }

  handleDateSelect(selectInfo: DateSelectArg) { }

  handleEventClick(clickInfo: EventClickArg) {
    this.authservice.encryptKey('patientId', clickInfo.event._def.extendedProps['patientId']);
    this.authservice.encryptKey('eventId', clickInfo.event.id);
    this.authservice.encryptKey('specilityId', clickInfo.event._def.extendedProps['specilityId']);

    this.router.navigate(['pages/admin/patient/patient-card']);
  }

  handleEvents(events: EventApi[]) { }
}
