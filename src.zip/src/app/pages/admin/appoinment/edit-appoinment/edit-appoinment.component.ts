import { DatePipe } from '@angular/common';
import { AfterViewInit, ChangeDetectorRef, Component, Input } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import * as moment from 'moment';
import { extendMoment } from 'moment-range';
import { HttpService } from 'src/app/shared/services/http.service';
import { AuthService } from 'src/app/shared/services/auth.service';

@Component({
  selector: 'app-edit-appoinment',
  templateUrl: './edit-appoinment.component.html',
  styleUrls: ['./edit-appoinment.component.scss']
})
export class EditAppoinmentComponent {

  rangeMoment = extendMoment(moment);
  updateappoinmentForm!: FormGroup;
  timeslots: any[] = [];
  doctorlist: any;
  patientList: any;
  drId: any;
  appTime: any;
  shiftType: boolean = true;
  doctorId: any;
  roleId: any;
  doctorSchedule: any = [];
  minDate = new Date();
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];

  appoinmentsSources: any = [
    { id: 1, source: 'Phone' },
    { id: 2, source: 'Web' },
    { id: 3, source: 'Personal Visit' },
  ];
  appoinmentData:any
  @Input() max: any;
  tomorrow = new Date();
  existingPatient: boolean = false;
  newPatientList: boolean = true;
  timesSlot: boolean = false;
  selectedDoctor: any;
  verifyCode: any;
  verificationId:any;
  tentantId='00000000-0000-0000-0000-000000000000';
  currentSelectedSlot: any = {
    "id": null,
    "doctorId": null,
    "frequency": "",
    "shift": null,
    "startDateTime": "",
    "endDateTime": "",
    "selectedSlot": {
      doctorSlotTime: null,
      isBooked: 0
    },
    "doctorSchedules": []
  }
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private doctorService: DoctorService,
    private patientService: PatientService,
    private httpService: HttpService,
    private appoinmentService: AppoinmentService,
    public datepipe: DatePipe,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService
  ) {
    this.getAppoinment();
    // this.verifyCode = this.route.snapshot.paramMap.get('verificationId');
        this.route.paramMap.subscribe((params: ParamMap) => {
        this.verificationId = params.get('verificationId');
        console.log('verificationId:', this.verificationId);
      });
    this.tomorrow.setDate(this.tomorrow.getDate() + 0);

    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.createForm();
    this.getDoctorList();
    this.appoinmentById();
    this.getPatientList();
   
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }
  getAppoinment() {
    return new Promise((reslove,reject)=>{
      if (this.drId && this.appTime) {
        let obj = {
          doctorId: this.drId,
          appointmentDate: this.datepipe.transform(this.appTime, 'yyyy-MM-dd'),
        };
        this.doctorService.getDoctorScheduleList(obj).subscribe((res: any) => {
          if (res.success) {
            this.doctorSchedule = res.result;
            reslove(this.doctorSchedule)
          }
        });
      }

    })
    
  }
   getDoctorList(){
    this.doctorService.doctorListByHospitals().subscribe((res: any) => {
      if (res.success) {
        this.doctorlist = res.result;
        if (this.roleId == 3) {
          this.selectedDoctor = this.doctorlist[0].doctorId;
          this.drId = this.selectedDoctor;
          this.getAppoinment();
        }
      }
    });
  }
  getPatientList() {
    this.patientService.getPatientListByHospitals().subscribe((res: any) => {
      if (res.success) {
        this.patientList = res.result;
        console.log(' this.patientList', this.patientList);
        }
    });
  }
  resetappoinmentForm() {
    const doctorId = this.updateappoinmentForm.get('doctorId')?.value
    this.updateappoinmentForm.reset();
    this.updateappoinmentForm.get('doctorId')?.setValue(doctorId);
  }
  back(){
    this.router.navigate(['/pages/admin/appointment'])
  }
  changeTime(event: any) {
    this.drId = event;
    this.getAppoinment();

  }
  onChangeAppDate(event: any) {
    this.appTime = event.value;
    this.getAppoinment();

  }
  onSelectSlot(shift: any) {
    if (shift == 1) {
      this.shiftType = true;
      this.updateappoinmentForm.controls['appointmentTime_2'].reset();
    } else {
      this.shiftType = false;
      this.updateappoinmentForm.controls['appointmentTime_1'].reset();
    }
  } 


  getCurrentSelectedSlot() {
    const doctorScheduleList = Object.assign(this.doctorSchedule);
    const currentData = this.updateappoinmentForm.getRawValue();

    const currentShift = doctorScheduleList.find((e: any) => {
      const shiftStartDateTime = new Date(e.startDateTime);
      const endDateTime = new Date(e.endDateTime);
      const currentDateTime = new Date(currentData.appointmentDate);
      if (shiftStartDateTime.toString() == currentDateTime.toString() || endDateTime.toString() == currentDateTime.toString()) {
        return e;
      } else if (shiftStartDateTime < currentDateTime && endDateTime > currentDateTime) {
        return e;
      } else {
        return null;
      }
    });
    return currentShift;
  }

  tConvert(date: any) {
    var dt = new Date(date);
    var hours = dt.getHours(); // gives the value in 24 hours format
    var AmOrPm = hours >= 12 ? 'PM' : 'AM';
    hours = (hours % 12) || 12;
    var minutes = dt.getMinutes();
    var finalTime = (hours.toString().length == 1 ? '0' + hours : hours) + ":" + minutes + " " + AmOrPm;
    return finalTime; // return adjusted time or original string
  }


  appoinmentById(){
    let obj = {
      id :this.verificationId,
    }
    this.appoinmentService.getAppoinmentById(obj).subscribe((res:any)=>{
      if(res.success){
        this.appoinmentData = res.result;
        this.updateappoinmentForm.patchValue({

          id:this.appoinmentData.id,
          doctorName:this.appoinmentData.doctorName,
          patientName:this.appoinmentData.patientName,
          doctorId:this.appoinmentData.doctorId,
          appointmentDate:this.appoinmentData.appointmentDate,
          patientId:this.appoinmentData.patientId,
          status:this.appoinmentData.status,
        });
        this.appTime=new Date(this.appoinmentData.appointmentDate)
        this.getAppoinment().then((r)=>{

          this.currentSelectedSlot = this.getCurrentSelectedSlot();
          const currentSlotOfAppointment = this.tConvert(this.updateappoinmentForm.getRawValue().appointmentDate);
      
          const currentSlot = this.currentSelectedSlot.doctorSchedules.find((e: any) => {
            const slt = e.doctorSlotTime.split('To');
            return slt[0].includes(currentSlotOfAppointment);
          });
          this.currentSelectedSlot.selectedSlot = currentSlot;
      
          console.log('Main form data: ', this.appoinmentData);
          console.log('All slots list : ', this.doctorSchedule);
          console.log('currentSlot : ', this.currentSelectedSlot);
          console.log('currentSlot Time : ', currentSlotOfAppointment);
          console.log('selected slot time : ', currentSlot);
          console.log('final Object : ', this.currentSelectedSlot);
            
        })
      } 
    })
  }
  createForm() {
    this.updateappoinmentForm = this.fb.group({
      id:new FormControl(),
      doctorId: new FormControl(null),
      appointmentDate: new FormControl(new Date()),
      appointmentTime:new FormControl(),
      appointmentTime_1: new FormControl(),
      appointmentTime_2: new FormControl(),
      patientId: new FormControl(),
      status:new FormControl(),
      appointmentSource:new FormControl(),
    });
    // this.appTime = new Date();
  }

  submitappoinmentForm() {
    var obj = {
      id:this.updateappoinmentForm.value.id,
      doctorId: this.updateappoinmentForm.value.doctorId,
      appointmentDate: this.datepipe.transform(this.updateappoinmentForm?.value.appointmentDate,'yyyy-MM-dd'),
      appointmentTime: (this.updateappoinmentForm.value.appointmentTime_1 == null?this.updateappoinmentForm.value.appointmentTime_2.slice(0, 8) : this.updateappoinmentForm.value.appointmentTime_1.slice(0, 8)),
     
      patientId: this.updateappoinmentForm.value.patientId || 0,
      status:this.updateappoinmentForm.value.status || 0,
    };

    this.appoinmentService.updateAppoinment(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(
          ConstantsMessage.APPOINMENT_UPDATE,
          ''
        );
        this.router.navigate(['pages/admin/appointment']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
}

