import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { RoleService } from 'src/app/shared/services/role.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.scss']
})
export class AddRoleComponent {
  addRoleForm!: FormGroup;
  @Input() max: any;
  statusList: any = [
    { id: 1, status: 'Active'},
    { id: 2, status: 'InActive'}

  ];
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private hospitalService: HospitalService,
    private httpService: HttpService,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    private roleService:RoleService,
  ) {
    this.createForm();
  }
  createForm() {
    this.addRoleForm = this.fb.group({
      roleName: new FormControl('', [Validators.required,Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      status: new FormControl('', [ Validators.required]),
      roleDescription: new FormControl('', [Validators.required, Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),]),
    });
  }

  submitRoleForm() {
    var obj = {
      roleName: this.addRoleForm.value.roleName,
      status: this.addRoleForm.value.status,
      roleDescription: this.addRoleForm.value.roleDescription
    };
    this.roleService.createRole(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.CREATE_ROLE, '');
        this.router.navigate(['pages/admin/role']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
  resetRoleForm() {
    this.router.navigate(['/pages/admin/role'])
  }
}
