import { ChangeDetectorRef, Component, Inject, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatOption } from '@angular/material/core';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelect } from '@angular/material/select';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { HttpService } from 'src/app/shared/services/http.service';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { MenuService } from 'src/app/shared/services/menu.service';
import { RoleService } from 'src/app/shared/services/role.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { UserService } from 'src/app/shared/services/user.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';


@Component({
  selector: 'app-manage-permission',
  templateUrl: './manage-permission.component.html',
  styleUrls: ['./manage-permission.component.scss']
})
export class ManagePermissionComponent {
  managePermissionForm!: FormGroup;
  id: any;
  roleData: any;
  allSelected = false;
  managePermissionsArray: any = [];
  tempRoleData: any;
  roleId: any;
  menuList: any = [];
  rolePermissionData: any;
  menuListData: any;
  loader: boolean = true
  @ViewChild('select') private select!: MatCheckbox;
  permissionList: any = [
    { id: 1, name: 'Full Control', isChecked: '', key: 'isFullControl' },
    { id: 2, name: 'Add', isChecked: '', key: 'isAdd' },
    { id: 3, name: 'Edit', isChecked: '', key: 'isEdit' },
    { id: 4, name: 'Delete', isChecked: '', key: 'isDelete' },
    { id: 5, name: 'View', isChecked: '', key: 'isView' }
  ];
  menuMasterData: any;
  // displayedColumns: string[] = ['menuName', 'isFullControl', 'isAdd', 'isEdit', 'isDelete', 'isView'];
  // public dataSource = new MatTableDataSource<any>(this.menuList);

  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();

  constructor(private fb: FormBuilder, private httpService: HttpService, private dialog: MatDialog, private router: Router, private toasterService: ToasterService, private userService: UserService, private loaderService: LoaderService, private roleService: RoleService, private menuService: MenuService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.getMenuMasterList();
    if (this.id != '') {
      const obj = {
        id: Number(this.httpService.getDecryptedValue('roleId')),
      };
    }
    this.createForm();
    this.loaderService.isSpinnerShow.next(true);
    this.getAllMenuAccess().then((resp: any) => {
      this.getRolePermissionById(resp);
    });
  }

  getAllMenuAccess() {
    return new Promise((resolve, reject) => {
      this.menuService.getMenuMasterList().subscribe((res: any) => {
        if (res.success) {
          if (res.result.length > 0) {
            resolve(res.result);
          } else {
            resolve([]);
          }
        }
      });
    });
  }

  // getRolePermissionById(allMenus: any[]) {
  //   this.roleService.getRolePermissionById({id:this.data.roleId}).subscribe((res: any) => {
  //     if (res.success) {
  //       this.loaderService.isSpinnerShow.next(false);
  //       const allMenusCanAccess: any[] = allMenus.map((ele: any,index: number)=>({
  //           id:0,
  //           menuName:ele.menuName,
  //           menuId:ele.menuId,
  //           roleId:this.data.roleId,
  //           isFullControl:false,
  //           isAdd:false,
  //           isEdit:false,
  //           isView:false,
  //           isDelete:false,
  //         }));

  //       if (res.result.length > 0) {
  //         allMenusCanAccess.forEach((element)=>{
  //           res.result.forEach((ele:any) => {
  //             if(ele.menuId === element.menuId) {
  //               element.id= ele.id;
  //               element.isFullControl = ele.isFullControl;
  //               element.isAdd = ele.isAdd;
  //               element.isEdit = ele.isEdit;
  //               element.isView = ele.isView;
  //               element.isDelete = ele.isDelete;

  //             }

  //           });
  //           this.menuList.push(element);
  //         });
  //         return;
  //       }
  //       this.menuList = allMenusCanAccess;
  //     }
  //     if (this.data.roleId === 1) {
  //       this.menuList.forEach((element) => {
  //         element.isFullControl = true;
  //         element.isAdd = true;
  //         element.isEdit = true;
  //         element.isView = true;
  //         element.isDelete = true;
  //       });
  //     }
  //   });
  // }

  getRolePermissionById(allMenus: any[]) {
    this.roleService.getRolePermissionById({ id: this.data.roleId }).subscribe((res: any) => {
      if (res.success) {
        this.loaderService.isSpinnerShow.next(false);
        const allMenusCanAccess: any[] = allMenus.map((ele: any, index: number) => ({
          id: 0,
          menuName: ele.menuName,
          menuId: ele.menuId,
          roleId: this.data.roleId,
          isFullControl: false,
          isAdd: false,
          isEdit: false,
          isView: false,
          isDelete: false,
        }));
        if (res.result.length > 0) {
          allMenusCanAccess.forEach((element) => {
            res.result.forEach((ele: any) => {
              if (ele.menuId === element.menuId) {
                element.id = ele.id;
                element.isFullControl = ele.isFullControl;
                element.isAdd = ele.isAdd;
                element.isEdit = ele.isEdit;
                element.isView = ele.isView;
                element.isDelete = ele.isDelete;
              }
            });
            this.menuList.push(element);
          });
        } else {
          this.menuList = allMenusCanAccess;
        }
        if (this.data.roleId === 1) {
          this.menuList.forEach((element) => {
            element.isFullControl = true;
            element.isAdd = true;
            element.isEdit = true;
            element.isView = true;
            element.isDelete = true;
          });
        }
      }
    });
  }
  createForm() {
    this.managePermissionForm = this.fb.group({
    });
  }

  // checkboxClick(i: number,keyToChange: string) {
  //   if (keyToChange == 'isFullControl') {
  //       this.menuList[i].isAdd=this.menuList[i].isEdit=this.menuList[i].isDelete=this.menuList[i].isView = this.menuList[i][keyToChange];
  //     return;
  //   }

  //   const isAllChecked = this.menuList[i].isAdd && this.menuList[i].isEdit&& this.menuList[i].isDelete&& this.menuList[i].isView;
  //   this.menuList[i].isFullControl = isAllChecked;
  // }

  checkboxClick(i: number, keyToChange: string) {
    if (keyToChange == 'isFullControl') {
      this.menuList[i].isAdd = this.menuList[i].isEdit = this.menuList[i].isDelete = this.menuList[i].isView = this.menuList[i][keyToChange];
      return;
    }
    const isAddAndEditSelected = this.menuList[i].isAdd && this.menuList[i].isEdit;
    if (isAddAndEditSelected) {
      this.menuList[i].isView = true;
    } else {
      this.menuList[i].isView = false;
    }
    const isAllChecked = this.menuList[i].isAdd && this.menuList[i].isEdit && this.menuList[i].isDelete && this.menuList[i].isView;
    this.menuList[i].isFullControl = isAllChecked;
  }


  submitManageForm() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CONFIRM,
        message: ConstantsMessage.CREATE_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        let obj: any[] = [];
        Object.assign(obj, this.menuList);
        obj = obj.map((e) => {
          delete e.menuName;
          return e;
        })
        this.roleService.updateRolePermission(obj).subscribe((res: any) => {
          if (res.success) {
            if (obj.length > 0) {
              if(obj[0].id==0){
                this.toasterService.showSuccess(
                  ConstantsMessage.CREATE_ROLE_PERMISSION, '');
              }
              else {
                this.toasterService.showSuccess(
                  ConstantsMessage.UPDATE_ROLE_PERMISSION,
                  ''
                );
              }
            }
            // this.getMenuMasterList()
            this.dialog.closeAll();
            this.router.navigate(['pages/admin/role'])

          }
        });

      }
    });
  }


  getMenuMasterList() {
    this.menuService.getMenuMasterList().subscribe((res: any) => {
      if (res.success) {
        this.menuMasterData = res.result;
        console.log('menuMasterData', this.menuMasterData);
      }
    })
  }
  areAnyCheckboxesSelected(): boolean {
    return this.menuList.some((menu) => menu.isFullControl || menu.isAdd || menu.isEdit || menu.isDelete || menu.isView);
  }
}

export interface displayedColumns {
  id: number;
  roleName: string;
  description: string;
  status: number;
}
let roleData: displayedColumns[];
