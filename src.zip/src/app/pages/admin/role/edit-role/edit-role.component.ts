import { ChangeDetectorRef, Component ,Inject} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/shared/services/http.service';
import { RoleService } from 'src/app/shared/services/role.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

@Component({
  selector: 'app-edit-role',
  templateUrl: './edit-role.component.html',
  styleUrls: ['./edit-role.component.scss']
})
export class EditRoleComponent {

  updateRoleForm!: FormGroup;
  statusList: any = [
    { id: 1, status: 'Active'},
    { id: 2, status: 'InActive'}

  ];
  id:any;
  roleData:any
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private httpService: HttpService,
    private toasterService: ToasterService,
    private roleService:RoleService,
    public fd: ChangeDetectorRef,
    @Inject(MAT_DIALOG_DATA) public data:any,

  ) {
    this.createForm();
    this.updateRoleForm.patchValue(this.data);
  }
  createForm() {
    this.updateRoleForm = this.fb.group({
      id:new FormControl(),
      roleName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      status: new FormControl('', [ Validators.required
      ]),
      roleDescription: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      
    });
  }

  submitRoleForm() {
    var obj = {
      id:this.updateRoleForm.value.id,
      roleName: this.updateRoleForm.value.roleName,
      status: this.updateRoleForm.value.status,
      roleDescription: this.updateRoleForm.value.roleDescription
    };
    this.roleService.updateRole(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.UPDATE_ROLE, '');
        this.router.navigate(['pages/admin/role']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
  
  
  resetLaboratoryForm() {
    this.router.navigate(['/pages/admin/laboratory'])
  }
}

