import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { LaboratoryService } from 'src/app/shared/services/laboratory.service';
import { ConfirmDailogComponent } from '../../common/confirm-dailog/confirm-dailog.component';
import { EditRoleComponent } from './edit-role/edit-role.component';
import { AddRoleComponent } from './add-role/add-role.component';
import { RoleService } from 'src/app/shared/services/role.service';
import { ManagePermissionComponent } from './manage-permission/manage-permission.component';

function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.scss']
})
export class RoleComponent {
  pageSizeTemp: any;
  totalRowCount = 0;
  displayedColumns: string[] = [
    'roleName',
    'roleDescription',
    'status',
    'Action',
  ];
  roleForm!: FormGroup;
  tempRoleData: any;
  roleData: any = [];
  public dataSource = new MatTableDataSource(roleData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();

  constructor(
    private router: Router,
    private dialogRef: MatDialog,
    private formBuilder: FormBuilder,
    private authservice: AuthService,
    private roleService:RoleService,
  ) {
    this.createForm();
    this.getRoleList();
    }

  resetForm() {
    this.roleForm.reset();
    this.createForm();
  }

  createForm() {
    this.roleForm = this.formBuilder.group({
      laboratoryName: new FormControl(''),

    });
  }

  getRoleList() {
        this.roleService.getRoleList().subscribe((res: any) => {
          if (res.success) {
            roleData = res.result;
            this.tempRoleData = res.result;
            if (res.result.length > 0) {
              this.dataSource = new MatTableDataSource(roleData);
            } else {
              this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
              this.dataSource = new MatTableDataSource(roleData);
            }
        this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;

            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
          }
      });
  }
  editRole(roleId: any) {
    this.authservice.encryptKey('roleId', roleId);
    const confirmDialog = this.dialogRef.open(EditRoleComponent, {
      width: '700px',
      disableClose: true,
      data:roleId
    });
    confirmDialog.afterClosed().subscribe((result) => {
      this.getRoleList();
      this.getRoleList()
      if (result === true) {
        this.router.navigate(['pages/admin/role']);
      }
    });

  }

  addRole() {
    const confirmDialog = this.dialogRef.open(AddRoleComponent, {
      width: '700px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      this.getRoleList()
      if (result === true) {
      this.getRoleList()

        this.router.navigate(['pages/admin/role']);
      }
    });
  }
  managePermission(roleId:any,roleName:any){
  
    const confirmDialog = this.dialogRef.open(ManagePermissionComponent, {
      width: '700px',
      disableClose: true,
      data:{roleId,roleName},
    });
    confirmDialog.afterClosed().subscribe((result) => {
      this.getRoleList()
      if (result === true) {
      this.getRoleList()

        this.router.navigate(['pages/admin/role']);
      }
    });

  }
    applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
}
export interface displayedColumns {
  id:number,
  roleName: string;
  roleDescription: string;
  status:number;
}
let roleData: displayedColumns[];
