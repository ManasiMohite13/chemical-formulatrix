import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { AddAppoinmentComponent } from './appoinment/add-appoinment/add-appoinment.component';
import { AppoinmentComponent } from './appoinment/appoinment.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddDoctorComponent } from './doctors/add-doctor/add-doctor.component';
import { EditDoctorsComponent } from './doctors/edit-doctors/edit-doctors.component';
import { AddHospitalComponent } from './hospital/add-hospital/add-hospital.component';
import { EditHospitalComponent } from './hospital/edit-hospital/edit-hospital.component';
import { HospitalComponent } from './hospital/hospital.component';
import { AddPatientsComponent } from './patients/add-patients/add-patients.component';
import { EditPatientsComponent } from './patients/edit-patients/edit-patients.component';
import { PatientsComponent } from './patients/patients.component';
import { PaymentComponent } from './payment/payment.component';
import { AddRoomComponent } from './room/add-room/add-room.component';
import { EditRoomComponent } from './room/edit-room/edit-room.component';
import { RoomListComponent } from './room/room-list/room-list.component';
import { RoomComponent } from './room/room.component';
import { AddStaffComponent } from './staff/add-staff/add-staff.component';
import { EditStaffComponent } from './staff/edit-staff/edit-staff.component';
import { StaffListComponent } from './staff/staff-list/staff-list.component';
import { StaffComponent } from './staff/staff.component';
import { DoctorsComponent } from './doctors/doctors.component';
import { AuthGuard } from 'src/app/shared/guard/auth.guard';
import { ViewUserComponent } from './user/view-user/view-user.component';
import { AddUserComponent } from './user/add-user/add-user.component';
import { UserComponent } from './user/user.component';
import { PatientProfileComponent } from './patients/patient-profile/patient-profile.component';
import { AddScheduleComponent } from './doctors/add-schedule/add-schedule.component';
import { ViewPatientComponent } from './patients/view-patient/view-patient.component';
import { PatientCardComponent } from './patient-card/patient-card.component';
import { SupportComponent } from './support/support.component';
import { EditSupportComponent } from './support/edit-support/edit-support.component';
import { AddSupportComponent } from './doctors/add-support/add-support.component';
import { AddPatientsSupportComponent } from './patients/add-patients-support/add-patients-support.component';
import { AddReceptionistSupportComponent } from './support/add-receptionist-support/add-receptionist-support.component';
import { LaboratoryComponent } from './laboratory/laboratory.component';
import { AddLaboratoryComponent } from './laboratory/add-laboratory/add-laboratory.component';
import { EditScheduleComponent } from './doctors/edit-schedule/edit-schedule.component';
import { AddRoleComponent } from './role/add-role/add-role.component';
import { RoleComponent } from './role/role.component';
import { EditRoleComponent } from './role/edit-role/edit-role.component';
import { ManagePermissionComponent } from './role/manage-permission/manage-permission.component';
import { EditAppoinmentComponent } from './appoinment/edit-appoinment/edit-appoinment.component';
import { CancelAppoinmentComponent } from './patient-card/cancel-appoinment/cancel-appoinment.component';
import { NotFoundComponent } from '../common/confirm-dailog/404.component';
import { AppointmentListComponent } from './appoinment/appointment-list/appointment-list.component';
import { SpecilityComponent } from './hospital/specility/specility.component';
import { AddSpecilityComponent } from './hospital/specility/add-specility/add-specility.component';
import { ViewPatientAppointmentComponent } from './appoinment/view-patient-appointment/view-patient-appointment.component';
import { ManageFormsComponent } from './manage-forms/manage-forms.component';
import { TransitionByPatientComponent } from './transition-by-patient/transition-by-patient.component';
import { TransitionBySourceComponent } from './transition-by-source/transition-by-source.component';
import { PrintPrescriptionPageComponent } from './patient-card/print-prescription-page/print-prescription-page.component';
import { ManageInventoryComponent } from './manage-inventory/manage-inventory.component';
import { AddInventoryComponent } from './manage-inventory/add-inventory/add-inventory.component';
import { EditInventoryComponent } from './manage-inventory/edit-inventory/edit-inventory.component';
import { PatientBillComponent } from './patient-bill/patient-bill.component';
import { AddNewBillComponent } from './patient-bill/add-new-bill/add-new-bill.component';
import { PrintPatientBillComponent } from './patient-bill/print-patient-bill/print-patient-bill.component';

const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard],

      },

      {
        path: 'appointment',
        component: AppoinmentComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },
      {
        path: 'appointment/appointment-list',
        component: AppointmentListComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },
      {
        path: 'appointment/add-appointment',
        component: AddAppoinmentComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'appointment/edit-appointment/:verificationId',
        component: EditAppoinmentComponent,
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },

      {
        path: 'appointment/view-patient-appointment',
        component: ViewPatientAppointmentComponent,
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },
      {
        path: 'doctor',
        component: DoctorsComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'doctor/add-doctor',
        component: AddDoctorComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'doctor/edit-doctor',
        component: EditDoctorsComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'doctor/add-schedule',
        component: AddScheduleComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'doctor/edit-schedule',
        component: EditScheduleComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'patient',
        component: PatientsComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },
      {
        path: 'patient/add-patient',
        component: AddPatientsComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'patient/edit-patient',
        component: EditPatientsComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'patient/patient-profile',
        component: PatientProfileComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'patient/view-patient',
        component: ViewPatientComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'patient/patient-card',
        component: PatientCardComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },


      },
      {
        path: 'patient/cancel-appoinment/:id',
        component: CancelAppoinmentComponent,
      },
      {
        path: 'room',
        component: RoomComponent,
        canActivate: [AuthGuard],

      },

      {
        path: 'room/room-list',
        component: RoomListComponent,
        canActivate: [AuthGuard],

      },
      {
        path: 'room/add-room',
        component: AddRoomComponent,
        canActivate: [AuthGuard],

      },
      {
        path: 'room/edit-room',
        component: EditRoomComponent,
        canActivate: [AuthGuard],

      },

      {
        path: 'payment',
        component: PaymentComponent,
        canActivate: [AuthGuard],

      },

      {
        path: 'staff/staff-list',
        component: StaffListComponent,
        canActivate: [AuthGuard],

      },
      {
        path: 'staff',
        component: StaffComponent,
        canActivate: [AuthGuard],

      },
      {
        path: 'staff/add-staff',
        component: AddStaffComponent,
        canActivate: [AuthGuard],

      },
      {
        path: 'staff/edit-staff',
        component: EditStaffComponent,
        canActivate: [AuthGuard],

      },
      {
        path: 'hospital',
        component: HospitalComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },
      {
        path: 'hospital/add-hospital',
        component: AddHospitalComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'hospital/edit-hospital',
        component: EditHospitalComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'user',
        component: UserComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },
      {
        path: 'user/add-user',
        component: AddUserComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'user/view-user',
        component: ViewUserComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'support',
        component: SupportComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },
      {
        path: 'support/edit-support',
        component: EditSupportComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'add-support',
        component: AddSupportComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'add-patient-support',
        component: AddPatientsSupportComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'add-receptionist-support',
        component: AddReceptionistSupportComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'laboratory',
        component: LaboratoryComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'add-laboratory',
        component: AddLaboratoryComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'role',
        component: RoleComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'add-role',
        component: AddRoleComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },
      {
        path: 'edit-role',
        component: EditRoleComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },

      },

      {
        path: 'manage-permission',
        component: ManagePermissionComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },

      {
        path: 'manage-speciality',
        component: SpecilityComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },

      {
        path: 'add-speciality',
        component: AddSpecilityComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2, 3, 4, 5],
        },
      },
      {
        path: 'manage-forms',
        component: ManageFormsComponent,
        canActivate: [AuthGuard],

      },
      
      {
        path: 'transition-by-patient',
        component: TransitionByPatientComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [ 2, 3],
        },
      },
      {
        path: 'transition-by-source',
        component: TransitionBySourceComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [ 2, 3],
        },
      },

      {
        path: 'manage-inventory',
        component: ManageInventoryComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [1, 2],
        },
      },
      {
        path: 'add-inventory',
        component: AddInventoryComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [ 1, 2],
        },
      },

      {
        path: 'edit-inventory',
        component: EditInventoryComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [ 1, 2],
        },
      },

      {
        path: 'patient-bill',
        component: PatientBillComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [ 1, 2,3,5],
        },
      },

      {
        path: 'add-new-bill',
        component: AddNewBillComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [ 1,2,3,5],
        },
      },

      {
        path: 'print-bill',
        component: PrintPatientBillComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [ 1,2,3,5],
        },
      },
     

      // {
      //   path: '**',
      //   component: NotFoundComponent,
      //   data: {
      //     title: 'Not Found',
      //     head: 'Page not found',
      //     message: 'The page is deprecated, deleted, or does not exist at all',
      //     status: '404',
      //   },
      // },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule { }
