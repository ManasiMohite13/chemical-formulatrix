import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, Input, Inject, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
@Component({
  selector: 'app-edit-patients',
  templateUrl: './edit-patients.component.html',
  styleUrls: ['./edit-patients.component.scss'],
})
export class EditPatientsComponent {

  updatePatientForm!: FormGroup;
  hospitalList: any;
  roleId: any;
  @Input() max: any;
  tomorrow = new Date();
  id: any;
  patientDeatils: any;
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];
  patientRelation: any = [
    { id: 1, relation: 'Father' },
    { id: 2, relation: 'Mother' },
    { id: 3, relation: 'son' },
    { id: 4, relation: 'Sister' },
    { id: 5, relation: 'Uncle' },
    { id: 6, relation: 'Aunty ' },
    { id: 7, relation: 'Brother ' },
    { id: 8, relation: 'Other ' },];
  constructor(
    private fb: FormBuilder,
    private patientService: PatientService,
    private router: Router,
    private hospitalService: HospitalService,
    private httpService: HttpService,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,

  ) {
    this.tomorrow.setDate(this.tomorrow.getDate() + 0);
    this.createForm();
    if (this.id != '') {
      let obj = {
        id: Number(this.httpService.getDecryptedValue('id')),
      };
      this.getPatientById(obj);
    }
  }

  createForm() {
    this.updatePatientForm = this.fb.group({
      id: new FormControl(1),
      firstName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      lastName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      primaryContactNo: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      dateOfBirth: new FormControl(),
      email: new FormControl('', [
        Validators.required, Validators.email,
      ]),
      // gender:new FormControl(),
      discription: new FormControl('', []),
      // allowPortalLogin: new FormControl(false),

      address1: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_ADDRESS)]),
      address2: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_ADDRESS)]),
      city: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      district: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      state: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      zipCode: new FormControl('', [Validators.pattern(ConstantsMessage.ZIP_CODE_PATTERN)]),
      familyMemberName: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      contactNumber: new FormControl('', [Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN)]),
      familyPersonDOB: new FormControl(''),
      // familyMemberGender:  new FormControl('',[Validators.required]),
      relationToPatient: new FormControl(''),
    });
  }
  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }

  submitPatientForm() {
    const datePipe = new DatePipe('en-US');
    var obj = {
      id: this.updatePatientForm.value.id,
      firstName: this.updatePatientForm.value.firstName,
      lastName: this.updatePatientForm.value.lastName,
      primaryContactNo: this.updatePatientForm.value.primaryContactNo.toString(),
      //dateOfBirth: this.updatePatientForm.value.dateOfBirth,
      email: this.updatePatientForm.value.email,
      gender: this.updatePatientForm.value.gender,
      discription: this.updatePatientForm.value.discription,
      // allowPortalLogin: this.updatePatientForm.value.allowPortalLogin,

      address1: this.updatePatientForm.value.address1,
      address2: this.updatePatientForm.value.address2,
      city: this.updatePatientForm.value.city,
      district: this.updatePatientForm.value.district,
      state: this.updatePatientForm.value.state,
      zipCode: this.updatePatientForm.value.zipCode,
      familyMemberName: this.updatePatientForm.value.familyMemberName,
      contactNumber: this.updatePatientForm.value.contactNumber,
      familyPersonDOB: datePipe.transform(this.updatePatientForm.value.familyPersonDOB, 'yyyy-MM-dd') || null,
      // familyMemberGender: this.updatePatientForm.value.familyMemberGender,
      relationToPatient: this.updatePatientForm.value.relationToPatient || 0,
    };
    this.patientService.upadtePatient(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.PATIENT_UPDATE, '');
        this.router.navigate(['pages/admin/patient']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
  resetPatientForm() {
    this.updatePatientForm.reset();
  }
  back() {
    this.router.navigate(['pages/admin/patient'])

  }

  getPatientById(id: any) {
    this.patientService.getPatientById(id).subscribe((res: any) => {
      this.patientDeatils = res.result;
      this.updatePatientForm.patchValue(this.patientDeatils);
      this.updatePatientForm.patchValue(this.patientDeatils.patientAddress);
      this.updatePatientForm.patchValue(this.patientDeatils.patientFamilyDetail);
    });
  }
}

