import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPatientsSupportComponent } from './add-patients-support.component';

describe('AddPatientsSupportComponent', () => {
  let component: AddPatientsSupportComponent;
  let fixture: ComponentFixture<AddPatientsSupportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddPatientsSupportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddPatientsSupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
