import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDatepicker } from '@angular/material/datepicker';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
@Component({
  selector: 'app-add-patients',
  templateUrl: './add-patients.component.html',
  styleUrls: ['./add-patients.component.scss'],
})
export class AddPatientsComponent implements OnInit {
  addPatientForm!: FormGroup;
  hospitalList: any;
  hospitalListCopy: any = [];
  roleId: any;
  @Input() max: any;
  tomorrow = new Date();
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];

  patientRelation: any = [
    { id: 1, relation: 'Father' },
    { id: 2, relation: 'Mother' },
    { id: 3, relation: 'son' },
    { id: 4, relation: 'Sister' },
    { id: 5, relation: 'Uncle' },
    { id: 6, relation: 'Aunty ' },
    { id: 7, relation: 'Brother ' },
    { id: 8, relation: 'Other ' },];

  statusList: any = [
    { id: 'O+', status: 'O+' },
    { id: 'A+', status: 'A+' },
    { id: 'A-', status: 'A-' },
    { id: 'O-', status: 'O-' },
    { id: 'B+', status: 'B+' },
    { id: 'AB+', status: 'AB+' },
    { id: 'AB-', status: 'AB-' },

  ];
  @ViewChild('picker1') picker1: MatDatepicker<any>;
  constructor(
    private fb: FormBuilder,
    private patientService: PatientService,
    private router: Router,
    private hospitalService: HospitalService,
    private httpService: HttpService,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef
  ) {
    this.tomorrow.setDate(this.tomorrow.getDate() + 0);
    this.createForm();
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.roleId === 2 ? this.getHospitalById() : this.getHospitalList();
  }
  ngOnInit(){
    this.patientRelation.sort((a, b) => a.relation.localeCompare(b.relation));
  }
  getHospitalById() {
    this.hospitalService.getHospitalById(0).subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = [res.result];
        this.hospitalListCopy = this.hospitalList;
        this.addPatientForm.controls['tenantId'].setValue(
          this.hospitalList[0].tenantId
        );
      }
    });
  }

  createForm() {
    this.addPatientForm = this.fb.group({
      firstName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      lastName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      primaryContactNumber: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      dateOFBirth: new FormControl(''),
      email: new FormControl('', [
        Validators.required, Validators.email,
      ]),
      gender: new FormControl(null, [Validators.required]),
      discription: new FormControl('', []),
      allowPortalLogin: new FormControl(false),
      tenantId: new FormControl('', [Validators.required]),

      bloodGroup: new FormControl('', [ Validators.pattern(ConstantsMessage.BLOOD_GROUP)]),
      address1: new FormControl('', [ Validators.pattern(ConstantsMessage.ONLY_ADDRESS)]),
      address2: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_ADDRESS)]),
      city: new FormControl('', [ Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      district: new FormControl('', [ Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      state: new FormControl('', [ Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      zipCode: new FormControl('', [ Validators.pattern(ConstantsMessage.ZIP_CODE_PATTERN)]),
      familyMemberName: new FormControl('', [ Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      contactNumber: new FormControl('', [ Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN)]),
      familyPersonDOB: new FormControl(null),
      familyMemberGender: new FormControl(null),
      relationToPatient: new FormControl(null),
    });
  }
  getHospitalList() {
    this.hospitalService.getHospitalListAsc().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
        this.hospitalListCopy = this.hospitalList;
      }
    });
  }

  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  submitPatientForm() {
    const datePipe = new DatePipe('en-US');
    var obj = {
      firstName: this.addPatientForm.value.firstName,
      lastName: this.addPatientForm.value.lastName,
      primaryContactNo: this.addPatientForm.value.primaryContactNumber.toString(),
      dateOfBirth: datePipe.transform(this.addPatientForm.value.dateOFBirth, 'yyyy-MM-dd')|| null,
      email: this.addPatientForm.value.email,
      gender: this.addPatientForm.value.gender,
      discription: this.addPatientForm.value.discription,
      allowPortalLogin: this.addPatientForm.value.allowPortalLogin,
      tenantId: this.addPatientForm.value.tenantId,

      bloodGroup: this.addPatientForm.value.bloodGroup,
      address1: this.addPatientForm.value.address1,
      address2: this.addPatientForm.value.address2,
      city: this.addPatientForm.value.city,
      district: this.addPatientForm.value.district,
      state: this.addPatientForm.value.state,
      zipCode: this.addPatientForm.value.zipCode,
      familyMemberName: this.addPatientForm.value.familyMemberName,
      contactNumber: this.addPatientForm.value.contactNumber,
      familyPersonDOB: datePipe.transform(this.addPatientForm.value.familyPersonDOB, 'yyyy-MM-dd') || null,
      familyMemberGender: this.addPatientForm.value.familyMemberGender || 0 ,
      relationToPatient: this.addPatientForm.value.relationToPatient || 0, 


    };
    this.patientService.createPatient(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.PATIENT_CREATE, '');
        this.router.navigate(['pages/admin/patient']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
  back() {
    this.router.navigate(['pages/admin/patient'])
  }
  resetPatientForm() {
    this.addPatientForm.reset();
  }
}
