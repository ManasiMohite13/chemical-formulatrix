import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';

function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}

@Component({
  selector: 'app-patients',
  templateUrl: './patients.component.html',
  styleUrls: ['./patients.component.scss'],
})
export class PatientsComponent implements OnInit {
  pageSizeTemp: any;
  totalRowCount = 0;
  firstName: any;
  roleId: any;
  patientForm!: FormGroup;
  public totalPatientRecord = 0;
  displayedColumns: string[] = [
    'firstName',
    'lastName',
    'primaryContactNo',
    'patientNumber',
    'email',
    'gender',
    'Action'
  ];
  patientData: any = [];
  hospitalList: any;
  permissonData: any;
  hospitalListCopy: any = [];
  public dataSource = new MatTableDataSource(employeeData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();

  constructor(
    private patientList: PatientService,
    private hospitalService: HospitalService,
    private router: Router,
    private authService: AuthService,
    private formBuilder: FormBuilder,
    private httpService: HttpService,
  ) {
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.createForm();
    this.getPatientList();
    this.getHospitalList();
    if (this.roleId === 2) {
      this.patientForm.controls['hospitalTenantId'].disable();
    }
  }

  ngOnInit(): void {
    if (this.patientList.selectedHospital) {
      this.patientList.selectedHospital = this.patientForm.controls['hospitalTenantId'].setValue(this.patientList.selectedHospital);
      this.getPatientList();
    }
  }

  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  getHospitalList() {
    this.hospitalService.getHospitalListAsc().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
        this.hospitalListCopy = this.hospitalList;
      }
    });
  }
  sortData(sort: Sort) {
    const data = this.patientData;
    if (!sort.active || sort.direction === '') {
      this.dataSource = data;
      return;
    }
    const isAsc = sort.direction === 'asc';
    var sortedData = data.sort((a: any, b: any) => {
      switch (sort.active) {
        case 'firstName':
          return compareString(a.firstName, b.firstName, isAsc);
        case 'lastName':
          return compareString(a.lastName, b.lastName, isAsc);
        case 'primaryContactNo':
          return compareNumber(a.primaryContactNo, b.primaryContactNo, isAsc);
        case 'patientNumber':
          return compareString(a.patientNumber, b.patientNumber, isAsc);
        case 'email':
          return compareNumber(a.email, b.email, isAsc);
        case 'gender':
          return compareNumber(a.gender, b.gender, isAsc);
        default:
          return 0;
      }
    });
    this.dataSource = new MatTableDataSource(sortedData);
    this.dataSource.paginator = this.paginator;
  }

  resetForm() {
    this.patientForm.reset();
    this.createForm();
    this.getPatientList();

  }

  createForm() {
    this.patientForm = this.formBuilder.group({
      mobileNumber: new FormControl('',[Validators.minLength(9),
        Validators.maxLength(11)]),
      patientFirstName: new FormControl('', []),
      hospitalTenantId: new FormControl('', [Validators.required]),
    });
  }

  getPatientList() {
    if (this.roleId === 1) {
      let obj = {
        pageNumber: this.paginator
          ? this.paginator.pageIndex == 0
            ? 1
            : this.paginator.pageIndex + 1
          : 1,
        pageSize: this.pageSizeTemp || 10,
        mobileNumber: this.patientForm.value.mobileNumber || '',
        patientFirstName: this.patientForm.value.patientFirstName || '',
        patientLastName: '',
        hospitalTenantId:
          this.patientForm.value.hospitalTenantId ||
          '00000000-0000-0000-0000-000000000000',
      };
      this.patientList.getPatientlist(obj).subscribe((res: any) => {
        if (res.success) {
          let patientData = res.result;
          if (res.result.length > 0) {
            this.dataSource = new MatTableDataSource(patientData.patientListResponse);
          } else {
            this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
            this.dataSource = new MatTableDataSource(patientData.patientListResponse);
          }

          this.dataSource.sort = this.sort;
          this.totalRowCount = res.result.rowCount;
        }
      });
    } else {
      let obj = {
        pageNumber: this.paginator
          ? this.paginator.pageIndex == 0
            ? 1
            : this.paginator.pageIndex + 1
          : 1,
        pageSize: this.pageSizeTemp || 10,
        mobileNumber: this.patientForm.value.mobileNumber || '',
        patientFirstName: this.patientForm.value.patientFirstName || '',
        patientLastName: '',
      };
      this.patientList
        .getPatientListByHospitalAdmin(obj)
        .subscribe((res: any) => {
          if (res.success) {
            let patientData = res.result;
            if (res.result.length > 0) {
              this.dataSource = new MatTableDataSource(patientData.patientListResponse);
            } else {
              this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
              this.dataSource = new MatTableDataSource(patientData.patientListResponse);
            }
            this.dataSource.sort = this.sort;
            this.totalRowCount = res.result.rowCount;
          }
        });
    }
  }

  changePaging(event: any) {
    pageNumber: event.pageIndex == 0 ? 1 : event.pageIndex + 1,
      (this.pageSizeTemp = event.pageSize),
      this.getPatientList();
  }
  addPatient() {
    this.router.navigate(['pages/admin/patient/add-patient'])
  }

  editPatient(id: any) {
    this.patientList.selectedHospital = this.patientForm.controls['hospitalTenantId'].value
    this.authService.encryptKey('id', id);
    this.router.navigate(['pages/admin/patient/edit-patient'])

    // const confirmDialog = this.dialogRef.open(EditPatientsComponent, {
    //   width: '650px',
    //   disableClose: true,
    //   data: id

    // });
    // confirmDialog.afterClosed().subscribe((result) => {
    //   if (result === true) {
    //     this.router.navigate(['pages/admin/patient']);
    //     this.getPatientList();
    //   }
    // });

  }

  applyFilter(filterValue: string) {
    this.firstName = filterValue;
    this.getPatientList();
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
}
export interface displayedColumns {
  id: number;
  firstName: string;
  lastName: string;
  primaryContactNo: number;
  patientNumber: string;
  email: number;
  gender: number;
}
let employeeData: displayedColumns[];
