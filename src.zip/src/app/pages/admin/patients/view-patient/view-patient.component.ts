import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelect } from '@angular/material/select';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { AppConfigService } from 'src/app/shared/services/common/app-config.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}
@Component({
  selector: 'app-view-patient',
  templateUrl: './view-patient.component.html',
  styleUrls: ['./view-patient.component.scss'],
})
export class ViewPatientComponent {
  patientAttributeData: string[] = ['weight', 'height'];
  patientDocumentsData: string[] = [
    'referenceId',
    'documentTypeId',
    'documentName',
    'documentPath',
    'patientAppointmentId',
  ];
  patientDrugsMasterData: string[] = [
    'day',
    'shift',
    'drugName',
    'quantity',
    'uom',
    'appointmentDateTime',
    'doctorName',
    'createDate',
  ];
  patientExaminationData: string[] = [
    'bloodPressure',
    'fever',
    'patientHistory',
    'recommandedTest',
    'doctorName',
    'appointMentTime',
    'createDate',
  ];
  patientFamilyDetailData: string[] = [
    'familyMemberName',
    'relationToPatient',
    'familyPersonDateOfBirth',
    'gender',
    'familyContactNo',
  ];
  tempatientAttributeD: any;
  tempatientDocumentsData: any;
  tempatientDrugsMaster: any;
  tempatientExaminationData: any;
  appoinmentId: any;
  tempatientFamilyDetailData: any;
  public dataSource = new MatTableDataSource(patientAttributeD);
  public dataSource1 = new MatTableDataSource(patientDocumentsD);
  public dataSource2 = new MatTableDataSource(patientDrugsMasterD);
  public dataSource3 = new MatTableDataSource(patientExaminationD);
  public dataSource4 = new MatTableDataSource(patientFamilyDetailD);
  noRecordsFoundMsg: string | undefined;
  // @ViewChild(MatPaginator) paginator!: MatPaginator;
  // @ViewChild(MatSort) sort = new MatSort();

  patientForm!: FormGroup;
  patientData: any = [];
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private patientService: PatientService,
    private appoinmentService: AppoinmentService,
    private router: Router,
    private http: HttpService,
    private appConfig: AppConfigService,
    private dialog: MatDialog,
    public hospitalService: HospitalService
  ) {
    this.updateForm();
    let obj = {
      id: Number(this.http.getDecryptedValue('patientId')),
    };
    this.appoinmentId = Number(this.http.getDecryptedValue('eventId'));

    this.getPatientDetail(obj);
  }

  updateForm() {
    this.patientForm = this.fb.group({
      id: new FormControl(),
      patientName: new FormControl({ value: null, disabled: true }),
      gender: new FormControl({ value: null, disabled: true }),
      contactNo: new FormControl({ value: null, disabled: true }),
      email: new FormControl({ value: null, disabled: true }),
      hospitalName: new FormControl({ value: null, disabled: true }),
    });
  }

  getPatientDetail(patientId: any) {
    this.patientService.getPatientDetail(patientId).subscribe((res: any) => {
      this.patientData = res.result;
      this.patientForm.patchValue(this.patientData);
      // patientAttributeD = res.result;
      patientAttributeD = res.result?.patientAttributeData;
      this.tempatientAttributeD = res.result?.patientAttributeData;

      patientDocumentsD = res.result?.patientDocumentsData;
      this.tempatientDocumentsData = res.result?.patientDocumentsData;

      patientDrugsMasterD = res.result?.patientDrugsMaster;
      this.tempatientDrugsMaster = res.result?.patientDrugsMaster;

      patientExaminationD = res.result?.patientExaminationData;
      this.tempatientExaminationData = res.result?.patientExaminationData;

      patientFamilyDetailD = res.result?.patientFamilyDetailData;
      this.tempatientFamilyDetailData = res.result?.patientFamilyDetailData;

      if (res.result.patientAttributeData.length > 0) {
        this.dataSource = new MatTableDataSource(patientAttributeD);
      } else {
        this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
        this.dataSource = new MatTableDataSource(patientAttributeD);
      }

      if (res.result.patientDocumentsData.length > 0) {
        this.dataSource1 = new MatTableDataSource(patientDocumentsD);
      } else {
        this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
        this.dataSource1 = new MatTableDataSource(patientDocumentsD);
      }

      if (res.result.patientDrugsMaster.length > 0) {
        this.dataSource2 = new MatTableDataSource(patientDrugsMasterD);
      } else {
        this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
        this.dataSource2 = new MatTableDataSource(patientDrugsMasterD);
      }

      if (res.result.patientExaminationData.length > 0) {
        this.dataSource3 = new MatTableDataSource(patientExaminationD);
      } else {
        this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
        this.dataSource3 = new MatTableDataSource(patientExaminationD);
      }
      if (res.result.patientFamilyDetailData.length > 0) {
        this.dataSource4 = new MatTableDataSource(patientFamilyDetailD);
      } else {
        this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
        this.dataSource4 = new MatTableDataSource(patientFamilyDetailD);
      }
    });
  }

  backAppList() {
    this.router.navigate(['/pages/admin/appointment']);
  }

  cancelAppoinment() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CANCEL_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.CANCEL_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        let obj = {
          id: Number(this.appoinmentId),
        };
        this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(
              ConstantsMessage.APPOINMENT_CANCEL,
              ''
            );
          }
        });
        this.router
          .navigateByUrl('/', {
            skipLocationChange: true,
          })
          .then(() => {
            this.router.navigate(['pages/admin/appointment']);
          });
      }
    });
  }
}

export interface patientAttributeData {
  weight: string;
  height: string;
}

let patientAttributeD: patientAttributeData[];

export interface patientDocumentsData {
  referenceId: number;
  documentTypeId: number;
  documentName: string;
  documentPath: string;
  patientAppointmentId: number;
}

let patientDocumentsD: patientDocumentsData[];

export interface patientDrugsMasterData {
  day: number;
  shift: number;
  drugName: string;
  quantity: number;
  uom: string;
  appointmentDateTime: Date;
  doctorName: string;
  createDate: Date;
}

let patientDrugsMasterD: patientDrugsMasterData[];

export interface patientExaminationData {
  bloodPressure: number;
  fever: number;
  patientHistory: string;
  recommandedTest: string;
  doctorName: string;
  appointMentTime: Date;
  createDate: Date;
}
let patientExaminationD: patientExaminationData[];
export interface patientFamilyDetailData {
  familyMemberName: string;
  relationToPatient: number;
  familyPersonDateOfBirth: Date;
  gender: number;
  familyContactNo: number;
}
let patientFamilyDetailD: patientFamilyDetailData[];
