import { Component } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

@Component({
  selector: 'app-patient-profile',
  templateUrl: './patient-profile.component.html',
  styleUrls: ['./patient-profile.component.scss'],
})
export class PatientProfileComponent {
  patientForm!: FormGroup;
  showManager = false;
  hospitalList: any;
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];
  userId: any;
  patientDetails: any;
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private patientService: PatientService,
    private hospitalService: HospitalService,
    private httpService: HttpService,
    private router: Router,
    private dialog: MatDialog
  ) {
    this.createForm();
    this.getHospitalList();
    this.getPatientProfile();
  }

  getPatientProfile() {
    this.patientService.getPatientProfile().subscribe((res: any) => {
      if (res.success) {
        this.patientDetails = res.result;
        this.patientForm.patchValue(this.patientDetails);
      }
    });
  }

  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }

  createForm() {
    this.patientForm = this.fb.group({
      id: new FormControl(null),
      patientName: new FormControl({ value: '', disabled: true }),
      gender: new FormControl({ value: '', disabled: true }),
      dateOfBirth: new FormControl({ value: '', disabled: true }),
      primaryContactNo: new FormControl({ value: '', disabled: true }),
      email: new FormControl({ value: '', disabled: true }),
      tenantId: new FormControl({ value: '', disabled: true }),
    });
  }
}
