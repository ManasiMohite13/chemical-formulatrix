import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { LaboratoryService } from 'src/app/shared/services/laboratory.service';
import { ConfirmDailogComponent } from '../../common/confirm-dailog/confirm-dailog.component';
import { EditLaboratoryComponent } from '../laboratory/edit-laboratory/edit-laboratory.component';
import { AddLaboratoryComponent } from '../laboratory/add-laboratory/add-laboratory.component';
import { InventoryService } from 'src/app/shared/services/inventory.service';

function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}

@Component({
  selector: 'app-manage-inventory',
  templateUrl: './manage-inventory.component.html',
  styleUrls: ['./manage-inventory.component.scss']
})
export class ManageInventoryComponent implements OnInit{
  pageSizeTemp: any;
  totalRowCount = 0;
  doctorName: any;
  hospitalList: any;
  public totalDoctorRecord = 0;
  displayedColumns: string[] = [
    'itemCategoryDesc',
    'itemName',
    'brandName',
    'power',
    'qty',
    'purchaseDate',
    'expiryDate',
    'purchasePrice',
    'sellPrice',
    'action',
  ];
  itemForm!: FormGroup;
  tempsupportData: any;
  hospitalData: any;
  roleId: any
  hospitalListCopy: any = [];
  inventoryData: any = [];
  public dataSource = new MatTableDataSource(inventoryData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private authservice: AuthService,
    private httpService: HttpService,
    private inventoryService: InventoryService,
    private hospitalService: HospitalService,

  ) {
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.createForm();
    this.getItemList();
    this.getHospitalList();
  }
  ngOnInit(): void {
    if (this.inventoryService.selectedHospital) {
      this.inventoryService.selectedHospital = this.itemForm.controls['tenantId'].setValue(this.inventoryService.selectedHospital);
      this. getItemList();
    }
  }
  resetForm() {
    this.itemForm.reset();
    this.createForm();
    this.getItemList();
  }

  createForm() {
    this.itemForm = this.formBuilder.group({
      tenantId: new FormControl(),
      laboratoryName: new FormControl(''),

    });
  }

  changeHospital(event: any) {
    this.hospitalData = event;
  }
  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }
  getHospitalList() {
    this.hospitalService.getHospitalListAsc().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
        this.hospitalListCopy = this.hospitalList;
      }
    });
  }
  getItemList() {
    let obj = {
      tenantId: this.itemForm.value.tenantId || '00000000-0000-0000-0000-000000000000',
    }
    this.inventoryService.getItemList(obj).subscribe((res: any) => {
      if (res.success) {
      let inventoryData = res.result;
      console.log('inventoryData',inventoryData)
        if (res.result.length > 0) {
          inventoryData = inventoryData.map((e)=>{
            
              e['itemCategoryDesc'] = e.itemCategoryId === 1 ? "Medicine" : "Consumable" ;
            
            return e;
          })
          this.dataSource = new MatTableDataSource(inventoryData);
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
        } else {         
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(inventoryData);
        }
        this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });
  }
  editInventory(id: any) {   
    this.authservice.encryptKey('inventoryId', id);
    this.router.navigate(['pages/admin/edit-inventory'])
    this.inventoryService.selectedHospital = this.itemForm.controls['tenantId'].value
  }

  addInventory() {
    this.router.navigate(['/pages/admin/add-inventory'])
  }

  filterType: number = 0;

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  
}
export interface displayedColumns {
  id: number;
  itemCategoryId : number;
  itemName: string;
  qty: number;
  expiryDate: Date;
  power: number;
  brandName: number;
  purchaseDate: Date;
  purchasePrice: number;
  sellPrice: number
}
let inventoryData: displayedColumns[];

