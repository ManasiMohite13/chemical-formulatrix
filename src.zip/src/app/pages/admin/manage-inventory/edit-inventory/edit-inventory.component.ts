import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { InventoryService } from 'src/app/shared/services/inventory.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

@Component({
  selector: 'app-edit-inventory',
  templateUrl: './edit-inventory.component.html',
  styleUrls: ['./edit-inventory.component.scss']
})
export class EditInventoryComponent {
  addInventoryForm!: FormGroup;
  hospitalList: any;
  hospitalListCopy:any
  roleId: any;
  itemType = true;
  itemCategoryType:any;
  itemCategory = [
    {
      id:1,
      name:'Medicine'
    },
    {
      id:2,
      name:'Consumable'
    }]
  @Input() max: any;
  inventoryData:any;
 
  tomorrow = new Date();
  minDate = new Date(); 
  id: any;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private inventoryService:InventoryService,
    private httpService: HttpService,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    private http:HttpService,
   private hospitalService:HospitalService,
  ) {
    this.tomorrow.setDate(this.tomorrow.getDate() + 0);
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.createForm();
    this.getHospitalList();
    if (this.id != '') {
      let obj = {
        id: Number(this.http.getDecryptedValue('inventoryId')),
      };
      this.getItemById(Number(this.http.getDecryptedValue('inventoryId')));
    }
  }
  dateFilter = (date: Date): boolean => {
    return date >= this.minDate;
  }
  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }
  createForm() {
    this.addInventoryForm = this.fb.group({
      id:new FormControl(),
      itemCategoryId: new FormControl(''),
      itemName: new FormControl('',[Validators.required,Validators.pattern(ConstantsMessage.ONLY_ADDRESS)] ),
      power: new FormControl('' ),
      brandName: new FormControl('' ),
      description: new FormControl(''),
      qty: new FormControl('',[Validators.min(1),Validators.pattern(ConstantsMessage.QTY_LENGTH)] ),
      expiryDate: new FormControl('' ),
      purchaseDate:new FormControl(''),
      purchasePrice:new FormControl('',[Validators.min(1),Validators.required,Validators.min(0)]),
      salePrice:new FormControl('',[Validators.min(1),Validators.min(0)]),
      tenantId: new FormControl(Validators.required),
    });
  }

  submitInventoryForm() {
    const datePipe = new DatePipe('en-US');
    debugger;
    var obj = {
      id:this.addInventoryForm.value.id,
      itemCategoryId:this.addInventoryForm.value.itemCategoryId,
      itemName: this.addInventoryForm.value.itemName,
      power: this.addInventoryForm.value.power,     
      brandName: this.addInventoryForm.value.brandName,
      qty: this.addInventoryForm.value.qty || Number,
      expiryDate: datePipe.transform(this.addInventoryForm.value.expiryDate, 'yyyy-MM-dd') || null,
      purchaseDate:datePipe.transform(this.addInventoryForm.value.purchaseDate, 'yyyy-MM-dd'),
      purchasePrice:Number(this.addInventoryForm.value.purchasePrice),
      salePrice:Number(this.addInventoryForm.value.salePrice ),
      description : this.addInventoryForm.value.description,
      tenantId: this.addInventoryForm.value.tenantId || '00000000-0000-0000-0000-000000000000',
    };
    this.inventoryService.updtateItem(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.UPDATE_INVENTORY, '');
        this.router.navigate(['pages/admin/manage-inventory']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
        this.hospitalListCopy = this.hospitalList;
      }
    });
  }


  getItemById(id: any) {
    this.inventoryService.getItemById(id).subscribe((res: any) => {
      this.inventoryData = res.result;
      this.addInventoryForm.patchValue(this.inventoryData)
      this.addInventoryForm.controls['itemCategoryId'].setValue(res.result.itemCategoryId);        
         });  
        
                     
   }
   back(){
    this.router.navigate(['/pages/admin/manage-inventory'])
   }
   resetForm(){
    this.addInventoryForm.reset()
   }

   changeItemCategoryType(event: any) {
    this.itemCategoryType = event;
   if (this.itemCategoryType === 2 ) {
     this.addInventoryForm.controls['power'].disable();            
   } 
   else
   {
     this.addInventoryForm.controls['power'].enable();  
   }
 }
}

