import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { InventoryService } from 'src/app/shared/services/inventory.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

@Component({
  selector: 'app-add-inventory',
  templateUrl: './add-inventory.component.html',
  styleUrls: ['./add-inventory.component.scss']
})
export class AddInventoryComponent {
  addInventoryForm!: FormGroup;
  hospitalList: any;
  hospitalListCopy: any
  roleId: any;
  itemCategoryType:any;
  maxDate = new Date();
  minDate = new Date(); 
  today = new Date();
  tomorrow = new Date();
  expiryDate :any;
  itemType = true;
  itemCategory = [
    {id:1,name:'Medicine'},
    {id:2,name:'Consumable'}
  ]
  @Input() max: any;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private inventoryService: InventoryService,
    private httpService: HttpService,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    private hospitalService: HospitalService,
  ) {
    this.tomorrow.setDate(this.tomorrow.getDate() + 0);
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));

    this.createForm();
    this.getHospitalList();
  }
  dateFilter = (date: Date): boolean => {
    return date >= this.minDate;
  }
  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }
  createForm() {
    const currentDate = new Date();
    this.addInventoryForm = this.fb.group({
      itemCategoryId: new FormControl('', [Validators.required]),
      itemName: new FormControl('',[Validators.required,Validators.pattern(ConstantsMessage.ONLY_ADDRESS)]),
      power: new FormControl(''),
      brandName: new FormControl(''),
      description: new FormControl(''),
      qty: new FormControl('',[Validators.min(1),Validators.pattern(ConstantsMessage.QTY_LENGTH)]),
      expiryDate: new FormControl(''),
      purchaseDate: new FormControl(new Date()),
      purchasePrice: new FormControl('',[Validators.min(1),Validators.required,Validators.min(0)]),
      salePrice: new FormControl('',[Validators.min(1),Validators.min(0)]),
      tenantId: new FormControl(''),
    });
  }
  onChange(event: any) {    
    if(!this.addInventoryForm.value.salePrice){
      this.addInventoryForm.patchValue({salePrice: Number(event.target.value)});
    }
 };

  submitInventoryForm() {
    const datePipe = new DatePipe('en-US');
    debugger;
    var obj = {
      itemCategoryId: this.addInventoryForm.value.itemCategoryId,
      itemName: this.addInventoryForm.value.itemName,
      power: this.addInventoryForm.value.power || '',
      brandName: this.addInventoryForm.value.brandName,
      qty: this.addInventoryForm.value.qty || Number,
      expiryDate: datePipe.transform(this.addInventoryForm.value.expiryDate, 'dd/MM/yyyy') ||null,
      purchaseDate:this.addInventoryForm.value.purchaseDate || new Date(),
      purchasePrice: Number(this.addInventoryForm.value.purchasePrice),
      salePrice: Number(this.addInventoryForm.value.salePrice ),
      description : this.addInventoryForm.value.description,
      tenantId: this.addInventoryForm.value.tenantId || '00000000-0000-0000-0000-000000000000',
    };
    this.inventoryService.createInventory(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.CREATE_INVENTORY, '');
        this.router.navigate(['pages/admin/manage-inventory']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
  getHospitalList() {
    this.hospitalService.getHospitalListAsc().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
        this.hospitalListCopy = this.hospitalList;
      }
    });
  }
  back(){
    this.router.navigate(['/pages/admin/manage-inventory'])
  }
  resetForm(){
    this.addInventoryForm.reset()
   }

   changeItemCategoryType(event: any) {
     this.itemCategoryType = event;
    if (this.itemCategoryType === 2 ) {
      this.addInventoryForm.controls['power'].disable();               
    } 
    else
    {
      this.addInventoryForm.controls['power'].enable();          
    }
  }
}

