import { Component, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { DatePipe, Time } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { PaymentOption, PaymentOptionName } from 'src/assets/config/global-enums';
// import { PaymentOption } from 'dist/emr/assets/config/global-enums';

@Component({
  selector: 'app-transition-by-patient',
  templateUrl: './transition-by-patient.component.html',
  styleUrls: ['./transition-by-patient.component.scss']
})
export class TransitionByPatientComponent {
  transactionPatientForm!: FormGroup;
  doctorData: any = [];
  public dataSource = new MatTableDataSource(doctorData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  PaymentOptionName=PaymentOptionName;
  PaymentOption=PaymentOption;
  displayedColumns: string[] = [
    'patientName',
    'patientMobileNo',
    'paymentAmount',
    'paymentSource',
    'doctorName',
    'appointmentDateTime',
    'appointmentTime'
  ];
  today = new Date();
  weekStart!: Date;
  weekEnd!: Date;
  constructor(
    private formBuilder: FormBuilder,
    private appoinmentService: AppoinmentService,
    public datepipe: DatePipe,
    private httpService: HttpService,
    private fb: FormBuilder,
    private tosterService: ToasterService) {
      this.createForm();
      this.getTransactionByPatient()
  }
  resetForm() {
    this.transactionPatientForm.reset();
  }
  createForm() {
    const today = new Date();
    this.transactionPatientForm = this.formBuilder.group({
      fromDate: [today],
      toDate: [today],
    });
  }
  
  private setDate(isSunday): Date {
    const today = new Date();
    const dayOfWeek = today.getDay();
    var diff = null;
    if (isSunday) {
      diff = today.getDate() - dayOfWeek;
    } else {
      diff = today.getDate() + (0 - dayOfWeek);
    }
    return new Date(today.setDate(diff));
  }
  getTransactionByPatient() {
    let obj = {
      fromDate: this.datepipe.transform(
        this.transactionPatientForm?.value.fromDate,
        'yyyy-MM-dd'
      ),
      toDate: this.datepipe.transform(
        this.transactionPatientForm?.value.toDate,
        'yyyy-MM-dd'
      ),
    };
    this.appoinmentService.getTransactionByPatient(obj).subscribe((res: any) => {
      if (res.success) {
        let doctorData = res.result;
        if (res.result.length > 0) {
          this.dataSource = new MatTableDataSource(doctorData);
        } else {
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(doctorData);
        }
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;

      }

    });
  }

}

export interface displayedColumns {
  patientName: string;
  patientMobileNo: number;
  paymentAmount: number;
  paymentSource: number;
  doctorName: string;
  appointmentDateTime:Date;
  appointmentTime:Time
  
}
let doctorData: displayedColumns[];

