import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransitionByPatientComponent } from './transition-by-patient.component';

describe('TransitionByPatientComponent', () => {
  let component: TransitionByPatientComponent;
  let fixture: ComponentFixture<TransitionByPatientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransitionByPatientComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TransitionByPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
