import { ChangeDetectorRef, Component, Inject, Optional } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { UserService } from 'src/app/shared/services/user.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { ValidationService } from 'src/app/shared/validation.service';

@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.scss'],
})
export class UpdatePasswordComponent {
  passUpdateForm!: FormGroup;
  userId: any;
  userDetail: any;
  hide: boolean = true;
  visible: boolean = true;
  passwordInfo: string = ConstantsMessage.VALIDATION_PASSWORD_MESSAGE_INFO;
  constructor(
    private confirmPasswordValidators: ValidationService,
    private fb: FormBuilder,
    private userService: UserService,
    private hospitalService: HospitalService,
    private router: Router,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    private dialog: MatDialog,
    public dialogRef: MatDialogRef<UpdatePasswordComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.userId = data;
    this.createForm();
  }
  createForm() {
    this.passUpdateForm = this.fb.group(
      {
        id: new FormControl(),
        password: new FormControl('', [
          Validators.required,
          Validators.pattern(
            '(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-zd$@$!%*?&].{8,}'
          ),
        ]),
        confirmPassword: new FormControl('', Validators.required),
      },
      {
        validator: this.confirmPasswordValidators.ConfirmedValidator(
          'password',
          'confirmPassword'
        ),
      }
    );
  }

  resetForm() {
    this.passUpdateForm.reset();
  }

  submitForm() {
    const obj = {
      id: this.userId,
      password: this.passUpdateForm.value.password,
    };
    this.userService.updateUserPassword(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.USER_PASS_UPDATE, '');
        this.router.navigate(['pages/admin/user']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
}
