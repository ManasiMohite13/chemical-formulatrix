import { ChangeDetectorRef, Component, Inject, Optional } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { UserService } from 'src/app/shared/services/user.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.scss'],
})
export class ViewUserComponent {
  userForm!: FormGroup;
  userId: any;
  hospitalList: any;
  roleList: any = [
    { id: 1, role: 'Super Admin' },
    { id: 2, role: 'Admin' },
    { id: 3, role: 'Doctor' },
    { id: 4, role: 'Patient ' },
    { id: 5, role: 'Receptionist' },
  ];
  statusList: any = [
    { id: 1, status: 'Active' },
    { id: 2, status: 'Inactive' },
  ];
  isTextBoxDisabled: boolean = true;
  userDetail: any;
  intenantId:any
  userData: any[];
  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private hospitalService: HospitalService,
    private router: Router,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    private dialog: MatDialog,
    public dialogRef: MatDialogRef<ViewUserComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.userId = data;
    this.createForm();
    this.getUserList();
    if (this.userId) {
      this.getUser();
    }
    this.getHospitalList();
  }
  createForm() {
    this.userForm = this.fb.group({
      id: new FormControl(),
      email: new FormControl({ value: null, disabled: true }),
      status: new FormControl('', [Validators.required]),
      userType: new FormControl({ value: null, disabled: true }),
      firstName: new FormControl({ value: null, disabled: true }),
      lastName: new FormControl({ value: null, disabled: true }),
      tenantId: new FormControl('', [Validators.required]),
      hospitalName:new FormControl({ value: null, disabled: true }),
    });
  }


  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }

  getUser() {
    const obj = {
      id: Number(this.userId),
    };
    this.userService.getUserById(obj).subscribe((res: any) => {
      if (res.success) {
        this.userDetail = res.result;
        this.intenantId=this.userDetail.tenantId
        this.userForm.patchValue(this.userDetail);
      }
    });
  }

  submitForm() {
    const obj = {
      id: this.userForm.value.id,
      email: this.userDetail.email,
      status: this.userForm.value.status,
      userType: this.userDetail.userType,
      firstName: this.userDetail.firstName,
      lastName: this.userDetail.lastName,
      tenantId: this.intenantId,
    };
    
    this.userService.updateUser(obj).subscribe((res: any) => {
      if (res.success) {
       
        this.toasterService.showSuccess(ConstantsMessage.USER_UPDATE, ''); 
        this.getUserList();      
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
  getUserList() {
    this.userService
      .getUserList(this.intenantId)
      .subscribe((res: any) => {
        if (res.success) {
          this.userData = res.result;         
        }
      });
  }
}
