import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { RoleService } from 'src/app/shared/services/role.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { UserService } from 'src/app/shared/services/user.service';
import { ValidationService } from 'src/app/shared/validation.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss'],
})
export class AddUserComponent {
  addUserForm!: FormGroup;
  hospitalList: any;
  hospitalListCopy: any = [];
  refreanceListing: any;
  tenantId: any;
  email: any;
  mobileNumber: any;
  roleId: any;
  userType: any;
  name: any;
  drOrPatientantId: any;
  hide: boolean = true;
  visible: boolean = true;
  roleData: any;
  userData:any[];
  passwordInfo: string = ConstantsMessage.VALIDATION_PASSWORD_MESSAGE_INFO;
  roleList: any = [
    { id: 1, role: 'Super Admin' },
    { id: 2, role: 'Admin' },
    { id: 3, role: 'Doctor' },
    { id: 4, role: 'Patient ' },
    { id: 5, role: 'Receptionist' },
  ];
  selectedHospital: any;
  constructor(
    private hospitalService: HospitalService,
    private fb: FormBuilder,
    private confirmPasswordValidators: ValidationService,
    private userService: UserService,
    private httpService: HttpService,
    private router: Router,
    private toasterService: ToasterService,
    public dialogRef: MatDialogRef<AddUserComponent>,
    public fd: ChangeDetectorRef,
    private roleService: RoleService,
  ) {
    this.getRoleList();
    this.createForm();
    this.getUserList();
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.roleId === 2 ? this.getHospitalById() : this.getHospitalList();
  }
  createForm() {
    this.addUserForm = this.fb.group(
      {
        email: new FormControl('', [Validators.required, Validators.email]),
        userType: new FormControl('', [Validators.required]),
        referanceId: new FormControl('', [Validators.required]),
        firstName: new FormControl('', [
          Validators.required,
          Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
        ]),
        lastName: new FormControl('', [
          Validators.required,
          Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
        ]),
        mobileNumber: new FormControl('', [Validators.required, Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN)]),
        tenantId: new FormControl('', [Validators.required]),
        password: new FormControl('', [
          Validators.required,
          Validators.pattern(
            '(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-zd$@$!%*?&].{8,}'
          ),
        ]),
        confirmPassword: new FormControl('', Validators.required),
      },
      {
        validator: this.confirmPasswordValidators.ConfirmedValidator(
          'password',
          'confirmPassword'
        ),
      }
    );
  }

  getHospitalList() {
    this.hospitalService.getHospitalListAsc().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
        this.hospitalListCopy = this.hospitalList;
      }
    });
  }

  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  getRoleList() {
    this.roleService.getRoleListAsc().subscribe((res: any) => {
      if (res.success) {
        this.roleData = res.result.filter(item => item.status !== 2);
      }
    });
  }

  changeTenantId(event: any) {
    this.tenantId = event;
    this.getReferanceDetail();
  }

  changeDrOrPatient(event: any) {
    this.drOrPatientantId = event;
    this.getReferanceDetail();
  }

  changeUserType(event: any) {
    this.userType = event;
    if (this.userType === 3 || this.userType === 4) {
      this.addUserForm.controls['firstName'].disable();
      this.addUserForm.controls['lastName'].disable();
      this.addUserForm.controls['referanceId'].enable();
      this.getReferanceDetail();
    } else {
      this.addUserForm.controls['referanceId'].disable();
      this.addUserForm.controls['firstName'].enable();
      this.addUserForm.controls['lastName'].enable();
      this.addUserForm.controls['email'].reset();
      this.addUserForm.controls['email'].enable();
      this.addUserForm.controls['mobileNumber'].enable();
      this.addUserForm.controls['mobileNumber'].reset();
    }
  }

  getHospitalById() {
    this.hospitalService.getHospitalById(0).subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = [res.result];
        this.hospitalListCopy = this.hospitalList;
        this.addUserForm.controls['tenantId'].setValue(
          this.hospitalList[0].tenantId
        );
        this.tenantId = this.hospitalList[0].tenantId;
      }
    });
  }

  getReferanceDetail() {
    if (this.tenantId && this.userType) {
      let obj = {
        tenantId: this.tenantId,
        userType: this.userType,
      };
      this.userService.getReferanceDetail(obj).subscribe((res: any) => {
        if (res.success) {
          this.refreanceListing = res.result;
          this.addUserForm.patchValue(this.refreanceListing);

          if (this.drOrPatientantId) {
            this.email = this.refreanceListing.find(
              (x: { id: any }) => x.id === this.drOrPatientantId
            ).email;
            this.addUserForm.controls['email'].setValue(this.email);
            this.addUserForm.controls['email'].disable();
          }

          if (this.drOrPatientantId) {
            this.mobileNumber = this.refreanceListing.find(
              (x: { id: any }) => x.id === this.drOrPatientantId
            ).mobileNumber;
            this.addUserForm.controls['mobileNumber'].setValue(this.mobileNumber);
            this.addUserForm.controls['mobileNumber'].disable();
          }

        }
      });
    }
  }

  submitPatientForm() {
    var obj = {
      email: this.addUserForm.value.email || this.email,
      password: this.addUserForm.value.password,
      userType: this.addUserForm.value.userType,
      firstName: this.addUserForm.value.firstName || '',
      lastName: this.addUserForm.value.lastName || '',
      referanceId: this.addUserForm.value.referanceId || 0,
      tenantId: this.addUserForm.value.tenantId,
      mobileNumber: this.mobileNumber || this.addUserForm.value.mobileNumber.toString(),
    };
    this.userService.createUser(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.USER_CREATE, '');
        this.dialogRef.close({ result: true });
        this.getUserList();
        // this.router.navigate(['pages/admin/user']);
       
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }

  resetForm() {
    this.addUserForm.reset();
  }
  getUserList() {
    var tenantId = localStorage.getItem('tenantId'); 
    this.userService
      .getUserList(this.addUserForm.value.tenantId)
      .subscribe((res: any) => {
        if (res.success) {
          this.userData = res.result;         
        }
      });
  }
}
