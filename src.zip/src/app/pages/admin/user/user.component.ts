import {
  Component,
  ElementRef,
  ViewChild,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { AddUserComponent } from './add-user/add-user.component';
import { UserService } from 'src/app/shared/services/user.service';
import { ViewUserComponent } from './view-user/view-user.component';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpService } from 'src/app/shared/services/http.service';
import { UpdatePasswordComponent } from './update-password/update-password.component';
import { fromEvent } from 'rxjs';

function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'],
})
export class UserComponent {
  displayedColumns: string[] = [
    'hospitalName',
    'firstName',
    'email',
    'userType',
    'status',
    'Action',
  ];
  tempUserData: any;
  roleId: any;
  hospitalList: any;
  hospitalListCopy: any = [];
  userForm!: FormGroup;
  public dataSource = new MatTableDataSource(userData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  @ViewChild('filterInput') filterInput!: ElementRef;
  subscription: any;
  constructor(
    private userService: UserService,
    private router: Router,
    private dialogRef: MatDialog,
    private hospitalService: HospitalService,
    private httpService: HttpService,
    private formBuilder: FormBuilder
  ) {
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.createForm();
    this.getHospitalList();
    this.roleId === 2 ? this.getUserListForAdmin() : this.getUserList();
  }

  resetForm() {
    this.userForm.reset();
    this.createForm();
    this.getUserListForAdmin();
    this.getUserList();

  }

  createForm() {
    this.userForm = this.formBuilder.group({
      tenantId: new FormControl('', [Validators.required]),
      email: new FormControl(),
    });
  }

  sortData(sort: Sort) {
    const data = this.tempUserData;
    if (!sort.active || sort.direction === '') {
      this.dataSource = data;
      return;
    }
    const isAsc = sort.direction === 'asc';
    const sortedData = data.sort((a: any, b: any) => {
      switch (sort.active) {
        case 'status':
          return compareNumber(a.status, b.status, isAsc);
        case 'firstName':
          return compareString(a.firstName, b.firstName, isAsc);
        case 'hospitalName':
          return compareString(a.hospitalName, b.hospitalName, isAsc);
        case 'userType':
          return compareString(a.userType, b.userType, isAsc);
        case 'email':
          return compareNumber(a.email, b.email, isAsc);
        default:

          return 0;
      }
    });
    this.dataSource = new MatTableDataSource(sortedData);
    this.dataSource.paginator = this.paginator;
  }

  getHospitalList() {
    this.hospitalService.getHospitalListAsc().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
        this.hospitalListCopy = this.hospitalList;
      }
    });
  }

  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  getUserListForAdmin() {
    this.userService.getUserListForAdmin().subscribe((res: any) => {
      if (res.success) {
        userData = res.result;
        this.tempUserData = res.result;
        if (res.result.length > 0) {
          this.dataSource = new MatTableDataSource(userData);
        } else {
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(userData);
        }
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });
  }

  getUserList() {
    this.userService
      .getUserList(this.userForm.value.tenantId || '00000000-0000-0000-0000-000000000000')
      .subscribe((res: any) => {
        if (res.success) {
          userData = res.result;
          this.tempUserData = res.result;
          if (res.result.length > 0) {
            this.dataSource = new MatTableDataSource(userData);
          } else {
            this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
            this.dataSource = new MatTableDataSource(userData);
          }
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }
      });
  }

  addUser() {
    const confirmDialog = this.dialogRef.open(AddUserComponent, {
      width: '650px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        // this.router.navigate(['pages/admin/user']);
        this.getUserList();
      }
    });
  }

  editUser(Id: any) {
    const confirmDialog = this.dialogRef.open(ViewUserComponent, {
      width: '600px',
      disableClose: true,
      data: Id,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        // this.router.navigate(['pages/admin/user']);
        if (this.userForm.value.tenantId) {
          this.getUserList();
        }
      }
    });
  }

  updatePass(Id: any) {
    const confirmDialog = this.dialogRef.open(UpdatePasswordComponent, {
      width: '550px',
      disableClose: true,
      data: Id,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.router.navigate(['pages/admin/user']);
        this.getUserList();
      }
    });
  }
  ngOnDestroy() {
    history.pushState(null, '', location.href);

    this.subscription = fromEvent(window, 'popstate').subscribe(_ => {
      history.pushState(null, '', location.href);
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
    const searchInput = this.filterInput.nativeElement;
    searchInput.value = '';
    this.applyFilter('');
  }
}
export interface displayedColumns {
  email: string;
  status: string;
  userType: string;
  hospitalName: string;
  firstName: string;
}
let userData: displayedColumns[];
