import {ChangeDetectorRef,Component,OnInit,Renderer2,ViewChild} from '@angular/core';
import {FormBuilder,FormControl,FormGroup,Validators} from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import { Router } from '@angular/router';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { ManagePermissionService } from 'src/app/shared/services/manage-permission.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

@Component({
  selector: 'app-add-doctor',
  templateUrl: './add-doctor.component.html',
  styleUrls: ['./add-doctor.component.scss'],
})
export class AddDoctorComponent implements OnInit {
  roleId: any;
  addDoctorForm!: FormGroup;
  specificationList: any;
  specialityArray: any = [];
  chagesMonths: any = [];
  allSelected = false;
  hospitalList: any = [];
  hospitalListCopy: any = [];
  isSpecAvailable = false;
  specificationListCopy:any=[]
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];
  specialityList: any;
  tenantId: any
  event: any
  permissonData: any
  @ViewChild('select') private select!: MatSelect;
  bmcList: any;
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private doctorService: DoctorService,
    private httpService: HttpService,
    private router: Router,
    public fd: ChangeDetectorRef,
    public hospitalService: HospitalService,
    private managePermission: ManagePermissionService,
    private renderer: Renderer2
  ) {
    this.getRolePermission()
    this.createForm();
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.roleId === 2 ? this.getHospitalById() : this.getHospitalList();

  }
  ngOnInit(): void {
  }
  getRolePermission() {
    this.managePermission.getRolePermissionList().subscribe((res: any) => {
      if (res.success) {
        this.permissonData = res.result;
      }
    })
  }

  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }
  autoCompleteSpciality(data){
    this.specificationListCopy = this.specificationList.filter(option => option.doctorSpecialityName.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  canceladdDoctorForm() {
    this.addDoctorForm.reset();
    this.addDoctorForm.get('profilePic').setValue('');
    this.imageUrl = 'assets/image/no_image.jpg';
    this.editFile = true;
    this.removeUpload = false;
  }

  getDoctorSpecification(tenantId: any) {
    this.doctorService.getDoctorSpecility(tenantId).subscribe((res: any) => {
      if (res.success) {
        this.specificationList = res.result;
        this.specificationListCopy= this.specificationList;
        this.isSpecAvailable = false;
        if (this.specificationList.length < 1) {
          this.isSpecAvailable = true;
        }
      }
    });
  }

  toggleAllSelection() {
    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }

  optionClick() {
    // let newStatus = true;
    // this.select.value.forEach((item: MatOption) => {
    //   if (!item.selected) {
    //     newStatus = false;
    //   }
    // });
    // if (this.specificationList.length == this.select.value.length) {
    //   this.allSelected = true;
    // } else this.allSelected = false;
    //this.specialityArray.push()
  }
  // specilitiesList() {
  //   this.specialityArray = [];
  //   const selectedSpecialities = this.addDoctorForm.value.doctorSpecilityDetail;
  //   for (let i = 0; i < selectedSpecialities.length; i++) {
  //     var obj = {
  //       specilityId: selectedSpecialities[i],
  //     };
  //     this.specialityArray.push(obj);
  //   }

  // }

  changeTenantId(event: any) {
    this.getDoctorSpecification(event);
  }

  getHospitalById() {
    this.hospitalService.getHospitalById(0).subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = [res.result];
        this.hospitalListCopy = this.hospitalList;
        this.addDoctorForm.controls['tenantId'].setValue(this.hospitalList[0].tenantId);
        this.getDoctorSpecification(this.hospitalList[0].tenantId);
      }
    });
  }
  back() {
    this.router.navigate(['/pages/admin/doctor']);
  }

  getHospitalList() {
    this.hospitalService.getHospitalListAsc().subscribe((res: any) => {
      this.hospitalList = res.result;
      this.hospitalListCopy = this.hospitalList;
    });
  }
  getSpecialityList(tenantId) {
    // this.hospitalService.getSpecialtiesList(tenantId).subscribe((res: any) => {
    //   this.specialityList = res.result;
    // })
  }
  createForm() {
    this.addDoctorForm = this.fb.group({
      firstName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_DOCTOR_FIRST_NAME),
      ]),
      middleName: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      lastName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      gender: new FormControl('', [Validators.required]),
      qualification: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_QUALIFICATION),]),
      homePhone: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      workPhone: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      email: new FormControl('', [
        Validators.required, Validators.email]
      ),
      experience: new FormControl('', [Validators.min(1), Validators.max(100)]),
      profilePic: new FormControl(''),
      tenantId: new FormControl('', [Validators.required]),
      allowPortalLogin: new FormControl(false, [Validators.required]),
      doctorSpecilityDetail: new FormControl('', [Validators.required]),
    });
  }

  editFile = true;
  removeUpload = false;
  imageUrl: any;

  uploadFile(event: any, controlName: string) {
    const reader = new FileReader();
    const file = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.imageUrl = reader.result;
        this.addDoctorForm.controls[controlName].setValue(reader.result);
        this.editFile = false;
        this.removeUpload = true;
      };
    }
  }
  submitaddDoctorForm() {
    this.specialityArray=[];
    if(this.addDoctorForm.value.doctorSpecilityDetail){
      this.specialityArray.push({specilityId :this.addDoctorForm.value.doctorSpecilityDetail});
    }
  
    var obj = {
      firstName: this.addDoctorForm.value.firstName,
      middleName: this.addDoctorForm.value.middleName,
      lastName: this.addDoctorForm.value.lastName,
      gender: this.addDoctorForm.value.gender,
      qualification: this.addDoctorForm.value.qualification,
      homePhone: this.addDoctorForm.value.homePhone,
      workPhone: this.addDoctorForm.value.workPhone,
      email: this.addDoctorForm.value.email,
      experience: Number(this.addDoctorForm.value.experience) || null,
      profilePic:
        this.addDoctorForm.value.profilePic
          .replace('data:', '')
          .replace(/^.+,/, '') || '',
      tenantId: this.addDoctorForm.value.tenantId,
      allowPortalLogin: this.addDoctorForm.value.allowPortalLogin,
      doctorSpecilityDetail: this.specialityArray,
    };

    this.doctorService.createDoctor(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.DOCTOR_CREATE, '');
        this.router.navigate(['pages/admin/doctor']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
}
