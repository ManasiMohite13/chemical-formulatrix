import {Component, OnInit, ViewChild, } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { AddScheduleComponent } from './add-schedule/add-schedule.component';
import { EditScheduleComponent } from './edit-schedule/edit-schedule.component';
function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}
@Component({
  selector: 'app-doctors',
  templateUrl: './doctors.component.html',
  styleUrls: ['./doctors.component.scss'],
})
export class DoctorsComponent implements OnInit {
  pageSizeTemp: any;
  totalRowCount = 0;
  doctorName: any;
  hospitalList: any;
  hospitalListCopy: any = [];
  roleId: any;
  permissonData: any
  public totalDoctorRecord = 0;
  displayedColumns: string[] = [
    'doctorName',
    'doctorSpecialityName',
    'qualification',
    'workPhone',
    'email',
    'Action',
  ];
  doctorForm!: FormGroup;
  doctorData: any = [];
  public dataSource = new MatTableDataSource(doctorData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();

  constructor(
    private doctorService: DoctorService,
    private router: Router,
    private dialogRef: MatDialog,
    private hospitalService: HospitalService,
    private formBuilder: FormBuilder,
    private authservice: AuthService,
    private httpService: HttpService
  ) {
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.createForm();
    this.getDoctorList();
    this.getHospitalList();
    if (this.roleId === 2) {
      this.doctorForm.controls['hospitalTenantId'].disable();
    }
  }
  ngOnInit(): void {
    if (this.doctorService.seletectedHospital) {
      this.doctorService.seletectedHospital = this.doctorForm.controls['hospitalTenantId'].setValue(this.doctorService.seletectedHospital);
      this.getDoctorList();
    }
  }

  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  resetForm() {
    this.doctorForm.reset();
    this.createForm();
    this.getDoctorList();
  }

  createForm() {
    this.doctorForm = this.formBuilder.group({
      mobileNumber: new FormControl('',[Validators.minLength(9),
        Validators.maxLength(11)]),
      doctorFirstName: new FormControl(''),
      hospitalTenantId: new FormControl('', [Validators.required]),
    });
  }

  getHospitalList() {
    this.hospitalService.getHospitalListAsc().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
        this.hospitalListCopy = this.hospitalList;
      }
    });
  }

  getDoctorList() {
    if (this.roleId === 1) {
      let obj = {
        pageNumber: this.paginator
          ? this.paginator.pageIndex == 0
            ? 1
            : this.paginator.pageIndex + 1
          : 1,
        pageSize: this.pageSizeTemp || 10,
        mobileNumber: this.doctorForm.value.mobileNumber || '',
        doctorFirstName: this.doctorForm.value.doctorFirstName || '',
        doctorLastName: '',
        hospitalTenantId:
          this.doctorForm.value.hospitalTenantId ||
          '00000000-0000-0000-0000-000000000000',
      };
      this.doctorService.getDoctorList(obj).subscribe((res: any) => {
        if (res.success) {
          let doctorData = res.result;
          if (res.result.length > 0) {
            this.dataSource = new MatTableDataSource(doctorData.doctorListResponse);
          } else {
            this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
            this.dataSource = new MatTableDataSource(doctorData.doctorListResponse);
          }
          this.dataSource.sort = this.sort;
          this.totalRowCount = res.result.rowCount;
        }
      });
    } else {
      let obj = {
        pageNumber: this.paginator
          ? this.paginator.pageIndex == 0
            ? 1
            : this.paginator.pageIndex + 1
          : 1,
        pageSize: this.pageSizeTemp || 10,
        mobileNumber: this.doctorForm.value.mobileNumber || '',
        doctorFirstName: this.doctorForm.value.doctorFirstName || '',
        doctorLastName: '',
      };
      this.doctorService
        .getDoctorListByHospitalAdmin(obj)
        .subscribe((res: any) => {
          if (res.success) {
            let doctorData = res.result;
            if (res.result.length > 0) {
              this.dataSource = new MatTableDataSource(doctorData.doctorListResponse);
            } else {
              this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
              this.dataSource = new MatTableDataSource(doctorData.doctorListResponse);
            }
            this.dataSource.sort = this.sort;
            this.totalRowCount = res.result.rowCount;
          }
        });
    }
  }

  changePaging(event: any) {
    pageNumber: event.pageIndex == 0 ? 1 : event.pageIndex + 1,
      (this.pageSizeTemp = event.pageSize),
      this.getDoctorList();
  }

  editDoctor(doctorId: any) {
    this.doctorService.seletectedHospital = this.doctorForm.controls['hospitalTenantId'].value
    this.authservice.encryptKey('doctorId', doctorId);
    this.router.navigate(['/pages/admin/doctor/edit-doctor']);
  }
  editSchedule(doctorId: any) {
    const confirmDialog = this.dialogRef.open(EditScheduleComponent, {
      width: '600px',
      disableClose: true,
      data: doctorId,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.router.navigate(['pages/admin/doctor']);
        this.getDoctorList();
      }
    });


  }
  addSchedule(doctorId: any) {
    const confirmDialog = this.dialogRef.open(AddScheduleComponent, {
      width: '600px',
      disableClose: true,
      data: doctorId,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.router.navigate(['pages/admin/doctor']);
        this.getDoctorList();
      }
    });
  }

  addDoctor() {
    this.router.navigate(['/pages/admin/doctor/add-doctor']);
  }

  applyFilter(filterValue: string) {
    this.doctorName = filterValue;
    this.getDoctorList();
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
}
export interface displayedColumns {
  doctorId: number;
  doctorName: string;
  doctorSpecialityName: string;
  qualification: string;
  workPhone: number;
  email: number;
}
let doctorData: displayedColumns[];
