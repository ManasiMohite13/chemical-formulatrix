import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select';
import { Router } from '@angular/router';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { AppConfigService } from 'src/app/shared/services/common/app-config.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ConstantsRoutes } from 'src/assets/config/constants-routes';

@Component({
  selector: 'app-edit-doctors',
  templateUrl: './edit-doctors.component.html',
  styleUrls: ['./edit-doctors.component.scss'],
})
export class EditDoctorsComponent implements OnInit {
  updateDoctorForm!: FormGroup;
  showManager: boolean = false;
  @ViewChild('select') private select!: MatSelect;
  specificationList: any = [];
  hospitalListCopy: any = [];
  allSelected = false;
  id: any;
  roleId: any;
  specialityArray: any = [];
  specificationArray: any = [];
  doctorSpecialityById: any;
  doctorSpecilityDetails: any = [];
  doctorSpecificationDetailsArray: any = [];
  doctorData: any = [];
  specificationListCopy:any=[]
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];
  apiURL: any;
  hospitalList: any = [];
  statusList: any = [
    { id: 1, status: 'Active' },
    { id: 2, status: 'InActive ' },
  ];
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private doctorService: DoctorService,
    private router: Router,
    private http: HttpService,
    private appConfig: AppConfigService,
    private dialog: MatDialog,
    public hospitalService: HospitalService
  ) {
    this.updateForm();
    // this.apiURL =
    //   this.appConfig.getConfig().apiURL + '/documents/DoctorImages/';
    this.roleId = Number(this.http.getDecryptedValue('roleId'));
    this.roleId === 2 ? this.getHospitalById() : this.getHospitalList();
    this.apiURL = ConstantsRoutes.Main_URL;
    if (this.id != '') {
      let obj = {
        id: Number(this.http.getDecryptedValue('doctorId')),
      };
      this.getDoctorById(obj);
    }
    this.getHospitalList();
  }

  
  getDoctorById(doctorId: any) {
    this.doctorService.getDoctorById(doctorId).subscribe((res: any) => {
      this.doctorData = res.result;
      this.getDoctorSpecification(this.doctorData.tenantId);
      // this.doctorSpecificationDetailsArray = res.result;
      // var arru = res.result.doctorSpecilityDetail.map((x: any) => x.specilityId);
      this.updateDoctorForm.patchValue(this.doctorData);
      this.updateDoctorForm.patchValue({
        profilePic:
          this.doctorData.profilePic == ''
            ? ''
            : this.apiURL + this.doctorData.profilePic,
      });
      // this.updateDoctorForm.controls['doctorSpecilityDetail'].setValue(
      //   res.result.doctorSpecilityDetail.map((x: any) => x.specilityId)
      // );
     
    });
  }

  ngOnInit(): void {
  }
  reset() {
    this.updateDoctorForm.reset()
  }

  cancelDoctorForm() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CANCEL_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.CANCEL_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.router.navigate(['/pages/admin/doctor']);
      }
    });
  }
  back() {
    this.router.navigate(['/pages/admin/doctor'])
  }
  getHospitalById() {
    this.hospitalService.getHospitalById(0).subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = [res.result];
        this.updateDoctorForm.controls['tenantId'].setValue(
          this.hospitalList[0].tenantId
        );
      }
    });
  }

  autoComplete(data) {
    this.hospitalListCopy = this.hospitalList.filter(option => option.hospitalName.toLowerCase().includes(data.target.value.toLowerCase()));
  }
  autoCompleteSpciality(data){
    this.specificationListCopy = this.specificationList.filter(option => option.doctorSpecialityName.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      this.hospitalList = res.result;
      this.hospitalListCopy = this.hospitalList;
    });
  }
  changeTenantId(event: any) {
    this.getDoctorSpecification(event);
  }
  getDoctorSpecification(tenantId: any) {
    this.doctorService.getDoctorSpecility(tenantId).subscribe((res: any) => {
      if (res.success) {
        this.specificationList = res.result;
        this.specificationListCopy =  this.specificationList;
        if (
          this.doctorSpecificationDetailsArray.length ==
          this.specificationList.length
        ) {
          this.allSelected = true;
        } else {
          this.allSelected = false;
        }

        this.doctorSpecificationDetailsArray =
        this.doctorData.doctorSpecilityDetail.map((s: any) => s.specilityId);
        this.updateDoctorForm.controls['doctorSpecilityDetail'].setValue(
          this.doctorSpecificationDetailsArray[0]
        );
      }
    });
  }
  toggleAllSelection() {
    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }
  optionClick() {
    let newStatus = true;
    this.select.value.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    if (this.specificationList.length == this.select.value.length) {
      this.allSelected = true;
    } else this.allSelected = false;
  }

  specilitiesList() {
    for (let i = 0; i < this.updateDoctorForm.value.specilityId.length; i++) {
      var obj = {
        specilityId: this.updateDoctorForm.value.specilityId[i],
      };
      this.specialityArray.push(obj);
    }
  }

  @ViewChild('fileInput') el: ElementRef | undefined;
  imageUrl: any = '';
  editFile: boolean = true;
  removeUpload: boolean = false;

  uploadFile(event: any, controlName: string) {
    const reader = new FileReader();
    const file = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.imageUrl = reader.result;
        this.updateDoctorForm.controls[controlName].setValue(reader.result);

        this.editFile = false;
        this.removeUpload = true;
      };
    }
  }

  updateForm() {
    this.updateDoctorForm = this.fb.group({
      firstName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_DOCTOR_FIRST_NAME),
      ]),
      middleName: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      lastName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      gender: new FormControl('', [Validators.required]),
      qualification: new FormControl('', [Validators.pattern(ConstantsMessage.ONLY_QUALIFICATION)]),
      homePhone: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      workPhone: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      email: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.EMAIL_PATTERN),
      ]),
      experience: new FormControl('', [Validators.min(1), Validators.max(100)]),
      profilePic: new FormControl(''),
      status: new FormControl(''),
      tenantId: new FormControl('', [Validators.required]),
      hospitalName : new FormControl({ value: null, disabled: true }),
      doctorSpecilityDetail: new FormControl([], [Validators.required]),
    });
  }

  submitupdateDoctorForm() {
    debugger
    //this.specilitiesList();
    this.specialityArray=[];
    if(this.updateDoctorForm.value.doctorSpecilityDetail){
      this.specialityArray.push({specilityId :this.updateDoctorForm.value.doctorSpecilityDetail});
    }

    var obj = {
      id: Number(this.http.getDecryptedValue('doctorId')),
      firstName: this.updateDoctorForm.value.firstName,
      middleName: this.updateDoctorForm.value.middleName,
      lastName: this.updateDoctorForm.value.lastName,
      qualification: this.updateDoctorForm.value.qualification,
      homePhone: this.updateDoctorForm.value.homePhone,
      workPhone: this.updateDoctorForm.value.workPhone,
      email: this.updateDoctorForm.value.email,
      gender: this.updateDoctorForm.value.gender,
      tenantId: this.updateDoctorForm.value.tenantId,
      experience: Number(this.updateDoctorForm.value.experience) || null,
      doctorSpecilityDetail: this.specialityArray,
      profilePic:
        (this.updateDoctorForm.value.profilePic.includes(this.apiURL)
          ? this.updateDoctorForm.value.profilePic.substring(this.apiURL.length)
          : this.updateDoctorForm.value.profilePic
            .replace('data:', '')
            .replace(/^.+,/, '')) || '',
      status: this.updateDoctorForm.value.status,
    };
    this.doctorService.updateDoctor(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.DOCTOR_UPDATE, '');
        this.router.navigate(['pages/admin/doctor']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
}
