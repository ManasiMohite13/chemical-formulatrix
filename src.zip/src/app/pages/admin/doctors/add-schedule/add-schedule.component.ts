import {
  ChangeDetectorRef,
  Component,
  Inject,
  Optional,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { el } from 'date-fns/locale';
import { extractTimefromDate } from 'src/app/shared/model/application.constants';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
@Component({
  selector: 'app-add-schedule',
  templateUrl: './add-schedule.component.html',
  styleUrls: ['./add-schedule.component.scss'],
})
export class AddScheduleComponent {
  scheduleForm!: FormGroup;
  hospitalList: any;
  doctorId: any;
  eveShiftCheck: any;
  morShiftCheck = true;
  doctorData: any = [];
  isDataUpdated: boolean = false;
  scheduleListData: any;
  frequenySlot: any = [
    { id: 1, frequency: '15' },
    { id: 2, frequency: '30' },
    { id: 3, frequency: '45' },
    { id: 4, frequency: '60' },
  ];
  shiftError: boolean = false;
  morningShifts: boolean = true
  startTimeVariable = null;
  startTimeEvening = '12:00 pm';

  // isCreate = true;
  constructor(
    private fb: FormBuilder,
    private doctorService: DoctorService,
    private hospitalService: HospitalService,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    public dialogRef: MatDialogRef<AddScheduleComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.doctorId = data;
    if (this.doctorId != '') {
      let obj = {
        id: this.doctorId,
      };
      this.getDoctorById(obj);
    }

    if (this.doctorId != '') {
      let obj = {
        id: this.doctorId,
      };
      this.getScheduleDoctorListbyId(obj);
    }

    this.createForm();
    this.getHospitalList();
  }
  getDoctorById(doctorId: any) {
    this.doctorService.getDoctorById(doctorId).subscribe((res: any) => {
      this.doctorData = res.result;
      // this.doctorData = [res.result];
      this.scheduleForm.controls['doctorId'].setValue(
        this.doctorData.doctorId
      );
      this.scheduleForm.controls['tenantId'].setValue(
        this.doctorData.tenantId
      );
      this.scheduleForm.controls['hospitalName'].setValue(
        this.doctorData.hospitalName
      );
    });
  }
  getScheduleDoctorListbyId(doctorId: any) {
    this.doctorService.getDoctorScheduleListByDoctorId(doctorId).subscribe((res: any) => {
      this.scheduleListData = res.result;
      if (this.scheduleListData && this.scheduleListData.length > 0) {
         this.isDataUpdated = true;
      } else {
         this.isDataUpdated = false;
        return;
      }
      let morningShift = this.scheduleListData.find((e) => e.shift == 1);
      let eveningShift = this.scheduleListData.find((e) => e.shift == 2);

      if (morningShift) {
        let startDateTime: any = new Date(morningShift.startDateTime);
        startDateTime = extractTimefromDate(startDateTime);
        let endDateTime: any = new Date(morningShift.endDateTime);
        endDateTime = extractTimefromDate(endDateTime);
        this.scheduleForm.patchValue({
          startDateTime: startDateTime,
          endDateTime: endDateTime,
          morningShift: true,
          frequency: morningShift.frequency,
          id: morningShift.id
        });
        this.morShiftCheck = true;
      } else {
        this.morShiftCheck = false;
        this.scheduleForm.controls['morningShift'].setValue(false);
      }

      if (eveningShift) {
        this.eveShiftCheck = true;
        let startDateTimeE: any = new Date(eveningShift.startDateTime);
        startDateTimeE = extractTimefromDate(startDateTimeE);
        let endDateTimeE: any = new Date(eveningShift.endDateTime);
        endDateTimeE = extractTimefromDate(endDateTimeE);
        this.scheduleForm.patchValue({
          startDateTimeE: startDateTimeE,
          endDateTimeE: endDateTimeE,
          eveningShift: true,
          frequencyE: eveningShift.frequency,
          idE: eveningShift.id
        });
        this.scheduleForm.controls['startDateTimeE'].enable();
        this.scheduleForm.controls['endDateTimeE'].enable();
        this.scheduleForm.controls['eveningShift'].enable();
        this.scheduleForm.controls['frequencyE'].enable();
      } else {
        this.eveShiftCheck = false;
        this.scheduleForm.controls['eveningShift'].setValue(false);
      }
    });
  }


  createForm() {
    this.scheduleForm = this.fb.group({
      doctorId: new FormControl(),
      id: new FormControl(0),
      idE: new FormControl(0),
      hospitalName: new FormControl({ value: '', disabled: true }),
      frequency: new FormControl('', [Validators.required]),
      frequencyE: new FormControl({ value: '', disabled: true }, [
        Validators.required,
      ]),
      morningShift: new FormControl(true, [Validators.required]),
      eveningShift: new FormControl('', []),
      startDateTime: new FormControl('', [Validators.required]),
      endDateTime: new FormControl('', [Validators.required]),
      startDateTimeE: new FormControl({ value: '', disabled: true }, [
        Validators.required,
      ]),
      endDateTimeE: new FormControl({ value: '', disabled: true }, [
        Validators.required,
      ]),
      tenantId: new FormControl('', [Validators.required]),
    });

    this.scheduleForm.get('startDateTime').valueChanges.subscribe((res: any) => {
      let currentHours = res.split(':')[0];
      let currentMins = res.split(':')[1];
      currentMins = currentMins.substring(0, 2)
      if (currentMins == 55) {
        currentHours = parseInt(currentHours) + 1;
        currentMins = '00';
      } else {
        currentMins = (parseInt(currentMins) + 15).toString();
      }
      let currentZone = res.substring(res.length - 2);

      this.startTimeVariable = currentHours + ':' + currentMins + ' ' + currentZone;

    });

    this.scheduleForm.get('startDateTimeE').valueChanges.subscribe((res: any) => {
      let currentHours = res.split(':')[0];
      let currentMins = res.split(':')[1];
      currentMins = currentMins.substring(0, 2)
      if (currentMins == 55) {
        currentHours = parseInt(currentHours) + 1;
        currentMins = '00';
      } else {
        currentMins = (parseInt(currentMins) + 15).toString();
      }
      let currentZone = res.substring(res.length - 2);
      this.startTimeEvening = currentHours + ':' + currentMins + ' ' + currentZone;

    })


  }

  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }

  toggleAllFieldsForMorning(event: any) {
    this.morShiftCheck = event.checked;
    if (this.morShiftCheck) {
      this.scheduleForm.controls['frequency'].enable();
      this.scheduleForm.controls['startDateTime'].enable();
      this.scheduleForm.controls['endDateTime'].enable();
      this.scheduleForm.get('frequency')?.setValidators([Validators.required]);

    } else {
      this.scheduleForm.controls['frequency'].disable();
      this.scheduleForm.controls['startDateTime'].disable();
      this.scheduleForm.controls['endDateTime'].disable();


    }
  }
  toggleAllFields(event: any) {
    this.eveShiftCheck = event.checked;
    if (this.eveShiftCheck) {
      this.scheduleForm.controls['startDateTimeE'].enable();
      this.scheduleForm.controls['endDateTimeE'].enable();
      this.scheduleForm.controls['frequencyE'].enable();

    } else {
      this.scheduleForm.controls['startDateTimeE'].disable();
      this.scheduleForm.controls['endDateTimeE'].disable();
      this.scheduleForm.controls['frequencyE'].disable();
    }
  }

  submitPatientForm() {
    if (
      !this.scheduleForm.value.morningShift &&
      !this.scheduleForm.value.eveningShift
    ) {
      this.toasterService.showError('Error', 'Select atleast one shift');
      return;
    }
    var MObj = {};
    var EObj = {};
    if (this.scheduleForm.value.morningShift) {
      MObj = {
        doctorId: this.doctorId,
        frequency: this.scheduleForm.value.frequency,
        shift: this.scheduleForm.value.morningShift === true ? 1 : '',
        startDateTime: this.scheduleForm.value.startDateTime,
        endDateTime: this.scheduleForm.value.endDateTime,
        tenantId: this.scheduleForm.value.tenantId,
        id: this.scheduleForm.value.id
      };
    }
    if (this.scheduleForm.value.eveningShift) {
      EObj = {
        doctorId: this.doctorId,
        frequency: this.scheduleForm.value.frequencyE,
        shift: this.scheduleForm.value.eveningShift === true ? 2 : '',
        startDateTime: this.scheduleForm.value.startDateTimeE,
        endDateTime: this.scheduleForm.value.endDateTimeE,
        tenantId: this.scheduleForm.value.tenantId,
        id: this.scheduleForm.value.idE
      };
    }

    var resultObj = [MObj, EObj].filter(
      (value) => Object.keys(value).length !== 0
    );   
    if(this.scheduleForm.value.Id>0)
    {
      this.isDataUpdated = true;
    }
    this.doctorService.createDoctorSchedule(resultObj).subscribe((res: any) => {
      if (res.success) {

        if (this.scheduleForm.value.idE == 0 && this.scheduleForm.value.id == 0) {
          this.toasterService.showSuccess(ConstantsMessage.DOCTOR_SCHEDULE_CREATE, '');
        } else {
          this.toasterService.showSuccess(ConstantsMessage.DOCTOR_SCHEDULE_UPDATE, '');
        }
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });



  }
  resetScheduleForm() {
    this.scheduleForm.reset();
  }
}
