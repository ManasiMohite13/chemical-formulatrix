import {
  ChangeDetectorRef,
  Component,
  Inject,
  OnInit,
  Optional,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

@Component({
  selector: 'app-edit-schedule',
  templateUrl: './edit-schedule.component.html',
  styleUrls: ['./edit-schedule.component.scss']
})
export class EditScheduleComponent {

  updatescheduleForm!: FormGroup;
  hospitalList: any;
  doctorId: any;
  eveShiftCheck: any;
  morShiftCheck = true;
  doctorData: any = [];
  frequenySlot: any = [
    { id: 1, frequency: '15' },
    { id: 2, frequency: '30' },
    { id: 3, frequency: '45' },
    { id: 4, frequency: '60' },
  ];
  shiftError:boolean=false;
  morningShifts:boolean=true
    constructor(
    private fb: FormBuilder,
    private doctorService: DoctorService,
    private router: Router,
    private hospitalService: HospitalService,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    public dialogRef: MatDialogRef<EditScheduleComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.doctorId = data;
    if (this.doctorId != '') {
      let obj = {
        id: this.doctorId,
      };
      this.getDoctorById(obj);
    }
    this.createForm();
    this.getHospitalList();
  }
  getDoctorById(doctorId: any) {
    this.doctorService.getDoctorById(doctorId).subscribe((res: any) => {
      this.doctorData = res.result;
      this.doctorData = [res.result];
      this.updatescheduleForm.controls['doctorId'].setValue(
        this.doctorData[0].doctorId
      );
      this.updatescheduleForm.controls['tenantId'].setValue(
        this.doctorData[0].tenantId
      );
    });
  }
  createForm() {
    this.updatescheduleForm = this.fb.group({
      id:new FormControl(),
      doctorId: new FormControl(),
      frequency: new FormControl('', [Validators.required]),
      frequencyE: new FormControl({ value: '', disabled: true }, [
        Validators.required,
      ]),
      morningShift: new FormControl('', [Validators.required]),
      eveningShift: new FormControl('', []),
      startDateTime: new FormControl('', [Validators.required]),
      endDateTime: new FormControl('', [Validators.required]),
      startDateTimeE: new FormControl({ value: '', disabled: true }, [
        Validators.required,
      ]),
      endDateTimeE: new FormControl({ value: '', disabled: true }, [
        Validators.required,
      ]),
      tenantId: new FormControl('', [Validators.required]),
    });
  }
  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }

  toggleAllFieldsForMorning(event: any) {
    this.morShiftCheck = event.checked;
    if (this.morShiftCheck) {
      this.updatescheduleForm.controls['frequency'].enable();
      this.updatescheduleForm.controls['startDateTime'].enable();
      this.updatescheduleForm.controls['endDateTime'].enable();
      this.updatescheduleForm.get('frequency')?.setValidators([Validators.required]);

    } else {
      this.updatescheduleForm.controls['frequency'].disable();
      this.updatescheduleForm.controls['startDateTime'].disable();
      this.updatescheduleForm.controls['endDateTime'].disable();

    } 
  }
  toggleAllFields(event: any) {
    this.eveShiftCheck = event.checked;
    if (this.eveShiftCheck) {
      this.updatescheduleForm.controls['startDateTimeE'].enable();
      this.updatescheduleForm.controls['endDateTimeE'].enable();
      this.updatescheduleForm.controls['frequencyE'].enable();

    } else {
      this.updatescheduleForm.controls['startDateTimeE'].disable();
      this.updatescheduleForm.controls['endDateTimeE'].disable();
      this.updatescheduleForm.controls['frequencyE'].disable();
    }
  }

  submitPatientForm() {
    if (
      !this.updatescheduleForm.value.morningShift &&
      !this.updatescheduleForm.value.eveningShift
    ) {
      this.toasterService.showError('Error', 'Select atleast one shift');
      return;
    }
    var MObj = {};
    var EObj = {};
    if (this.updatescheduleForm.value.morningShift) {
      MObj = {
        id:this.updatescheduleForm.value.id,
        doctorId: this.doctorId,
        frequency: this.updatescheduleForm.value.frequency,
        shift: this.updatescheduleForm.value.morningShift === true ? 1 : '',
        startDateTime: this.updatescheduleForm.value.startDateTime,
        endDateTime: this.updatescheduleForm.value.endDateTime,
        tenantId: this.updatescheduleForm.value.tenantId,
      };
    }
    if (this.updatescheduleForm.value.eveningShift) {
      EObj = {
        id:this.updatescheduleForm.value.id,
        doctorId: this.doctorId,
        frequency: this.updatescheduleForm.value.frequencyE,
        shift: this.updatescheduleForm.value.eveningShift === true ? 2 : '',
        startDateTime: this.updatescheduleForm.value.startDateTimeE,
        endDateTime: this.updatescheduleForm.value.endDateTimeE,
        tenantId: this.updatescheduleForm.value.tenantId,
      };
    }

    var resultObj = [MObj, EObj].filter(
      (value) => Object.keys(value).length !== 0
    );

    this.doctorService.createDoctorSchedule(resultObj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(
          ConstantsMessage.DOCTOR_SCHEDULE_CREATE,
          ''
        );
        this.router.navigate(['pages/admin/doctor']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
  resetupdatescheduleForm() {
    this.updatescheduleForm.reset();
  }
}
