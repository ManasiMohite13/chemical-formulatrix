import { LOCALE_ID, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppoinmentComponent } from './appoinment/appoinment.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DoctorsComponent } from './doctors/doctors.component';
import { PatientsComponent } from './patients/patients.component';
import { PaymentComponent } from './payment/payment.component';
import { RoomComponent } from './room/room.component';
import { StaffComponent } from './staff/staff.component';
import { AdminComponent } from './admin.component';
import { AdminRoutingModule } from './admin-routing.module';
import { AddAppoinmentComponent } from './appoinment/add-appoinment/add-appoinment.component';
import { AddDoctorComponent } from './doctors/add-doctor/add-doctor.component';
import { AddPatientsComponent } from './patients/add-patients/add-patients.component';
import { RoomListComponent } from './room/room-list/room-list.component';
import { AddRoomComponent } from './room/add-room/add-room.component';
import { StaffListComponent } from './staff/staff-list/staff-list.component';
import { AddStaffComponent } from './staff/add-staff/add-staff.component';
import { LayoutModule } from 'src/app/layout/layout.module';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatSortModule } from '@angular/material/sort';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatSelectModule } from '@angular/material/select';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatBadgeModule } from '@angular/material/badge';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgScrollbarModule } from 'ngx-scrollbar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { EditDoctorsComponent } from './doctors/edit-doctors/edit-doctors.component';
import { EditPatientsComponent } from './patients/edit-patients/edit-patients.component';
import { EditRoomComponent } from './room/edit-room/edit-room.component';
import { EditStaffComponent } from './staff/edit-staff/edit-staff.component';
import {
  NgxMatDatetimePickerModule,
  NgxMatNativeDateModule,
  NgxMatTimepickerModule,
} from '@angular-material-components/datetime-picker';
import { FullCalendarModule } from '@fullcalendar/angular';
import { ViewAppoinmentComponent } from './appoinment/view-appoinment/view-appoinment.component';
import { HospitalComponent } from './hospital/hospital.component';
import { AddHospitalComponent } from './hospital/add-hospital/add-hospital.component';
import { EditHospitalComponent } from './hospital/edit-hospital/edit-hospital.component';
import { MatChipsModule } from '@angular/material/chips';
import { MatExpansionModule } from '@angular/material/expansion';
import { UserComponent } from './user/user.component';
import { AddUserComponent } from './user/add-user/add-user.component';
import { ViewUserComponent } from './user/view-user/view-user.component';
import { PatientProfileComponent } from './patients/patient-profile/patient-profile.component';
import { AddScheduleComponent } from './doctors/add-schedule/add-schedule.component';
import { ViewPatientComponent } from './patients/view-patient/view-patient.component';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { UpdatePasswordComponent } from './user/update-password/update-password.component';
import { PatientCardComponent } from './patient-card/patient-card.component';
import { PatientSymtomsComponent } from './patient-card/patient-symtoms/patient-symtoms.component';
import { PatientExaminationComponent } from './patient-card/patient-examination/patient-examination.component';
import { PatientPlanComponent } from './patient-card/patient-plan/patient-plan.component';
import { PatientBasicDetailsComponent } from './patient-card/patient-basic-details/patient-basic-details.component';
import { SupportComponent } from './support/support.component';
import { EditSupportComponent } from './support/edit-support/edit-support.component';
import { AddSupportComponent } from './doctors/add-support/add-support.component';
import { AddPatientsSupportComponent } from './patients/add-patients-support/add-patients-support.component';
import { AddReceptionistSupportComponent } from './support/add-receptionist-support/add-receptionist-support.component';
import { LaboratoryComponent } from './laboratory/laboratory.component';
import { AddLaboratoryComponent } from './laboratory/add-laboratory/add-laboratory.component';
import { EditLaboratoryComponent } from './laboratory/edit-laboratory/edit-laboratory.component';
import { EditScheduleComponent } from './doctors/edit-schedule/edit-schedule.component';
import { RoleComponent } from './role/role.component';
import { AddRoleComponent } from './role/add-role/add-role.component';
import { EditRoleComponent } from './role/edit-role/edit-role.component';
import { ManagePermissionComponent } from './role/manage-permission/manage-permission.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ViewSupportComponent } from './support/view-support/view-support.component';
import { EditAppoinmentComponent } from './appoinment/edit-appoinment/edit-appoinment.component';
import { CancelAppoinmentComponent } from './patient-card/cancel-appoinment/cancel-appoinment.component';
import { PatientMedicineComponent } from './patient-card/patient-medicine/patient-medicine.component';
import { AppointmentListComponent } from './appoinment/appointment-list/appointment-list.component';
import { SpecilityComponent } from './hospital/specility/specility.component';
import { AddSpecilityComponent } from './hospital/specility/add-specility/add-specility.component';
import { ViewPatientAppointmentComponent } from './appoinment/view-patient-appointment/view-patient-appointment.component';
import { CancelAppointmentsComponent } from './patient-card/cancel-appoinment/cancel-appointments/cancel-appointments.component';
import { ManageFormsComponent } from './manage-forms/manage-forms.component';
import { AddEditTabComponent } from './manage-forms/add-edit-tab/add-edit-tab.component';
import { AddEditFormgroupComponent } from './manage-forms/add-edit-formgroup/add-edit-formgroup.component';
import { AddEditFormfieldComponent } from './manage-forms/add-edit-formfield/add-edit-formfield.component';
import { ManageTabComponent } from './manage-forms/manage-tab/manage-tab.component';
import { ManageFormgroupComponent } from './manage-forms/manage-formgroup/manage-formgroup.component';
import { ManageFormfieldComponent } from './manage-forms/manage-formfield/manage-formfield.component';
import { TransitionByPatientComponent } from './transition-by-patient/transition-by-patient.component';
import { TransitionBySourceComponent } from './transition-by-source/transition-by-source.component';
import { PrintPrescriptionPageComponent } from './patient-card/print-prescription-page/print-prescription-page.component';
import { ManageInventoryComponent } from './manage-inventory/manage-inventory.component';
import { AddInventoryComponent } from './manage-inventory/add-inventory/add-inventory.component';
import { EditInventoryComponent } from './manage-inventory/edit-inventory/edit-inventory.component';
import { PatientBillComponent } from './patient-bill/patient-bill.component';
import { AddNewBillComponent } from './patient-bill/add-new-bill/add-new-bill.component';
import { PrintPatientBillComponent } from './patient-bill/print-patient-bill/print-patient-bill.component';
import { NgxPrintModule } from 'ngx-print';


@NgModule({
  declarations: [
    AppoinmentComponent,
    DashboardComponent,
    DoctorsComponent,
    PatientsComponent,
    PaymentComponent,
    RoomComponent,
    StaffComponent,
    AdminComponent,
    AddAppoinmentComponent,
    AddDoctorComponent,
    AddPatientsComponent,
    RoomListComponent,
    AddRoomComponent,
    StaffListComponent,
    AddStaffComponent,
    EditDoctorsComponent,
    EditPatientsComponent,
    EditRoomComponent,
    EditStaffComponent,
    ViewAppoinmentComponent,
    HospitalComponent,
    AddHospitalComponent,
    EditHospitalComponent,
    UserComponent,
    AddUserComponent,
    ViewUserComponent,
    PatientProfileComponent,
    AddUserComponent,
    AddScheduleComponent,
    ViewPatientComponent,
    UpdatePasswordComponent,
    PatientCardComponent,
    PatientSymtomsComponent,
    PatientExaminationComponent,
    PatientPlanComponent,
    PatientBasicDetailsComponent,
    SupportComponent,
    EditSupportComponent,
    AddSupportComponent,
    AddPatientsSupportComponent,
    AddReceptionistSupportComponent,
    LaboratoryComponent,
    AddLaboratoryComponent,
    EditLaboratoryComponent,
    EditScheduleComponent,
    RoleComponent,
    AddRoleComponent,
    EditRoleComponent,
    ManagePermissionComponent,
    ViewSupportComponent,
    EditAppoinmentComponent,
    CancelAppoinmentComponent,
    PatientMedicineComponent,
    AppointmentListComponent,
    SpecilityComponent,
    AddSpecilityComponent,
    ViewPatientAppointmentComponent,
    CancelAppointmentsComponent,
    ManageFormsComponent,
    AddEditTabComponent,
    AddEditFormgroupComponent,
    AddEditFormfieldComponent,
    ManageTabComponent,
    ManageFormgroupComponent,
    ManageFormfieldComponent,
    TransitionByPatientComponent,
    TransitionBySourceComponent,
    ManageInventoryComponent,
    AddInventoryComponent,
    EditInventoryComponent,
    PatientBillComponent,
    AddNewBillComponent,
    PrintPatientBillComponent,
   
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    NgxPrintModule,
    LayoutModule,
    SharedModule,
    MatSidenavModule,
    MatToolbarModule,
    MatIconModule,
    MatTableModule,
    MatMenuModule,
    MatDialogModule,
    MatButtonModule,
    MatPaginatorModule,
    MatInputModule,
    MatIconModule,
    MatSlideToggleModule,
    MatMenuModule,
    MatButtonToggleModule,
    MatSortModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    MatDatepickerModule,
    MatSelectModule,
    MatNativeDateModule,
    MatCardModule,
    MatListModule,
    MatProgressBarModule,
    MatBadgeModule,
    MatCheckboxModule,
    MatRadioModule,
    FormsModule,
    ReactiveFormsModule,
    NgScrollbarModule,
    MatTabsModule,
    MatFormFieldModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule,
    FullCalendarModule,
    MatChipsModule,
    MatExpansionModule,
    NgxMaterialTimepickerModule,
    
  ],
})
export class AdminModule {}
