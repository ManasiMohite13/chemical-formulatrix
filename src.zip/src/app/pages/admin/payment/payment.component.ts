import { Component, Inject, Optional } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DateAdapter } from '@angular/material/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { PaymentOption } from 'src/assets/config/global-enums';
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss'],
})
export class PaymentComponent {
  minDate: Date;
  paymentForm!: FormGroup;
  yearList: any = [];
  appointmentId: any;
  monthList: any = [
    { Month: 'January', No: 1 },
    { Month: 'February', No: 2 },
    { Month: 'March', No: 3 },
    { Month: 'April', No: 4 },
    { Month: 'May', No: 5 },
    { Month: 'June', No: 6 },
    { Month: 'July', No: 7 },
    { Month: 'Augest', No: 8 },
    { Month: 'September', No: 9 },
    { Month: 'October', No: 10 },
    { Month: 'November', No: 11 },
    { Month: 'December', No: 12 }];
  showUPI: boolean = false;
  showCard: boolean = false;
  paymentOptions: any = [
    { id: 1, option: 'Cash' },
    { id: 2, option: 'UPI ID' },
    { id: 3, option: 'Card' }
  ];
  paymentSourceList: any = [];
  paymentSourceLists: any = []

  constructor(private fb: FormBuilder, private dateAdapter: DateAdapter<Date>, public hospitalService: HospitalService, public dialogRef: MatDialogRef<PaymentComponent>, @Optional() @Inject(MAT_DIALOG_DATA) public data: any, private patientService: PatientService,
    private toasterService: ToasterService) {
    this.minDate = this.dateAdapter.today();
    this.createForm();
    this.getYearList();
    this.appointmentId = data;
    this.getPaymentSource();
  }

  getPaymentSource() {
    let obj = {
      id: 1,
    }
    this.hospitalService.getLookUpTypeValueById(obj).subscribe((res: any) => {
      this.paymentSourceList = res.result;
      this.paymentSourceLists =  this.paymentSourceList.lookUpValues
    })
  }
  createForm() {
    this.paymentForm = this.fb.group(
      {
        id:new FormControl(),
        paymentType: new FormControl(null, [Validators.required]),
        notes: new FormControl(''),
        amount: new FormControl(null, [Validators.required, Validators.pattern(ConstantsMessage.EIGHT_NUMBER_PATTERN)]),
        name: new FormControl(null, [Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
        nextFollowUpdate: new FormControl(),

      }
    );
  }

  getYearList() {
    var currentYear = new Date().getFullYear();
    for (var i = currentYear; i <= (currentYear + 14); i++) {
      this.yearList.push(i)
    }
  }

  changeYear(data) {
    //console.log(data);
  }

  makePayment() {
    var obj = {
      id: this.appointmentId,
      paymentMode: this.paymentForm.value.paymentType,
      payAmount: this.paymentForm.value.amount,
      appointmentNotes: this.paymentForm.value.notes,
      nextFollowUpdate: this.paymentForm.value.nextFollowUpdate,
    }
    this.patientService.makePayment(obj).subscribe((res: any) => {
      this.toasterService.showSuccess(ConstantsMessage.PAYMENT_STATUS_UPDATE, '');
    });
  }

  changeOption(option: any) { }
  //   this.showUPI = false;
  //   this.showCard = false;

  //   this.paymentForm.removeControl('upiId');
  //   this.paymentForm.removeControl('cardNumber');
  //   this.paymentForm.removeControl('expiryDate');
  //   this.paymentForm.removeControl('cvc');
  //   this.paymentForm.removeControl('expiryMonth');
  //   this.paymentForm.removeControl('expiryYear');

  //   if (option == PaymentOption.UPI) {
  //     this.showUPI = true;
  //     this.paymentForm.addControl('upiId', new FormControl('', [Validators.required, Validators.pattern(ConstantsMessage.UPI_PATTERN)]));
  //   }
  //   else if (option == PaymentOption.Card) {
  //     this.showCard = true
  //     this.paymentForm.addControl('expiryMonth', new FormControl(null, [Validators.required]));
  //     this.paymentForm.addControl('expiryYear', new FormControl(null, [Validators.required]));
  //     this.paymentForm.addControl('cardNumber', new FormControl(null, [Validators.minLength(16), Validators.maxLength(16), Validators.required]));
  //     this.paymentForm.addControl('expiryDate', new FormControl(null, [Validators.minLength(4), Validators.maxLength(4), Validators.required]));
  //     this.paymentForm.addControl('cvc', new FormControl(null, [Validators.minLength(3), Validators.maxLength(3), Validators.required]));
  //   }
  // }
}
