import { DatePipe } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/shared/services/http.service';
import { SessionService } from 'src/app/shared/services/session.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { UserService } from 'src/app/shared/services/user.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { Priority, PriorityName, SupportTicket, SupportTicketsName } from 'src/assets/config/global-enums';

@Component({
  selector: 'app-view-support',
  templateUrl: './view-support.component.html',
  styleUrls: ['./view-support.component.scss']
})
export class ViewSupportComponent {

  userId:any
  editSupportForm!:FormGroup;
  priorityName=PriorityName;
  priority=Priority;
  id:any;
  supportData:any
  supportTicketsName=SupportTicketsName;
  supportTicket=SupportTicket;
  ticketNames=[{id:1,name:'Open'},{id:2,name:'Resolved'},{id:3,name:'In Progress'}];
  priorityList: any = [
    { id: 1, priority: 'High'},
    { id: 2, priority: 'Medium'},
    { id: 3, priority: 'Low'},

  ];
  constructor(private fb:FormBuilder,
    private dialog: MatDialog,
    private sessionService: SessionService,
    private toasterService: ToasterService,
    private userService:UserService,
    private httpService: HttpService,
    private router: Router,
    public datepipe: DatePipe,

    @Inject(MAT_DIALOG_DATA) public data:any,
  ) {
    this.createForm()
    this.userId = Number(this.httpService.getDecryptedValue('userId'));
    this.editSupportForm.patchValue({
      status:this.data.status,
    });
    if (this.id != '') {
      let obj = {
        id: Number(this.httpService.getDecryptedValue('supportId')),
      };
      this.getSupportById(obj);
    }
   
  }

  getSupportById(supportId:any){
    this.userService.getSupportById(supportId).subscribe((res: any) => {
      this.supportData = res.result;
      this.editSupportForm.patchValue({
        status:this.supportData.status,
        priority:this.supportData.priority,
        createdOn:this.datepipe.transform(this.supportData.createdOn, 'dd/MM/yyyy, hh:mm a'),
        description:this.supportData.description,
        resolutionDetails:this.supportData.resolutionDetails,
        title:this.supportData.title
        



      })
      });
   

}
  createForm(){
   this.editSupportForm=this.fb.group({
    id:new FormControl(),
    status:new FormControl({value:'',disabled:true}),
    priority:new FormControl({value:'',disabled:true}),
    createdOn:new FormControl({value:'',disabled:true}),
    description:new FormControl({value:'',disabled:true}),
    resolutionDetails:new FormControl({value:'',disabled:true}),
    title:new FormControl({value:'',disabled:true}),
   })
  }

  submitSupportForm(){
    let obj = {
      id:this.data.supportId,
      status:this.editSupportForm.value.status,
      priority:this.editSupportForm.value.priority,
      createdOn:this.editSupportForm.value.createdOn,
      description:this.editSupportForm.value.description,
      resolutionDetails:this.editSupportForm.value.resolutionDetails

    }
    this.userService.updateUserSupport(obj).subscribe((res:any)=>{
      if(res.success){
        this.toasterService.showSuccess(ConstantsMessage.TICKES_UPDATE,'');
        this.dialog.closeAll();
        this.router.navigate(['pages/admin/support']);        
      }
      else
      {
        this.toasterService.showError(res.error,'');

      }
    })
  }
}

