import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/shared/services/http.service';
import { SessionService } from 'src/app/shared/services/session.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { UserService } from 'src/app/shared/services/user.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { EditSupportComponent } from './edit-support/edit-support.component';
import { AuthService } from 'src/app/shared/services/auth.service';
import { ViewSupportComponent } from './view-support/view-support.component';
import { SupportTickets, TicketsSourceType } from 'src/assets/config/global-enums';
// import { SupportTickets, TicketsSourceType } from 'src/assets/config/global-enums';

function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}


@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.scss']
})
export class SupportComponent implements OnInit {
  displayedColumns: string[] = [
    'title',
    'description',
    'priority',
    'createdOn',
    'resolvedDate',
    'status',
    'Action',
  ];
  tempsupportData: any;
  isPatient: boolean = false;
  isDoctor: boolean = true;
  isReceptionist: boolean = false;
  isAll = false;
  isOpen = true;
  isInProgress = false;
  isResolved = false;
  TicketsSourceType = [
    { id: 3, name: "Doctor" },
    { id: 4, name: "Patient" },
    { id: 5, name: "Receptionist" },
  ];
  SupportTicketsList = [
    { id: 0, name: 'All' },
    { id: 1, name: 'Open' },
    { id: 2, name: 'InProgress' },
    { id: 3, name: 'Resolved' }
  ]

  data = []
  ticketsStatus = SupportTickets;
  ticketsSourceType: TicketsSourceType;
  public dataSource = new MatTableDataSource(supportData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  sourceType: number = 3;
  isCustomer: boolean;
  constructor(
    private dialog: MatDialog,
    private userService: UserService,
    private router: Router,
    private authservice: AuthService
  ) {
    this.getSupportList(this.sourceType, SupportTickets.Open);
    this.dialog.afterAllClosed.subscribe(() => {
      if (this.isDoctor == true) {
        if (this.isAll) {
          this.getSupportList(TicketsSourceType.Doctor, SupportTickets.All);

        }
        else if (this.isOpen) {
          this.getSupportList(TicketsSourceType.Doctor, SupportTickets.Open);

        }
        else if (this.isInProgress) {
          this.getSupportList(TicketsSourceType.Doctor, SupportTickets.InProgress);

        }
        else if (this.isResolved) {
          this.getSupportList(TicketsSourceType.Doctor, SupportTickets.Resolved);
        }

      }
      if (this.isPatient == true) {
        if (this.isAll) {
          this.getSupportList(TicketsSourceType.Patient, SupportTickets.All);

        }
        else if (this.isOpen) {
          this.getSupportList(TicketsSourceType.Patient, SupportTickets.Open);

        }
        else if (this.isInProgress) {
          this.getSupportList(TicketsSourceType.Patient, SupportTickets.InProgress);

        }
        else if (this.isResolved) {
          this.getSupportList(TicketsSourceType.Patient, SupportTickets.Resolved);
        }

      }
      if (this.isReceptionist == true) {
        if (this.isAll) {
          this.getSupportList(TicketsSourceType.Receptionist, SupportTickets.All);

        }
        else if (this.isOpen) {
          this.getSupportList(TicketsSourceType.Receptionist, SupportTickets.Open);

        }
        else if (this.isInProgress) {
          this.getSupportList(TicketsSourceType.Receptionist, SupportTickets.InProgress);

        }
        else if (this.isResolved) {
          this.getSupportList(TicketsSourceType.Receptionist, SupportTickets.Resolved);
        }

      }
    });

  }
  ngOnInit(): void {
    this.getSupportList(TicketsSourceType.Doctor, SupportTickets.Open);
  }

  sortData(sort: Sort) {
    const data = this.tempsupportData;
    if (!sort.active || sort.direction === '') {
      this.dataSource = data;
      return;
    }
    const isAsc = sort.direction === 'asc';
    const sortedData = data.sort((a: any, b: any) => {
      switch (sort.active) {
        case 'title':
          return compareString(a.title, b.title, isAsc);
        case 'description':
          return compareString(a.description, b.description, isAsc);
        case 'priority':
          return compareNumber(
            a.priority,
            b.priority,
            isAsc
          );
        case 'status':
          return compareNumber(a.status, b.status, isAsc);

        default:
          return 0;
      }
    });
    this.dataSource = new MatTableDataSource(sortedData);
    this.dataSource.paginator = this.paginator;
  }
  getDoctorTickets() {
    this.isPatient = false;
    this.isReceptionist = false;
    this.isDoctor = true;
    if (this.isAll == true) {
      this.getSupportList(TicketsSourceType.Doctor, SupportTickets.All);
    }
    else if (this.isOpen == true) {
      this.getSupportList(TicketsSourceType.Doctor, SupportTickets.Open);
    }
    else if (this.isInProgress == true) {
      this.getSupportList(TicketsSourceType.Doctor, SupportTickets.InProgress);
    }
    else if (this.isResolved == true) {
      this.getSupportList(TicketsSourceType.Doctor, SupportTickets.Resolved);
    }
  }

  getPatientSupportList() {
    this.isPatient = true;
    this.isDoctor = false;
    this.isReceptionist = false;
    if (this.isAll == true) {
      this.getSupportList(TicketsSourceType.Patient, SupportTickets.All);
    }
    else if (this.isOpen == true) {
      this.getSupportList(TicketsSourceType.Patient, SupportTickets.Open);
    }
    else if (this.isInProgress == true) {
      this.getSupportList(TicketsSourceType.Patient, SupportTickets.InProgress);
    }
    else if (this.isResolved == true) {
      this.getSupportList(TicketsSourceType.Patient, SupportTickets.Resolved);
    }
  }


  getReceSupportList() {
    this.isPatient = false;
    this.isDoctor = false;
    this.isReceptionist = true;
    if (this.isAll == true) {
      this.getSupportList(TicketsSourceType.Receptionist, SupportTickets.All);
    }
    else if (this.isOpen == true) {
      this.getSupportList(TicketsSourceType.Receptionist, SupportTickets.Open);
    }
    else if (this.isInProgress == true) {
      this.getSupportList(TicketsSourceType.Receptionist, SupportTickets.InProgress);
    }
    else if (this.isResolved == true) {
      this.getSupportList(TicketsSourceType.Receptionist, SupportTickets.Resolved);
    }
  }

  getSupportList(requestSource: any, status: any) {
    var tenantId = localStorage.getItem('tenantId');
    console.log("tenantId", tenantId);
    let obj = {
      tenantId: tenantId,
      requestSource: requestSource,
      status: status,
    }
    this.userService.getUserSupportList(obj).subscribe((res: any) => {
      if (res.success) {
        supportData = res.result;
        this.tempsupportData = res.result;
        if (res.result.length > 0) {
          this.dataSource = new MatTableDataSource(supportData);
        } else {
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(supportData);
        }
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });
  }

  getAll() {
    this.isAll = true;
    this.isOpen = false;
    this.isInProgress = false;
    this.isResolved = false;
    if (this.isDoctor == true) {
      this.getSupportList(TicketsSourceType.Patient, SupportTickets.All);
      this.getDoctorTickets();
    }
    else {
      this.getSupportList(TicketsSourceType.Receptionist, SupportTickets.All);
      this.getPatientSupportList();

    }


  }
  getOpen() {
    this.isAll = false;
    this.isOpen = true;
    this.isInProgress = false;
    this.isResolved = false;
    if (this.isDoctor == true) {
      this.getSupportList(TicketsSourceType.Doctor, SupportTickets.Open);
    }
    else {
      this.getSupportList(TicketsSourceType.Patient, SupportTickets.Open);

    }

  }
  getInProgress() {
    this.isAll = false;
    this.isOpen = false;
    this.isInProgress = true;
    this.isResolved = false;
    if (this.isDoctor == true) {
      this.getSupportList(TicketsSourceType.Doctor, SupportTickets.InProgress);

    }

    else {
      this.getSupportList(TicketsSourceType.Patient, SupportTickets.InProgress);

    }

  }
  getResolved() {
    this.isAll = false;
    this.isOpen = false;
    this.isInProgress = false;
    this.isResolved = true;
    if (this.isDoctor == true) {
      this.getSupportList(TicketsSourceType.Doctor, SupportTickets.Resolved);

    }
    else {
      this.getSupportList(TicketsSourceType.Patient, SupportTickets.Resolved);

    }

  }

  openEditSupport(supportId: any) {
    this.authservice.encryptKey('supportId', supportId);
    const confirmDialog = this.dialog.open(EditSupportComponent, {
      width: '500px',
      disableClose: true,
      data: {
        supportId
      },
    });
    confirmDialog.afterClosed().subscribe((result) => {
      this.getSupportList(this.sourceType, status);
      if (result === true) {
        this.router.navigate(['pages/admin/support']);
      }
    });
  }
  viewTicket(supportId: any) {
    this.authservice.encryptKey('supportId', supportId);
    const confirmDialog = this.dialog.open(ViewSupportComponent, {
      width: '500px',
      disableClose: true,
      data: {
        supportId
      },
    });
    confirmDialog.afterClosed().subscribe((result) => {
      this.getSupportList(this.sourceType, status);
      if (result === true) {
        this.router.navigate(['pages/admin/support']);
      }
    });



  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
}

export interface displayedColumns {
  id: number,
  title: string;
  description: string;
  createdOn: Date,
  resolvedDate: Date,
  priority: string;
  status: string;

}

let supportData: displayedColumns[];
