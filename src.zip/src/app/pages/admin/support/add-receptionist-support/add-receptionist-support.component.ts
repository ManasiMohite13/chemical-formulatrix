import { Component, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { UserService } from 'src/app/shared/services/user.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
// import { SupportTickets, TicketsSourceType } from 'src/assets/config/global-enums';

function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}


@Component({
  selector: 'app-add-receptionist-support',
  templateUrl: './add-receptionist-support.component.html',
  styleUrls: ['./add-receptionist-support.component.scss']
})
export class AddReceptionistSupportComponent {
  displayedColumns: string[] = [
    'title',
    'description',
    'priority',
    'createdOn',
    'resolvedDate',
    'status',
  ];
  priorityList: any = [
    { id: 1, priority: 'High'},
    { id: 2, priority: 'Medium'},
    { id: 3, priority: 'Low'},

  ];

  tempsupportData: any;
  isPatient:boolean=true;
  isDoctor:boolean=false;
  isReceptionist=false;
  isAll=false;
  isOpen=true;
  isInProgress=false;
  isResolved=false;
  TicketsSourceType = [
    {id:3,name:"Doctor"},
    {id:4,name:"Patient"},
    {id:5,name:"Receptionist"},
  ];
  data = []
  supportForm!:FormGroup;
  userId: any;
  settingsData: any;
  isAdmin: boolean = false;
  role: any;
  title: string = '';
  public dataSource = new MatTableDataSource(supportData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  sourceType : number = 4;
  constructor(
    private dialog: MatDialog,
    private toasterService: ToasterService,
    private userService:UserService,
    private router: Router,
    private fb:FormBuilder
  ) {
    this.createForm();
    this.getSupportList();
  }
  sortData(sort: Sort) {
    const data = this.tempsupportData;
    if (!sort.active || sort.direction === '') {
      this.dataSource = data;
      return;
    }
    const isAsc = sort.direction === 'asc';
    const sortedData = data.sort((a: any, b: any) => {
      switch (sort.active) {
        case 'title':
          return compareString(a.title, b.title, isAsc);
        case 'description':
          return compareString(a.description, b.description, isAsc);
        case 'priority':
          return compareNumber(
            a.priority,
            b.priority,
            isAsc
          );
        case 'status':
          return compareNumber(a.status, b.status, isAsc);

        default:
          return 0;
      }
    });
    this.dataSource = new MatTableDataSource(sortedData);
    this.dataSource.paginator = this.paginator;
  }
  support(templateRef: TemplateRef<any>) {
    this.supportForm.reset();
    const confirmDialog = this.dialog.open(templateRef, {
      width: '550px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
      }
    });
  }

  getSupportList() {
      this.userService.getSupportUserById().subscribe((res: any) => {
      if (res.success) {
        supportData = res.result;
        this.tempsupportData = res.result;
        if (res.result.length > 0) {
          this.dataSource = new MatTableDataSource(supportData);
        } else {
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(supportData);
        }
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });
  }
  // openEditSupport(supportId:any){
  //   this.dialog.open(EditSupportComponent,{
  //     width:"350px",
  //     data:Number(supportId),
  //   });
  // }

  // openEditSupport(supportId: any,status:any) {
  //   const confirmDialog = this.dialog.open(EditSupportComponent, {
  //     width: '350px',
  //     disableClose: true,
  //     data: {
  //       supportId,
  //       status
  //     },
  //   });
  //   confirmDialog.afterClosed().subscribe((result) => {
  //     this.getSupportList(this.sourceType);
  //     if (result === true) {
  //       this.router.navigate(['pages/admin/support']);
  //     }
  //   });
  // }
  createForm(){
    this.supportForm=this.fb.group({
      title:new FormControl('',[Validators.required, Validators.pattern(ConstantsMessage.ONLY_LETTERS_WITH_SPACE)]),
      description:new FormControl('',[Validators.required,Validators.maxLength(100)]),
      priority:new FormControl('',[Validators.required]),
      assignedTo:new FormControl(),
      assignedBy:new FormControl(),

    })
  }
  submitSupportForm(){
    let obj={
      title:this.supportForm.value.title,
      description:this.supportForm.value.description,
      priority:this.supportForm.value.priority,
      assignedTo:this.supportForm.value.assignedTo,
      assignedBy:this.supportForm.value.assignedBy
    }
    this.userService.craeteUserSupport(obj).subscribe((res:any)=>{
      if(res.success){
      this.toasterService.showSuccess(ConstantsMessage.SUPPORT_CREATE,'');
      this.getSupportList();
      }
      else {
        this.toasterService.showError(res.errors, '');

      }
      this.supportForm.reset();
    })
    
    
  }
  
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
}

export interface displayedColumns {
  id:number,
  title: string;
  description: string;
  priority: string;
  createdOn:Date,
  resolvedDate:Date
  status: string;
 
}

let supportData: displayedColumns[];

