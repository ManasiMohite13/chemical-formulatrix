import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddReceptionistSupportComponent } from './add-receptionist-support.component';

describe('AddReceptionistSupportComponent', () => {
  let component: AddReceptionistSupportComponent;
  let fixture: ComponentFixture<AddReceptionistSupportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddReceptionistSupportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddReceptionistSupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
