import { Component, ElementRef, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import {
  Calendar,
} from '@fullcalendar/core';

import { MatDialog } from '@angular/material/dialog';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { DatePipe, Time } from '@angular/common';
import { FullCalendarComponent } from '@fullcalendar/angular';
import { AuthService } from 'src/app/shared/services/auth.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { TransactionService } from 'src/app/shared/services/transaction.service';
import { AddNewBillComponent } from './add-new-bill/add-new-bill.component';

@Component({
  selector: 'app-patient-bill',
  templateUrl: './patient-bill.component.html',
  styleUrls: ['./patient-bill.component.scss']
})
export class PatientBillComponent {
  appoinmentForm!: FormGroup;
  totalRowCount = 0;
  isListView = true; 
  userProfile: boolean = true;
  userChangePassword: boolean = false
  transactionData: any = [];
  public dataSource = new MatTableDataSource(transactionData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  hospitalList: any;
  hospitalData: any;
  roleId: any;
  openPrintpage = false;
  currentAppointmentId: any
  displayedColumns: string[] = [
    'transactionNumber',
    'transactionDate',
    'patientName',
    'gender',    
    'paymentSource',
    'Action',
  ];
  convertedTime: any;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    public datepipe: DatePipe,
    private httpService: HttpService,
    private dialogRef: MatDialog,
    private transactionService:TransactionService,
    private authservice:AuthService,
    private datePipe: DatePipe) {
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.createForm();
    this.getTransactionList();
  }

  resetForm() {
    this.appoinmentForm.reset();
    this.createForm();
  }

  addNewBill(){
   this.router.navigate(['/pages/admin/add-new-bill'])
  }

  getTransactionList() {
    const datePipe = new DatePipe('en-US');
    let obj = {
      tenantId: '00000000-0000-0000-0000-000000000000',
      transcationDate:datePipe.transform(this.appoinmentForm.value.transcationDate ,'MM/dd/yyyy' ),
      transcationNumber:null
    }
    this.transactionService.getTransactionList(obj).subscribe((res: any) => {
      if (res.success) {
        transactionData = res.result;
        if (res.result.length > 0) {
          this.dataSource = new MatTableDataSource(transactionData);
        } else {
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(transactionData);
        }
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });
  }

  createForm() {
    this.appoinmentForm = this.formBuilder.group({
      tenantId:new FormControl(),
      transcationDate : new FormControl(this.datePipe.transform(new Date(), 'yyyy-MM-dd')),
    });
    this.getTransactionList();
  }


  printBill(patientId:any,transactionNumber:any){
    this.authservice.encryptKey('patientId', patientId);
    this.authservice.encryptKey('transactionNumber', transactionNumber);

    this.router.navigate(['/pages/admin/print-bill'])
  }
}

export interface displayedColumns {
  transactionNumber: string;
  patientName: string;
  transactionDate: Date;
  paymentSource: number;
  doctorName: string
}
let transactionData: displayedColumns[];


