import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/shared/services/http.service';
import { RoleService } from 'src/app/shared/services/role.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { UserService } from 'src/app/shared/services/user.service';
import { ValidationService } from 'src/app/shared/validation.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { AddUserComponent } from '../../user/add-user/add-user.component';
import { TransactionService } from 'src/app/shared/services/transaction.service';
import { InventoryService } from 'src/app/shared/services/inventory.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { ConstantsRoutes } from 'src/assets/config/constants-routes';
import { PatientService } from 'src/app/shared/services/patient.service';
import { OnInit, TemplateRef, ViewChild } from '@angular/core';
import {
  AbstractControl,
  FormArray,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { BehaviorSubject } from 'rxjs';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { AuthService } from 'src/app/shared/services/auth.service';
import { MatSelectChange } from '@angular/material/select';
import { DatePipe } from '@angular/common';

export interface PeriodicElement {
  medicineName: string;
  description: string;
  qty: string;
  salePrice: string;
  amount: number;
}

const ELEMENT_DATA: PeriodicElement[] = [];
@Component({
  selector: 'app-add-new-bill',
  templateUrl: './add-new-bill.component.html',
  styleUrls: ['./add-new-bill.component.scss']
})
export class AddNewBillComponent {
  medicineForm: FormGroup;
  private voDataSubject = new BehaviorSubject<any>(null);
  voData$ = this.voDataSubject.asObservable();
  displayedColumns: string[] = [
    'medicineName',
    'description',
    'qty',
    'salePrice',
    'amount',
    'action'
  ];
  qtyOptions = [' 1', ' 2', ' 3'];
  selectedqty: string = '';
  dataSource = new MatTableDataSource<any>();
  medicineMasterList: any
  isLoading = true;
  patientId: any;
  appointmentId: any;
  medicineData: any
  maxDate = new Date();
  pageNumber: number = 1;
  VOForm: FormGroup;
  medicineListCopy: any
  isEditableNew: boolean = true;
  minDate = new Date();
  addNewPatientForm!: FormGroup;
  hospitalList: any;
  hospitalListCopy: any = [];
  refreanceListing: any;
  tenantId: any;
  TransactionNumber: any;
  salePrice: any;
  roleId: any;
  paymentSource: any;
  name: any;
  drOrPatientantId: any;
  hide: boolean = true;
  visible: boolean = true;
  trasactionNumber: any
  roleData: any;
  patientList: any;
  itemList: any;
  passwordInfo: string = ConstantsMessage.VALIDATION_PASSWORD_MESSAGE_INFO;
  serializedObject: any
  selectedHospital: any;
  paymentSourceList: any;
  paymentSourceLists: any;
  hospitalListData: any;
  hospitalListCopyData: any;
  addressDetails: any;
  hospitalPic: any; selectedPatientId: number;
  selectedGender: string;
  patientDeatils: any;
  hospitalData: any;
  patientAddress: any;
  requestArray: any; transcationDetails: any[] = [];
  currentDate: Date = new Date();
  today = new Date();
  birthDate: any
  statusList = [{ id: 1, name: 'Paid' }, { id: 2, name: 'Unpaid' }]
  age: number;
  constructor(
    private httpService: HttpService,
    private router: Router,
    private toasterService: ToasterService,
    private trasactionService: TransactionService,
    private inventoryService: InventoryService,
    private hospitalService: HospitalService,
    private patientService: PatientService,
    private datePipe: DatePipe,
    private fb: FormBuilder, private authService: AuthService, private _formBuilder: FormBuilder, private dialog: MatDialog, private http: HttpService,

  ) {
    // this.today = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.createForm();
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.getTranscationNumber();
    this.getPatientList();
    this.getItemList();
    this.getPaymentSource();
    this.getHospitalById();
    this.getPatientById()
  }


  ngOnInit(): void {
    this.VOForm = this._formBuilder.group({
      VORows: this._formBuilder.array([]),
    });

    this.dataSource = new MatTableDataSource();
    this.dataSource.data = (this.VOForm.get('VORows') as FormArray).controls;
    this.dataSource.paginator = this.paginator;

    const filterPredicate = this.dataSource.filterPredicate;
    this.dataSource.filterPredicate = (data: AbstractControl, filter) => {
      return filterPredicate.call(this.dataSource, data.value, filter);
    };

  }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  goToPage() {
    this.paginator.pageIndex = this.pageNumber - 1;
    this.paginator.page.next({
      pageIndex: this.paginator.pageIndex,
      pageSize: this.paginator.pageSize,
      length: this.paginator.length,
    });
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.paginatorList = document.getElementsByClassName(
      'mat-paginator-range-label'
    );


  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  AddNewRow(dataToPopulate = null, isLoadingTime = false) {

    const control = this.VOForm.get('VORows') as FormArray;
    if (control.length == 0) {
      control.push(this.initiateVOForm(dataToPopulate));
    } else {
      const data = control.controls[control.length - 1];
      control.removeAt(control.length - 1)
      control.push(this.initiateVOForm(dataToPopulate));
      control.push(data);

    }

    if (control.length == 1) {
      control.push(this.initiateVOForm(dataToPopulate, true));
    }
    this.dataSource = new MatTableDataSource(control.controls);

  }

  EditSVO(VOFormElement, i) {
    VOFormElement.get('VORows').at(i).get('isEditable').patchValue(false);
  }

  saveVO(index = null) {
    let voData;

    if (index === null) {
      voData = this.VOForm.get('VORows').value;
    } else {
      const fArray = this.VOForm.get('VORows') as FormArray;
      voData = [fArray.at(index).value];
    }

    this.transcationDetails.push(...voData);

    this.voDataSubject.next(this.transcationDetails);
  }



  CancelSVO(VOFormElement, i) {
    VOFormElement.get('VORows').at(i).get('isEditable').patchValue(true);
  }

  deleteRo(index: number) {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CONFIRM,
        message: ConstantsMessage.DELETE_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        const control = this.VOForm.get('VORows') as FormArray;
        control.removeAt(index);
        this.dataSource.data = control.controls;
        this.toasterService.showSuccess(
          ConstantsMessage.TABLE_ROW_DELETE,
          ''
        );


      }
    });
  }
  deleteRow(rowIndex: number) {
    const control = this.VOForm.get('VORows') as FormArray;
    control.removeAt(rowIndex);
    if(control.length == 1){
      control.removeAt(0);
      }
    this.dataSource.data = control.controls;

    for (let i = 0; i < control.length; i++) {
      this.calculateAmount(i);
    }
    
  }
  
  
  initiateVOForm(patchdata = null, isLoadingTime = false): FormGroup {
    if (isLoadingTime) {
      return this.fb.group({
        itemId: new FormControl(''),
        qty: new FormControl(''),
        price: new FormControl(''),
        description: new FormControl(''),
        totalAmount: new FormControl(''),


      });
    } else {
      return this.fb.group({
        itemId: new FormControl(patchdata ? patchdata.itemId : ''),
        qty: new FormControl(patchdata ? patchdata.qty : ''),
        price: new FormControl(patchdata ? patchdata.salePrice : ''),
        description: new FormControl(patchdata ? patchdata.description : ''),
        amount: new FormControl(patchdata ? patchdata.amount : ''),

      });
    }
  }

  dateFilter = (date: Date): boolean => {
    return date >= this.minDate;
  }
  paginatorList: HTMLCollectionOf<Element>;
  idx: number;

  createForm() {
    const datePipe = new DatePipe('en-US');
    this.addNewPatientForm = this.fb.group(
      {
        TransactionNumber: new FormControl({ value: this.trasactionNumber, disabled: true }),
        paymentSource: new FormControl('', []),
        patientId: new FormControl('', [Validators.required]),
        description: new FormControl('', []),
        status: [2],
        qty: new FormControl(),
        itemId: new FormControl(),
        price: new FormControl(''),
        transactionDate: new FormControl(new Date()),
      },

    );
  }

  getHospitalById() {
    this.hospitalService.getHospitalById(0).subscribe((res: any) => {
      if (res.success) {
        this.hospitalListData = res.result;
        this.addressDetails = this.hospitalListData.addressDetails;
        this.hospitalPic = ConstantsRoutes.Main_URL + this.hospitalListData.hospitalLogo;
        console.log('hospitalListData', this.hospitalListData)
        this.hospitalListCopyData = this.hospitalListData;
      }
    });
  }

  updateGender() {
    const selectedPatient = this.hospitalListCopy.find(patient => patient.id === this.selectedPatientId);

    if (selectedPatient) {
      this.selectedGender = selectedPatient.gender === 1 ? 'Male' : selectedPatient.gender === 2 ? 'Female' : 'Unknown';
    } else {
      this.selectedGender = '';
    }
  }

  getTranscationNumber() {
    this.trasactionService.getTransactionNumber().subscribe((res: any) => {
      this.trasactionNumber = res.result;
    })
  }
  getPatientList() {
    this.trasactionService.getPatientListByTenantId().subscribe((res: any) => {
      this.patientList = res.result;
      this.hospitalListCopy = this.patientList;
      console.log('hospitalListCopy', this.hospitalListCopy)
    })
  }
  onMedicineSelection(event: any, rowIndex: number, selectedOption: any) {
    const selectedItemId = event.value;
    const selectedMedicine = this.itemList.find(item => item.id === selectedItemId);
    const row = this.getVORowAtIndex(rowIndex);

    if (selectedMedicine) {
      // Set the values in the form controls
      row.get('price').setValue(selectedMedicine.salePrice);
      row.get('description').setValue(selectedMedicine.description);

      // Check if quantity is not null before calculating amount
      if (row.get('qty').value !== null) {
        const amount = selectedMedicine.salePrice * row.get('qty').value;
        row.get('amount').setValue(amount);
      }
    }
  }





  calculateAmount(index: number) {
    const VORows = this.VOForm.get('VORows') as FormArray;
    const salePriceControl = VORows.at(index).get('price');
    const qtyControl = VORows.at(index).get('qty');
    const amountControl = VORows.at(index).get('amount');

    if (salePriceControl.valid && qtyControl.valid) {
      const salePrice = parseFloat(salePriceControl.value);
      const qty = parseFloat(qtyControl.value);
      const amount = salePrice * qty;
      amountControl.setValue(amount);
    } else {
    }
    let fullAmount = 0
    VORows.controls.forEach((element: any, index) => {
      if (VORows.controls.length - 1 != index) {
        fullAmount += parseInt(element.controls['amount'].value);
      }



    });
    VORows.controls[VORows.controls.length - 1].get('totalAmount').setValue(fullAmount)
  }




  getVORowAtIndex(index: number): FormGroup {
    const VORows = this.VOForm.get('VORows') as FormArray;
    return VORows.at(index) as FormGroup;
  }


  getItemList() {
    let obj = {
      tenantId: '00000000-0000-0000-0000-000000000000'
    }
    this.inventoryService.getItemTransactionList(obj).subscribe((res: any) => {
      this.itemList = res.result
    })

  }

  getPaymentSource() {
    let obj = {
      id: 1,
    }
    this.hospitalService.getLookUpTypeValueById(obj).subscribe((res: any) => {
      this.paymentSourceList = res.result;
      this.paymentSourceLists = this.paymentSourceList.lookUpValues
    })
  }
  changeHospital(event: any) {
    this.hospitalData = event;
    this.getPatientById()
  }

  getPatientById() {
    let obj = {
      id: this.hospitalData,
      tenantId: '00000000-0000-0000-0000-000000000000'
    };

    this.patientService.getPatientById(obj).subscribe((res: any) => {
      this.patientDeatils = res.result;
      this.birthDate = this.patientDeatils.dateOfBirth;
      this.patientAddress = this.patientDeatils.patientAddress;

      // Calculate age
      this.calculateAge();

    });
  }
  calculateAge() {
    const birthDate = new Date(this.birthDate);
    const today = new Date();

     this.age = today.getFullYear() - birthDate.getFullYear();
    let ageMonths = today.getMonth() - birthDate.getMonth();

    if (today.getDate() < birthDate.getDate()) {
        ageMonths--;
    }

    if (ageMonths < 0) {
        this.age--;
        ageMonths += 12;
    }
    console.log('Age:', this.age, 'years and', ageMonths, 'months');
}



  autoComplete(data) {
    this.hospitalListCopy = this.patientList.filter(option => option.patientName.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  submitPatientForm() {
    const fArray = this.VOForm.get('VORows') as FormArray;
    fArray.controls.forEach((element, index) => {
      if (!element.get('totalAmount')) {
        this.transcationDetails.push(fArray.at(index).value)
      }
    })

    
    const currentDate = new Date();
    var obj = {
      TransactionNumber: this.trasactionNumber,
      paymentSource: this.addNewPatientForm.value.paymentSource || 0,
      patientId: this.addNewPatientForm.value.patientId,
     // tenantId: this.addNewPatientForm.value.tenantId,
      status: this.addNewPatientForm.value.status,
      description: this.addNewPatientForm.value.description,
      transactionDate: this.datePipe.transform(this.addNewPatientForm.value.transactionDate  ) || new Date(),
      transcationDetails:
        this.transcationDetails

    };
    this.trasactionService.createTransaction(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.CREATE_BILL, '');
        // this.dialogRef.close({ result: true });
        this.router.navigate(['pages/admin/patient-bill']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }

  resetForm() {
    //this.addNewPatientForm.reset();
    this.router.navigate(['pages/admin/patient-bill']);
  }
}

