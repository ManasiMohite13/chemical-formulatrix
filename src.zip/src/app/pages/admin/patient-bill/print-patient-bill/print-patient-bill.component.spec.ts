import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintPatientBillComponent } from './print-patient-bill.component';

describe('PrintPatientBillComponent', () => {
  let component: PrintPatientBillComponent;
  let fixture: ComponentFixture<PrintPatientBillComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrintPatientBillComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrintPatientBillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
