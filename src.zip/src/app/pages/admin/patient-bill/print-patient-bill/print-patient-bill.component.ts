import {  AfterViewInit, Component, ElementRef, Renderer2, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { InventoryService } from 'src/app/shared/services/inventory.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { TransactionService } from 'src/app/shared/services/transaction.service';
import { ConstantsRoutes } from 'src/assets/config/constants-routes';
declare var shortcut;

@Component({
  selector: 'app-print-patient-bill',
  templateUrl: './print-patient-bill.component.html',
  styleUrls: ['./print-patient-bill.component.scss']
})
export class PrintPatientBillComponent implements AfterViewInit {
  @ViewChild('printContent', { static: false }) printContent: ElementRef;
  hospitalListData:any;
  addressDetails:any;  totalAmount: number = 0;
  hospitalPic:any;
  hospitalListCopyData:any;
  patientDeatils:any;
  patientAddress:any;
  hospitalData:any;
  patientList:any;
  hospitalListCopy:any;
  transactionData:any;
  transactionDetails:any;
  birthDate:any;
  descriptionData:any;
  patientId:any;
  transactionNumber :any = '0000';
  currentDate: Date = new Date();
  age: number;
  days:number;
  months:number;
  constructor(
    private httpService: HttpService,
    private router: Router,
    private el: ElementRef,
    private toasterService: ToasterService,
    private trasactionService: TransactionService,
    private inventoryService: InventoryService,
    private hospitalService: HospitalService,
    private patientService:PatientService,
    private renderer: Renderer2,
    private fb: FormBuilder, private authService: AuthService,  private _formBuilder: FormBuilder, private dialog: MatDialog, private http: HttpService,
  ) {
    this.getHospitalById();
    this.patientId = Number(this.http.getDecryptedValue('patientId'));
    this.transactionNumber = Number(this.http.getDecryptedValue('transactionNumber'));
    this.transactionNumber = this.transactionNumber.toString();
    this.transactionNumber = this.transactionNumber.padStart(6, '0'); // Assuming the original number has a maximum of 4 digits
    console.log('this.transactionNumber', this.transactionNumber);
    
    
    this.getPatientById();
    this.getPatientList();
    this.getTransactionList();

  }

  ngAfterViewInit(){
    // document.addEventListener('DOMContentLoaded', function(){
          // shortcut.add("ctrl+p", function() {
      // var myDiv = document.getElementById("printBillId").innerHTML;
      //     var oldPage = document.body.innerHTML;
      //     document.body.innerHTML = 
      //       "<html><head><title></title></head><body>" + 
      //       myDiv + "</body>";
      //     window.print();
      //     document.body.innerHTML = oldPage;
      //     });
    // })

    // window.addEventListener("afterprint", (event) => {
    //   console.log("After print");
    //   this.router.navigateByUrl('/pages/admin/patient-bill')  
    // });
  }

  getHospitalById() {
    this.hospitalService.getHospitalById(0).subscribe((res: any) => {
      if (res.success) {
        this.hospitalListData = res.result;
        this.addressDetails = this.hospitalListData.addressDetails;
        this.hospitalPic = ConstantsRoutes.Main_URL + this.hospitalListData.hospitalLogo;
        console.log('hospitalListData',this.hospitalListData)
        this.hospitalListCopyData = this.hospitalListData;
      }
    });
  }
  back() {
    
    this.router.navigate(['pages/admin/patient-bill'])
  }
  getPatientById() {
    
    let obj = {
      id: this.patientId ,
      tenantId:'00000000-0000-0000-0000-000000000000'
    };
    this.patientService.getPatientById(obj).subscribe((res: any) => {
      this.patientDeatils = res.result;
      this.birthDate = this.patientDeatils.dateOfBirth;

      console.log(' this.patientDeatils', this.patientDeatils)
      this.patientAddress =  this.patientDeatils.patientAddress;
      console.log('this.patientAddress',this.patientAddress);
      console.log('patientDeatils',this.patientDeatils);
      this.calculateAge();

    });
  }
  calculateAge() {
    const birthDate = new Date(this.birthDate);
    const today = new Date();
    
    this.age = today.getFullYear() - birthDate.getFullYear();
    this.months = today.getMonth() - birthDate.getMonth();
    this.days = today.getDate() - birthDate.getDate();
  
    if (this.months < 0 || (this.months === 0 && this.days < 0)) {
      this.age--;
      this.months += 12;
      // Calculate the number of days in the previous month
      const tempDate = new Date(today.getFullYear(), today.getMonth(), 0);
      const daysInPreviousMonth = tempDate.getDate();
      this.days = daysInPreviousMonth - birthDate.getDate() + today.getDate();
    }
  
    console.log('Age:', {
      years: this.age,
      months: this.months,
      days: this.days
    });
  }
  
  getPatientList() {
    this.trasactionService.getPatientListByTenantId().subscribe((res: any) => {
      this.patientList = res.result;
      this.hospitalListCopy = this.patientList;
    })
  }
  calculateTotalAmount() {
    if (this.transactionDetails) {
      this.totalAmount = this.transactionDetails.reduce((total, data) => total + data.amount, 0);
      return this.totalAmount;
    } else {
      return 0;
    }
  }
  
  

  getTransactionList() {
    let obj = {
      tenantId: '00000000-0000-0000-0000-000000000000',
      transcationDate:this.currentDate,
      transcationNumber:this.transactionNumber
    }
    this.trasactionService.getTransactionList(obj).subscribe((res: any) => {
      if (res.success) {
       this.transactionData = res.result;
       console.log(' this.transactionData1', this.transactionData[0].gender)
       console.log('this.transactionData',this.transactionData[0].description)
       this.descriptionData  = this.transactionData[0].description;
       this.transactionDetails = this.transactionData[0].transactionDetails;
       console.log(' this.transactionDetails', this.transactionDetails);

       
      }
    });
  }
  backPage(){
    this.router.navigate(['pages/admin/patient-bill'])
  }
  printPage() {
    // var myDiv = document.getElementById("printBillId").innerHTML;
    // var oldPage = document.body.innerHTML;
    // document.body.innerHTML = 
    //   "<html><head><title></title></head><body>" + 
    //   myDiv + "</body>";
    // window.print();
    // document.body.innerHTML = oldPage;
    const printContent = this.el.nativeElement.querySelector('#printBillId');

    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Print</title>
            </head>
            <body>
              ${printContent.innerHTML}
            </body>
          </html>
        `);

        printWindow.document.close();
        printWindow.print();
        printWindow.onafterprint = () => {
          // Handle after print event
          printWindow.close();
        };
      }
    }
  }

}
