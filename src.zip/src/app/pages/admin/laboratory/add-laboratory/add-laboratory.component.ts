import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { LaboratoryService } from 'src/app/shared/services/laboratory.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ConstantsRoutes } from 'src/assets/config/constants-routes';

@Component({
  selector: 'app-add-laboratory',
  templateUrl: './add-laboratory.component.html',
  styleUrls: ['./add-laboratory.component.scss']
})
export class AddLaboratoryComponent {

  addLaboratoryForm!: FormGroup;
  hospitalList: any;
  roleId: any;
  @Input() max: any;
  tomorrow = new Date();
  laboratoryData: any = [];
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private hospitalService: HospitalService,
    private httpService: HttpService,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    private laboratoryService:LaboratoryService
  ) {
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));

    this.createForm();
    this.getHospitalList();
    this.getLaboratoryList();
  }
  createForm() {
    this.addLaboratoryForm = this.fb.group({
      labName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      contactPersonName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      phoneNo1: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
    
      address1: new FormControl('', [ Validators.pattern(ConstantsMessage.ONLY_ADDRESS),]),
      address2: new FormControl('', [ Validators.pattern(ConstantsMessage.ONLY_ADDRESS),]),
    
      email: new FormControl('', [Validators.required,Validators.email,
      ]),
      city:new FormControl('',[ Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      district:new FormControl('',[ Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      state:new FormControl('',[ Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      zipCode:new FormControl('',[Validators.pattern(ConstantsMessage.ZIP_CODE_PATTERN)]),
       tenantId: new FormControl(Validators.required),
    });
  }

  submitLaboratoryForm() {
    var obj = {
      labName: this.addLaboratoryForm.value.labName,
      contactPersonName: this.addLaboratoryForm.value.contactPersonName,
      phoneNo1: this.addLaboratoryForm.value.phoneNo1,
      address1: this.addLaboratoryForm.value.address1,
      address2: this.addLaboratoryForm.value.address2,
      email: this.addLaboratoryForm.value.email,
      city:this.addLaboratoryForm.value.city,
      district:this.addLaboratoryForm.value.district,
      state:this.addLaboratoryForm.value.state,
      zipCode:this.addLaboratoryForm.value.zipCode,
      tenantId: this.addLaboratoryForm.value.tenantId || '00000000-0000-0000-0000-000000000000',
    };
    this.laboratoryService.createLaboratoryMaster(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.CREATE_LABORATORY, '');      
        this.getLaboratoryList();
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }

  getLaboratoryList() {
    var tenantId = localStorage.getItem('tenantId');    
    let obj = {
      tenantId: tenantId,     
    }    
        this.laboratoryService.getLaboratoryMasterList(obj).subscribe((res: any) => {
          if (res.success) {
            this.laboratoryData = res.result;    
          }        
      });    
  }

  resetLaboratoryForm() {
    this.router.navigate(['/pages/admin/laboratory'])
  }
}
