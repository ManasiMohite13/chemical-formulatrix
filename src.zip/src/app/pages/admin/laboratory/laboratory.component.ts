import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { AddScheduleComponent } from '../doctors/add-schedule/add-schedule.component';
import { AddLaboratoryComponent } from './add-laboratory/add-laboratory.component';
import { LaboratoryService } from 'src/app/shared/services/laboratory.service';
import { EditLaboratoryComponent } from './edit-laboratory/edit-laboratory.component';
import { ConfirmDailogComponent } from '../../common/confirm-dailog/confirm-dailog.component';

function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}

@Component({
  selector: 'app-laboratory',
  templateUrl: './laboratory.component.html',
  styleUrls: ['./laboratory.component.scss']
})
export class LaboratoryComponent {
  pageSizeTemp: any;
  totalRowCount = 0;
  doctorName: any;
  hospitalList: any;
  public totalDoctorRecord = 0;
  displayedColumns: string[] = [
    'labName',
    'contactPersonName',
    'phoneNo1',
    // 'labAddress',
    'email',
    'status',
    'Action',
  ];
  laboratoryForm!: FormGroup;
  tempsupportData: any;
  hospitalData:any;
  roleId:any


  laboratoryData: any = [];
  public dataSource = new MatTableDataSource(laboratoryData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();

  constructor(
    private doctorService: DoctorService,
    private router: Router,
    private authService: AuthService,
    private dialogRef: MatDialog,
    private toasterService: ToasterService,
    private hospitalService: HospitalService,
    private formBuilder: FormBuilder,
    private authservice: AuthService,
    private httpService: HttpService,
    private laboratoryService:LaboratoryService,
    private dialog: MatDialog,

  ) {
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));

    this.createForm();
    this.getLaboratoryList();
    this.getHospitalList();
    }

  resetForm() {
    this.laboratoryForm.reset();
    this.createForm();
  }

  createForm() {
    this.laboratoryForm = this.formBuilder.group({
      tenantId:new FormControl(),
      laboratoryName: new FormControl(''),

    });
  }
  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }

  changeHospital(event:any){
    this.hospitalData = event;
  
    }



  getLaboratoryList() {
    let obj = {
      tenantId:this.laboratoryForm.value.tenantId || '00000000-0000-0000-0000-000000000000',
    }
        this.laboratoryService.getLaboratoryMasterList(obj).subscribe((res: any) => {
          if (res.success) {
            laboratoryData = res.result;
            this.tempsupportData = res.result;
            if (res.result.length > 0) {
              this.dataSource = new MatTableDataSource(laboratoryData);
            } else {
              this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
              this.dataSource = new MatTableDataSource(laboratoryData);
            }
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
          }
      });
  }
  editLaboratory(laboratoryId: any) {
    this.authservice.encryptKey('laboratoryId', laboratoryId);
    const confirmDialog = this.dialogRef.open(EditLaboratoryComponent, {
      width: '920px',
      disableClose: true,
      data:laboratoryId
    });
    confirmDialog.afterClosed().subscribe((result) => {
      this.getLaboratoryList();
      if (result === true) {
        this.router.navigate(['pages/admin/laboratory']);
      }
    });

  }

  addLaboratory() {
    const confirmDialog = this.dialogRef.open(AddLaboratoryComponent, {
      width: '920px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      this.getLaboratoryList();
      if (result === true) {
        this.getLaboratoryList();
      }
    });
  }

  deleteLaboratory(ele:any) {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.DELETE_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.DELETE_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
         let obj ={
         id:ele
    }
        this.laboratoryService.deleteLaboratoryMaster(obj).subscribe((res: any) => {
          if (res.success) {
            this.getLaboratoryList();
            this.toasterService.showSuccess(
              ConstantsMessage.DELETE_LABORATORY,
              ''
            );
          }
        });
        this.getLaboratoryList();
        this.router.navigate(['pages/admin/laboratory']);
      }
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
}
export interface displayedColumns {
  id: number;
  labName: string;
  contactPersonName: string;
  phoneNo1: number;
  // labAddress:string;
  email: number;
  status:number;
}
let laboratoryData: displayedColumns[];
