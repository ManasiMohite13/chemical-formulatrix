import { ChangeDetectorRef, Component, Inject, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { format } from 'date-fns';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { LaboratoryService } from 'src/app/shared/services/laboratory.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

@Component({
  selector: 'app-edit-laboratory',
  templateUrl: './edit-laboratory.component.html',
  styleUrls: ['./edit-laboratory.component.scss']
})
export class EditLaboratoryComponent {
  addLaboratoryForm!: FormGroup;
  hospitalList: any;
  roleId: any; id: any;
  @Input() max: any;
  tomorrow = new Date();
  laboratoryData:any
  tempsupportData: any;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private hospitalService: HospitalService,
    private httpService: HttpService,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    private laboratoryService:LaboratoryService,
    private http:HttpService,
    @Inject(MAT_DIALOG_DATA) public data:any,

  ) {
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    this.createForm();
    this.getLaboratoryList();
    this. getHospitalList()
    if (this.id != '') {
      let obj = {
        id: Number(this.http.getDecryptedValue('laboratoryId')),
      };
      this.getLaboratoryById(obj);
    }
  }
 
  createForm() {
    this.addLaboratoryForm = this.fb.group({
      id:new FormControl(),
      labName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      contactPersonName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      phoneNo1: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      address1: new FormControl('',[Validators.pattern(ConstantsMessage.ONLY_ADDRESS)]),
      address2:new FormControl('',[Validators.pattern(ConstantsMessage.ONLY_ADDRESS)]),
      city:new FormControl('',[
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      district:new FormControl('',[
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      addressId:new FormControl(''),
      state:new FormControl('',[
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN)]),
      email: new FormControl('', [
        Validators.required,Validators.email,
      ]),
      zipCode:new FormControl('',[Validators.pattern(ConstantsMessage.ZIP_CODE_PATTERN)]),
      tenantId:new FormControl('',[Validators.required]),
       
    });
  }

  submitLaboratoryForm() {
    var obj = {
      id:this.addLaboratoryForm.value.id,
      labName: this.addLaboratoryForm.value.labName,
      contactPersonName: this.addLaboratoryForm.value.contactPersonName,
      phoneNo1: this.addLaboratoryForm.value.phoneNo1,
      address1: this.addLaboratoryForm.value.address1,
      address2:this.addLaboratoryForm.value.address2,
      city:this.addLaboratoryForm.value.city,
      district:this.addLaboratoryForm.value.district,
      addressId:this.addLaboratoryForm.value.addressId,
      email: this.addLaboratoryForm.value.email,
      state:this.addLaboratoryForm.value.state,
      zipCode:this.addLaboratoryForm.value.zipCode,

      // tenantId:this.addLaboratoryForm.value.tenantId,
    };
    this.laboratoryService.updateLaboratoryMaster(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.UPDATE_LABORATORY, '');      
        this.getLaboratoryList();
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
  resetLaboratoryForm() {
    this.addLaboratoryForm.reset();
  }

  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        this.hospitalList = res.result;
      }
    });
  }
  getLaboratoryList() {
    var tenantId = localStorage.getItem('tenantId');    
    let obj = {
      tenantId: this.addLaboratoryForm.value.tenantId,     
    }    
        this.laboratoryService.getLaboratoryMasterList(obj).subscribe((res: any) => {
          if (res.success) {
            this.laboratoryData = res.result;    
          }        
      });    
  }
  getLaboratoryById(laboratoryId: any) {
    this.laboratoryService.getLaboratoryMasterById(laboratoryId).subscribe((res: any) => {
      this.laboratoryData = res.result;
      this.addLaboratoryForm.patchValue(this.laboratoryData)
      // this.addLaboratoryForm.patchValue({
      //   tenantId:this.laboratoryData.tenantId

      // })

      });
   }
}

