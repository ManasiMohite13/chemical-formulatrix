import { Component, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import {
  Calendar,
} from '@fullcalendar/core';

import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { DatePipe, Time } from '@angular/common';
import { FullCalendarComponent } from '@fullcalendar/angular';
import { HttpService } from 'src/app/shared/services/http.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { PaymentOption, PaymentOptionName } from 'src/assets/config/global-enums';

@Component({
  selector: 'app-transition-by-source',
  templateUrl: './transition-by-source.component.html',
  styleUrls: ['./transition-by-source.component.scss']
})
export class TransitionBySourceComponent {
  trasactionSourceForm!: FormGroup;
  doctorData: any = [];
  public dataSource = new MatTableDataSource(doctorData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  PaymentOptionName=PaymentOptionName;
  PaymentOption=PaymentOption;
  displayedColumns: string[] = [
    'paymentSource',
    'payAmount',
  ];
  constructor(
    private formBuilder: FormBuilder,
    private appoinmentService: AppoinmentService,
    public datepipe: DatePipe,
    private fb: FormBuilder,
    private tosterService: ToasterService) {
      this.createForm();
      this.getTransactionBySource();
  }

  resetForm() {
    this.trasactionSourceForm.reset();
  }
  createForm() {
    const today = new Date();
    this.trasactionSourceForm = this.formBuilder.group({
      fromDate: [today],
      toDate: [today],
    });
  }
  getTransactionBySource(){
    let obj = {
      doctorId: this.trasactionSourceForm.value.doctorId,
      fromDate: this.datepipe.transform(
        this.trasactionSourceForm?.value.fromDate,
        'yyyy-MM-dd'
      ),
      toDate: this.datepipe.transform(
        this.trasactionSourceForm?.value.toDate,
        'yyyy-MM-dd'
      ),
    };
    this.appoinmentService.getTransactionByPaymentSource(obj).subscribe((res: any) => {
      if (res.success) {
        let doctorData = res.result;
        if (res.result.length > 0) {
          this.dataSource = new MatTableDataSource(doctorData);
        } else {
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(doctorData);
        }
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });
  }
}

export interface displayedColumns {
  paymentSource: number;
  payAmount: number;
}
let doctorData: displayedColumns[];

