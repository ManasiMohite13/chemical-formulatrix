import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransitionBySourceComponent } from './transition-by-source.component';

describe('TransitionBySourceComponent', () => {
  let component: TransitionBySourceComponent;
  let fixture: ComponentFixture<TransitionBySourceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransitionBySourceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TransitionBySourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
