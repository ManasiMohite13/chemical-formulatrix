import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { AddSpecilityComponent } from './add-specility/add-specility.component';

function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}

@Component({
  selector: 'app-specility',
  templateUrl: './specility.component.html',
  styleUrls: ['./specility.component.scss']
})
export class SpecilityComponent {

  displayedColumns: string[] = [
    'hospitalName',
    'contactNo',
    'hospitalEmergencyNo',
    'email',
    'contactPersonName',
    'Action',
  ];
  tempHospitalData: any;
  public dataSource = new MatTableDataSource(hospitalData);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  constructor(
    private authService: AuthService,
    private hospitalService: HospitalService,
    private router: Router,
    private dialogRef: MatDialog,

  ) {
    this.getHospitalList();
  }

  sortData(sort: Sort) {
    const data = this.tempHospitalData;
    if (!sort.active || sort.direction === '') {
      this.dataSource = data;
      return;
    }
    const isAsc = sort.direction === 'asc';
    const sortedData = data.sort((a: any, b: any) => {
      switch (sort.active) {
        case 'hospitalName':
          return compareString(a.hospitalName, b.hospitalName, isAsc);
        case 'contactNo':
          return compareNumber(a.contactNo, b.contactNo, isAsc);
        case 'hospitalEmergencyNo':
          return compareNumber(
            a.hospitalEmergencyNo,
            b.hospitalEmergencyNo,
            isAsc
          );
        case 'email':
          return compareNumber(a.email, b.email, isAsc);
        case 'contactPersonName':
          return compareNumber(a.contactPersonName, b.contactPersonName, isAsc);
        default:
          return 0;
      }
    });
    this.dataSource = new MatTableDataSource(sortedData);
    this.dataSource.paginator = this.paginator;
  }

  getHospitalList() {
    this.hospitalService.getHospitalList().subscribe((res: any) => {
      if (res.success) {
        hospitalData = res.result;
        this.tempHospitalData = res.result;
        if (res.result.length > 0) {
          this.dataSource = new MatTableDataSource(hospitalData);
        } else {
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(hospitalData);
        }
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });
  }

  openEditHospitalProfile(id: any) {
    this.authService.encryptKey('hospitalId', id);
    this.router.navigate(['pages/admin/hospital/edit-hospital']);
  }
  
  addSpeciality() {
    const confirmDialog = this.dialogRef.open(AddSpecilityComponent, {
      width: '650px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
      }
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
}

export interface displayedColumns {
  hospitalName: string;
  contactNo: string;
  hospitalEmergencyNo: string;
  email: string;
  contactPersonName: string;
}

let hospitalData: displayedColumns[];
