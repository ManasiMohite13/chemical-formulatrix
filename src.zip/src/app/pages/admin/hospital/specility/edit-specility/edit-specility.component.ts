import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { UserService } from 'src/app/shared/services/user.service';
import { ValidationService } from 'src/app/shared/validation.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

@Component({
  selector: 'app-edit-specility',
  templateUrl: './edit-specility.component.html',
  styleUrls: ['./edit-specility.component.scss']
})
export class EditSpecilityComponent {

  addSpecialityForm!: FormGroup;
  hospitalList: any;
  refreanceListing: any;
  tenantId: any;
  email: any;
  roleId: any;
  userType: any;
  name:any;
  drOrPatientantId: any;
  hide: boolean = true;
  visible: boolean = true;
  statusList: any = [
    { id: 1, status: 'Active' },
    { id: 2, status: 'InActive ' },
  ];
  passwordInfo: string = ConstantsMessage.VALIDATION_PASSWORD_MESSAGE_INFO;
  roleList: any = [
    { id: 1, role: 'Super Admin' },
    { id: 2, role: 'Admin' },
    { id: 3, role: 'Doctor' },
    { id: 4, role: 'Patient ' },
    { id: 5, role: 'Receptionist' },
  ];
  selectedHospital: any;
  constructor(
    private hospitalService: HospitalService,
    private fb: FormBuilder,
    private confirmPasswordValidators: ValidationService,
    private httpService: HttpService,
    private router: Router,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef
  ) {
    this.createForm();
    this.roleId = Number(this.httpService.getDecryptedValue('roleId'));
    
  }
  createForm() {
    this.addSpecialityForm = this.fb.group(
      {
        spcialityName: new FormControl('', [Validators.required]),
        status:new FormControl(),
     
      },
      
    );
  }
 
  

  submitPatientForm() {
    var obj = {
      spcialityName: this.addSpecialityForm.value.spcialityName ,
      status:this.addSpecialityForm.value.status,
    
    };
    this.hospitalService.createSpeciality(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.USER_CREATE, '');
        this.router.navigate(['pages/admin/user']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }

  resetForm() {
    this.addSpecialityForm.reset();
  }
}