import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSpecilityComponent } from './edit-specility.component';

describe('EditSpecilityComponent', () => {
  let component: EditSpecilityComponent;
  let fixture: ComponentFixture<EditSpecilityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditSpecilityComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditSpecilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
