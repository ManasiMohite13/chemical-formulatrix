import { ChangeDetectorRef, Component, Inject, OnInit, ViewChild, inject } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select';
import { MatOption } from '@angular/material/core';
export interface Fruit {
  "id": number;
  "doctorSpecialityName": string;
  "tenantId": string;
  "isDeleted": number;
  "description": string;
  status: number;
}
@Component({
  selector: 'app-add-specility',
  templateUrl: './add-specility.component.html',
  styleUrls: ['./add-specility.component.scss']
})
export class AddSpecilityComponent {
  allSelected = false;
  @ViewChild('select') private select!: MatSelect;
  masterSpecialityList: any;
  masterSpecialityListCopy:any=[];
  specialityArray: any = [];
  hospitalForm!: FormGroup;
  currentSpecialities: any[] = []
  hospitalList: any;
  tenantId: any;
  email: any;
  roleId: any;
  userType: any;
  name: any;
  drOrPatientantId: any;
  constructor(
    private hospitalService: HospitalService,
    private fb: FormBuilder,
    private router: Router,
    private toasterService: ToasterService,
    public fd: ChangeDetectorRef,
    public dialogRef: MatDialogRef<AddSpecilityComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.createForm();
    this.getMasterSpecialityList();
    this.tenantId = data.tenantId;
    this.getCurrentSpecilitiesList()
  }
  getMasterSpecialityList() {
    this.hospitalService.getSpecialityList().subscribe((res: any) => {
      this.masterSpecialityList = res.result;
      this.masterSpecialityListCopy =   this.masterSpecialityList;
    })
  }
  toggleAllSelection() {
    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
    this.finalizeSelections();
  }

  optionClick() {
    let newStatus = true;
    this.select.value.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    if (this.masterSpecialityList.length == this.select.value.length) {
      this.allSelected = true;
    } else this.allSelected = false;
    this.finalizeSelections();
  }

  finalizeSelections() {
    const arr:any[] = this.hospitalForm.controls['specilityId'].value;
    if (arr && Array.isArray(arr)) {
      this.currentSpecialities.forEach((e: any, i) => {
        if (!arr.includes(e['specilityId'])) {
          this.currentSpecialities[i]['isDeleted'] = 1
        }
        else{
          this.currentSpecialities[i]['isDeleted'] = 0
        }
      })
      console.log(arr,this.currentSpecialities)
    }
  }

  getCurrentSpecilitiesList() {
    this.hospitalService.getDoctorSpecilityMasterList(this.tenantId).subscribe((res: any) => {
      const selectedSpecilityIds = res.result.map((e) => e.specilityId);
      this.hospitalForm.get('specilityId').patchValue(selectedSpecilityIds);
      this.currentSpecialities = res.result.map((e) => {
        return {
          id: e.id,
          specilityId: e.specilityId,
          isDeleted: 0,
          tenantId: this.tenantId
        }
      });
    })
  }
  autoComplete(data) {
    this.masterSpecialityListCopy = this.masterSpecialityList.filter(option => option.specificationName.toLowerCase().includes(data.target.value.toLowerCase()));
  }
  createForm() {
    this.hospitalForm = this.fb.group({
      id: new FormControl(null),
      specilityId: new FormControl()
    })
  }
  submitPatientForm() {
    const allSelectedIds = this.hospitalForm.value.specilityId;
    let requestObj = [];
    this.currentSpecialities.forEach((e)=>{
      requestObj.push({
        tenantId: this.tenantId,
        specilityId: e.specilityId,
        id: e.id,
        isDeleted:e.isDeleted,
        description: ""
      })

    })
    const reqObj = allSelectedIds.map((e) => {
      const isAvaible = this.currentSpecialities.some((el)=>el.specilityId==e)
      if(isAvaible){
        return null
      }
      return {
        tenantId: this.tenantId,
        specilityId: e,
        id: 0,
        isDeleted: 0,
        description: ""
      }
    }).filter((element)=>element!=null)
    requestObj =[...requestObj,...reqObj]
    this.hospitalService.createHospitalSpeciality(requestObj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.SPECIALITY_CREATE, '');
        this.router.navigate(['pages/admin/hospital']);
      }
    });
  }
}