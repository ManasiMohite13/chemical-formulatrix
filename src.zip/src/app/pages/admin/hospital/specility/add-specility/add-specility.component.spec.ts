import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSpecilityComponent } from './add-specility.component';

describe('AddSpecilityComponent', () => {
  let component: AddSpecilityComponent;
  let fixture: ComponentFixture<AddSpecilityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddSpecilityComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddSpecilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
