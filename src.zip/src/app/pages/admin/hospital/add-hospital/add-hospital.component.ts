import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { Observable, map, startWith } from 'rxjs';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
@Component({
  selector: 'app-add-hospital',
  templateUrl: './add-hospital.component.html',
  styleUrls: ['./add-hospital.component.scss'],
})
export class AddHospitalComponent implements OnInit {
  hospitalForm!: FormGroup;
  editFile = true;
  removeUpload = false;
  timeZoneCopy: any = [];
  imageUrl: any;
  statusList: any = [
    { id: 'India Standard Time', status: 'India Standard Time' },
    { id: 'Central America Standard Time', status: 'Central America Standard Time' },
    { id: 'SA Pacific Standard Time', status: 'SA Pacific Standard Time' },

  ];

  timeZoneList: any;

  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private hospitalService: HospitalService,
    private router: Router,
    private appointmentService: AppoinmentService,
  ) {
    this.getTimeZone();
    this.createForm();
  }
  ngOnInit(): void { }

  resethospitalForm() {
    // Exclude the 'timeZone' control from reset
    this.hospitalForm.reset({ timeZone: this.hospitalForm.get('timeZone').value });
    
    // Reset other controls
    this.hospitalForm.get('hospitalLogo').setValue('');
    this.imageUrl = 'assets/image/no_image.jpg';
    this.editFile = true;
    this.removeUpload = false;
}

resetTimeZone() {
    // Reset only the 'timeZone' control
    this.hospitalForm.get('timeZone').reset();
}


  autoComplete(data) {
    this.timeZoneCopy = this.timeZoneList.filter(option => option.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  back() {
    this.router.navigate(['pages/admin/hospital'])
  }

  getTimeZone() {
    this.appointmentService.getTimeZone().subscribe((res: any) => {
      this.timeZoneList = res;
      this.timeZoneCopy = this.timeZoneList;
      var getTimeZone = this.timeZoneList.filter(a => a === "India Standard Time" || a === "India Standard time");
      if (getTimeZone.length > 0) {
        this.hospitalForm.patchValue({
          timeZone: getTimeZone[0]
        });
      }
    })
  }

  createForm() {
    this.hospitalForm = this.fb.group({
      hospitalName: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.ONLY_LETTER_PATTERN),
      ]),
      hospitalLogo: new FormControl(''),
      contactNo: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      alternateContactNo: new FormControl('', [
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      hospitalEmergencyNo: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      email: new FormControl('', [Validators.email
      ]),
      contactPersonName: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_DOCTOR_FIRST_NAME),
      ]),
      timeZone: new FormControl('', [Validators.required]),
      portalURL: new FormControl('', [Validators.pattern('(https?://)?([A-Za-z\d.-]+)\.([A-Za-z.]{2,6})[/\w .-]*/?')]),
      address1: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_ADDRESS),
      ]),
      address2: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_ADDRESS),
      ]),
      city: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_ADDRESS),
      ]),
      district: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_ADDRESS),
      ]),
      state: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_ADDRESS),
      ]),
      zipCode: new FormControl('', [
        Validators.pattern(ConstantsMessage.ZIP_CODE_PATTERN),
      ]),
    });
  }

  uploadFile(event: any, controlName: string) {
    const reader = new FileReader();
    const file = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.imageUrl = reader.result;
        this.hospitalForm.controls[controlName].setValue(reader.result);
        this.editFile = false;
        this.removeUpload = true;
      };
    }
  }

  submithospitalForm() {
    var obj = {
      hospitalName: this.hospitalForm.value.hospitalName,
      hospitalLogo:
        this.hospitalForm.value.hospitalLogo
          .replace('data:', '')
          .replace(/^.+,/, '') || '',
      contactNo: this.hospitalForm.value.contactNo,
      alternateContactNo: this.hospitalForm.value.alternateContactNo,
      hospitalEmergencyNo: this.hospitalForm.value.hospitalEmergencyNo,
      address1:this.hospitalForm.value.address1,
      address2:this.hospitalForm.value.address2,
      city:this.hospitalForm.value.city,
      state:this.hospitalForm.value.state,
      district:this.hospitalForm.value.district,
      zipCode:this.hospitalForm.value.zipCode,
      email: this.hospitalForm.value.email,
      contactPersonName: this.hospitalForm.value.contactPersonName,
      tenantName: this.hospitalForm.value.tenantName,
      timeZone: this.hospitalForm.value.timeZone,
      portalURL: this.hospitalForm.value.portalURL,
    };
    this.hospitalService.createHospital(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.HOSPITAL_CONFIRM, '');
        this.router.navigate(['pages/admin/hospital']);
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
}
