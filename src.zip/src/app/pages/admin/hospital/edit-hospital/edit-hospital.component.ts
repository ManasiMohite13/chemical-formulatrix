import { Component } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { AuthService } from 'src/app/shared/services/auth.service';
import { AppConfigService } from 'src/app/shared/services/common/app-config.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ConstantsRoutes } from 'src/assets/config/constants-routes';
@Component({
  selector: 'app-edit-hospital',
  templateUrl: './edit-hospital.component.html',
  styleUrls: ['./edit-hospital.component.scss'],
})
export class EditHospitalComponent {
  hospitalForm!: FormGroup;
  hospitalId: any;
  hospitalDetails: any;
  editFile = true;
  timeZoneCopy: any = [];
  isManageProfile: boolean = false;
  removeUpload = false;
  imageUrl: any;
  apiURL: any;
  statusList: any = [
    { id: 'India Standard Time', status: 'India Standard Time' },
    { id: 'Central America Standard Time', status: 'Central America Standard Time' },
    { id: 'SA Pacific Standard Time', status: 'SA Pacific Standard Time' },
  ];
  email: any;
  hospitalName:any;
  timeZoneList: any
  constructor(
    private authService: AuthService,
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private hospitalService: HospitalService,
    private httpService: HttpService,
    private router: Router,
    private dialog: MatDialog,
    private appConfig: AppConfigService,
    private appointmentService: AppoinmentService,
  ) {
    this.getTimeZone();
    this.apiURL = ConstantsRoutes.Main_URL;
    // this.apiURL =
    //   this.appConfig.getConfig().apiURL + '/documents/HospitalLogo/';
    this.createForm();
    this.hospitalId = Number(this.httpService.getDecryptedValue('hospitalId'));
    this.isManageProfile = Boolean(this.httpService.getDecryptedValue('isManageProfile'));
    if (this.hospitalId > 0 || this.isManageProfile) {
      this.getHospitalById();
    }
  }

  autoComplete(data) {
    this.timeZoneCopy = this.timeZoneList.filter(option => option.toLowerCase().includes(data.target.value.toLowerCase()));
  }

  getTimeZone() {
    this.appointmentService.getTimeZone().subscribe((res: any) => {
      this.timeZoneList = res;
      this.timeZoneCopy = this.timeZoneList;
    })

  }
  getHospitalById() {
    this.hospitalService
      .getHospitalById(this.hospitalId)
      .subscribe((res: any) => {
        if (res.success) {
          this.hospitalDetails = res.result;
          this.hospitalForm.patchValue(this.hospitalDetails);
          this.hospitalForm.patchValue(this.hospitalDetails.addressDetails)
          this.email = this.hospitalDetails.email;
          this.hospitalName =this.hospitalDetails.hospitalName
          this.hospitalForm.patchValue({
            hospitalLogo:
              this.hospitalDetails.hospitalLogo == ''
                ? ''
                : this.apiURL + this.hospitalDetails.hospitalLogo,
          });
        }
      });
  }

  uploadFile(event: any, controlName: string) {
    const reader = new FileReader();
    const file = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.imageUrl = reader.result;
        this.hospitalForm.controls[controlName].setValue(reader.result);
        this.editFile = false;
        this.removeUpload = true;
      };
    }
  }
  resethospitalForm() {
    this.hospitalForm.reset();
  }
  back() {
    if (!this.isManageProfile) {
      this.router.navigate(['/pages/admin/hospital']);
    }
  }

  openCancelConfirmation() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CANCEL_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.CANCEL_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        this.router.navigate(['pages/admin/hospital']);
      }
    });
  }

  createForm() {
    this.hospitalForm = this.fb.group({
      id: new FormControl(null),
      hospitalName: new FormControl({ value: null, disabled: true }),
      hospitalLogo: new FormControl(''),
      contactNo: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      alternateContactNo: new FormControl('', [
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
      hospitalEmergencyNo: new FormControl('', [
        Validators.required,
        Validators.pattern(ConstantsMessage.CONTACT_NUMBER_PATTERN),
      ]),
     
      email: new FormControl({ value: null, disabled: true }),
      contactPersonName: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_DOCTOR_FIRST_NAME),
      ]),
      timeZone: new FormControl('', [Validators.required]),
      address1: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_ADDRESS),
      ]),
      address2: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_ADDRESS),
      ]),
      city: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_ADDRESS),
      ]),
      district: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_ADDRESS),
      ]),
      state: new FormControl('', [
        Validators.pattern(ConstantsMessage.ONLY_ADDRESS),
      ]),
      zipCode: new FormControl('', [
        Validators.pattern(ConstantsMessage.ZIP_CODE_PATTERN),
      ]),
    });
  }

  submitEdithospitalForm() {
    const obj = {
      id: this.hospitalForm.value.id,
      hospitalName: this.hospitalForm.value.hospitalName || this.hospitalName,
      hospitalLogo:
        (this.hospitalForm.value.hospitalLogo.includes(this.apiURL)
          ? this.hospitalForm.value.hospitalLogo.substring(this.apiURL.length)
          : this.hospitalForm.value.hospitalLogo
            .replace('data:', '')
            .replace(/^.+,/, '')) || '',
      contactNo: this.hospitalForm.value.contactNo,
      alternateContactNo: this.hospitalForm.value.alternateContactNo,
      hospitalEmergencyNo: this.hospitalForm.value.hospitalEmergencyNo,
      hospitalAddress:this.hospitalForm.value.hospitalAddress,
      email: this.hospitalForm.value.email || this.email,
      contactPersonName: this.hospitalForm.value.contactPersonName,
      timeZone: this.hospitalForm.value.timeZone,
      address1:this.hospitalForm.value.address1,
      address2:this.hospitalForm.value.address2,
      city:this.hospitalForm.value.city,
      state:this.hospitalForm.value.state,
      district:this.hospitalForm.value.district,
      zipCode:this.hospitalForm.value.zipCode,
    };
    this.hospitalService.updateHospital(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(ConstantsMessage.HOSPITAL_UPDATE, '');
        if (this.isManageProfile) {
          this.authService.encryptKey('isManageProfile', 0);
          this.router.navigate(['pages/admin/hospital/edit-hospital']);
        } else {
          this.router.navigate(['pages/admin/hospital']);
        }
      } else {
        this.toasterService.showError(res.errors, '');
      }
    });
  }
}
