import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { CancelAppointmentsComponent } from './cancel-appointments/cancel-appointments.component';
function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}

@Component({
  selector: 'app-cancel-appoinment',
  templateUrl: './cancel-appoinment.component.html',
  styleUrls: ['./cancel-appoinment.component.scss']
})
export class CancelAppoinmentComponent {
  appoinmentId: any;
  verificationId:any
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private appoinmentService: AppoinmentService,
    private http: HttpService,
    private dialog: MatDialog,
    public hospitalService: HospitalService,
    private router: Router,
    private route: ActivatedRoute,
  ) {
   
    
    this.appoinmentId = Number(this.http.getDecryptedValue('eventId'));
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.verificationId = params.get('id');
      this.cancelAppoinment(this.verificationId);
      console.log('verificationId:', this.verificationId);
    });
  }

  backAppList() {
    this.router.navigate(['/']);
  }

  // cancelAppoinment() {
  //   const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
  //     data: {
  //       title: ConstantsMessage.CANCEL_CONFIRM_POPUP_TITLE,
  //       message: ConstantsMessage.CANCEL_APPOINMENT_MESSAGE,
  //     },
  //     width: '420px',
  //     disableClose: true,
  //   });
  //   confirmDialog.afterClosed().subscribe((result) => {
  //     if (result === true) {
  //       let obj = {
  //         id:this.verificationId,
  //       };
  //       this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
  //         if (res.success) {
  //           this.toasterService.showSuccess(
  //             ConstantsMessage.APPOINMENT_CANCEL,
  //             ''
  //           );
  //         }
  //       });
  //       this.router
  //         .navigateByUrl('/', {
  //           skipLocationChange: true,
  //         })
  //         .then(() => {
  //           this.router.navigate(['/']);
  //         });
  //     }
  //   });
  // }



  cancelAppoinment(verificationId:any) {
    const confirmDialog = this.dialog.open(CancelAppointmentsComponent, {
      width: '350px',
      disableClose: true,
      data:verificationId,
    });
    
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
      }
    });
  }
  
}

