import { Component,Inject, } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

@Component({
  selector: 'app-cancel-appointments',
  templateUrl: './cancel-appointments.component.html',
  styleUrls: ['./cancel-appointments.component.scss']
})
export class CancelAppointmentsComponent {
  appoinmentId: any;
  verificationId: any;
  cancelForm:FormGroup;
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private appoinmentService: AppoinmentService,
    private http: HttpService,
    private dialog: MatDialog,
    public hospitalService: HospitalService,
    private router: Router,
    private route: ActivatedRoute,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.cancelcreateForm();
    this.appoinmentId = data;
    // this.route.paramMap.subscribe((params: ParamMap) => {
    //   this.verificationId = params.get('id');
    //   console.log('verificationId:', this.verificationId);
    // });
  }
  cancelcreateForm() {
    this.cancelForm = this.fb.group({
      id: new FormControl(),
      appointmentReason: new FormControl('', [Validators.required,Validators.pattern(ConstantsMessage.ONLY_NUMBER_AND_CHARACTER_PATTERN), Validators.maxLength(50)]),
    })
  }

  cancelAppoinment() {
    let obj = {
      id: this.appoinmentId,
      appointmentReason:this.cancelForm.value.appointmentReason,
    }
    this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
      if (res.success) {
        this.toasterService.showSuccess(
          ConstantsMessage.APPOINMENT_CANCEL, '');
          this.router.navigate(['/'])
      }
    });

  }
  cancel(){
    this.router.navigate(['/'])

  }


}
