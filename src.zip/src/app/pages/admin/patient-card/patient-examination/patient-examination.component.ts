import { Component} from '@angular/core';
import { FormBuilder, FormControl, FormGroup,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { AppConfigService } from 'src/app/shared/services/common/app-config.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}
@Component({
  selector: 'app-patient-examination',
  templateUrl: './patient-examination.component.html',
  styleUrls: ['./patient-examination.component.scss']
})
export class PatientExaminationComponent {

  appoinmentId: any;
  patientForm!: FormGroup;
  patientData: any = [];
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private patientService: PatientService,
    private appoinmentService: AppoinmentService,
    private router: Router,
    private http: HttpService,
    private appConfig: AppConfigService,
    private dialog: MatDialog,
    public hospitalService: HospitalService
  ) {
    this.updateForm();
    let obj = {
      id: Number(this.http.getDecryptedValue('patientId')),
    };
    this.appoinmentId = Number(this.http.getDecryptedValue('eventId'));

    this.getPatientDetail(obj);
  }

  updateForm() {
    this.patientForm = this.fb.group({
      id: new FormControl(),
      patientName: new FormControl({ value: null, disabled: true }),
      gender: new FormControl({ value: null, disabled: true }),
      contactNo: new FormControl({ value: null, disabled: true }),
      email: new FormControl({ value: null, disabled: true }),
      hospitalName: new FormControl({ value: null, disabled: true }),
    });
  }

  getPatientDetail(patientId: any) {
    this.patientService.getPatientDetail(patientId).subscribe((res: any) => {
      this.patientData = res.result;
      this.patientForm.patchValue(this.patientData);
    });
  }

  backAppList() {
    this.router.navigate(['/pages/admin/appointment']);
  }

  cancelAppoinment() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CANCEL_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.CANCEL_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        let obj = {
          id: Number(this.appoinmentId),
        };
        this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(
              ConstantsMessage.APPOINMENT_CANCEL,
              ''
            );
          }
        });
        this.router
          .navigateByUrl('/', {
            skipLocationChange: true,
          })
          .then(() => {
            this.router.navigate(['pages/admin/appointment']);
          });
      }
    });
  }

}
