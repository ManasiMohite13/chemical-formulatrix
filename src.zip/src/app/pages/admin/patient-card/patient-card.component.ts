import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelect } from '@angular/material/select';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { AppConfigService } from 'src/app/shared/services/common/app-config.service';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { TabServiceService } from 'src/app/shared/services/tab-service.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { DyanamicFormValidator } from 'src/app/shared/validator/form.validator';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { ConstantsRoutes } from 'src/assets/config/constants-routes';
import { FileExt, apiUrl } from 'src/assets/config/global-enums';
function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}
@Component({
  selector: 'app-patient-card',
  templateUrl: './patient-card.component.html',
  styleUrls: ['./patient-card.component.scss'],
})
export class PatientCardComponent implements OnInit {
  fileAttr = 'Choose File';
  selectedFileNames: string[] = [];
  disbaledUploadBtn = true;
  filePath: any;
  appoinmentId: any;
  tabs: any;
  allTabs: any;
  public currentFormGroup: FormGroup = this.fb.group({});
  public allSections: any = [];
  public tabGroupFields: any = [];
  allfieldsData: any[] = [];
  public selectedTabIndex = 0;
  id: any;
  buttonsHideShow: boolean = false;
  currentTab: any;
  patientId: any;
  isFormLoaded = true;
  public dynamicData: any = {};
  filesArray: any = [];
  dropdownFormControl = new FormControl();
  medicineData: any;
  data = false;
  displayedColumns: string[] = [
    'documentName',
    'Action'
  ];
  isMedicineForm = true
  laboratoryForm!: FormGroup;
  tempsupportData: any;
  hospitalData: any;
  selectedIds: number[] = [];
  roleId: any;
  specilityId: any;
  deserializedObject: any = [];
  isLoading = true;
  apiUrl = apiUrl;
  parsedObject: any;
  groupTypeList: any = []; voDataService: any;
  ;
  MedicineData: any = [];
  documentData: any = [];
  voData; any
  nextDate: Date;
  selectedFormFieldValueIds: any;
  public dataSource = new MatTableDataSource(this.deserializedObject);
  noRecordsFoundMsg: string | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  @ViewChild('fileInput') docElementRef;

  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private appoinmentService: AppoinmentService,
    private router: Router,
    private http: HttpService,
    private dialog: MatDialog,
    public hospitalService: HospitalService,
    private tabService: TabServiceService,
    private patientService: PatientService,
  ) {
    this.patientId = Number(this.http.getDecryptedValue('patientId')),
      this.appoinmentId = Number(this.http.getDecryptedValue('eventId'));
    this.specilityId = Number(this.http.getDecryptedValue('specilityId'));
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
    this.nextDate = tomorrow;


    this.getTabMasterList();
    this.getFormFildsValuesById();
    this.dynamicData = {};
    // this.getPatientMedicineByAppoinementId();


  }
  ngOnInit() {
    const retrievedObject = localStorage.getItem('myObjectKey');
    if (retrievedObject) {
      this.parsedObject = JSON.parse(retrievedObject);
    }
  }

  backAppList() {
    this.router.navigate(['/pages/admin/appointment']);
  }

  cancelAppoinment() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CANCEL_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.CANCEL_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        let obj = {
          id: Number(this.appoinmentId),
        };
        this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(
              ConstantsMessage.APPOINMENT_CANCEL,
              ''
            );
          }
        });
        this.router
          .navigateByUrl('/', {
            skipLocationChange: true,
          })
          .then(() => {
            this.router.navigate(['pages/admin/appointment']);
          });
      }
    });
  }
  finishAppoinment() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CONFIRM_POPUP_TITLES,
        message: ConstantsMessage.FINISH_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        let obj = {
          id: Number(this.appoinmentId),
        };
        this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(
              ConstantsMessage.APPOINMENT_CANCEL,
              ''
            );
          }
        });
        this.router
          .navigateByUrl('/', {
            skipLocationChange: true,
          })
          .then(() => {
            this.router.navigate(['pages/admin/appointment']);
          });
      }
    });
  }

  getTabMasterList() {
    let obj = {
      id: this.specilityId,
    }
    this.tabService.getTabListBySpecilityId(obj).subscribe((res: any) => {
      if (res.success) {
        this.tabs = res.result;
        this.allTabs = this.tabs.sort((a, b) => a.displayOrder - b.displayOrder);
        this.activateTab(this.allTabs[0].tabId);
      }
    })
  }

  activateTab(tabId: number) {
    this.currentFormGroup = this.fb.group({
    });
    this.currentTab = this.allTabs.find((e) => e.tabId === tabId);
    let allSections = this.allfieldsData.filter(e => this.currentTab.tabId == tabId);
    allSections = allSections.map((section: any) => {
      section.formFields = section.formFields.sort((a: any, b: any) => a.fieldsDisplayOrder - b.fieldsDisplayOrder);
      return section;
    });
    this.createForm(allSections).then((e) => {
      this.allSections = allSections;
      this.getPatientDynamicData();
    });
    this.dynamicData.id = null;
  }

  tabGroupFieldDetails(tabId: any) {
    return new Promise((resolve, reject) => {
      let obj = {
        tabId: tabId,
        specialityId: this.specilityId,
      }
      this.tabService.tabGroupFieldsBySpecilityTabDetail(obj).subscribe((res: any) => {
        if (res.success) {
          this.allfieldsData = res.result;
          this.buttonsHideShow = true;
          this.allfieldsData.sort((a: any, b: any) => a.displayOrder - b.displayOrder);
          this.isFormLoaded = true;
          resolve(true);
        }
      })

    })
  }

  onTabChangeEvent(event: any) {
    const clickedIndex = event.index;
    if (clickedIndex < 1) {
      return;
    }
    let tabId = this.allTabs[clickedIndex - 1].tabId;
    this.tabGroupFieldDetails(tabId).then((res) => {
      this.activateTab(tabId);
    });

  }
  createForm(sections: any[]) {
    return new Promise((resolve, reject) => {
      for (const section of sections) {
        for (const control of section.formFields) {
          const validatorsToAdd = [];
          for (let singleVal of control.fieldValidators) {
            for (var [key, value] of Object.entries(singleVal)) {
              let validatorValue: any = value;
              switch (key) {
                case 'min':
                  validatorsToAdd.push(DyanamicFormValidator.isMin(validatorValue, singleVal.validationMessage));

                  break;
                case 'max':
                  validatorsToAdd.push(DyanamicFormValidator.isMax(validatorValue, singleVal.validationMessage));

                  break;
                case 'isRequired':
                  if (value) {
                    validatorsToAdd.push(DyanamicFormValidator.isRequired(validatorValue, singleVal.validationMessage));
                  }
                  break;
                case 'email':
                  if (value) {
                    validatorsToAdd.push(DyanamicFormValidator.isEmail(validatorValue, singleVal.validationMessage));

                  }
                  break;
                case 'minLength':
                  validatorsToAdd.push(DyanamicFormValidator.isMinLength(validatorValue, singleVal.validationMessage));

                  break;
                case 'maxLength':
                  validatorsToAdd.push(DyanamicFormValidator.isMaxLength(validatorValue, singleVal.validationMessage));
                  break;
                case 'validationPattern':
                  validatorsToAdd.push(DyanamicFormValidator.isPattern(validatorValue, singleVal.validationMessage));

                  break;
                case 'nullValidator':
                  if (value) {
                    validatorsToAdd.push(Validators.nullValidator);
                  }
                  break;
                default:
                  break;
              }
            }
          }
          if (control.type == 'table') {
            this.currentFormGroup.addControl(control.fieldName, this.fb.array([]));
          } else {
            this.currentFormGroup.addControl(
              control.fieldName,
              this.fb.control((control.fieldType == 'file' || control.fieldType == 'dropdown' || control.fieldType == 'number') ? null : (''), validatorsToAdd)
            );
          }
        }
      }
      resolve(true)
    })

  }
  isRequired(fieldValidators: any[]): boolean {
    // for (const validator of fieldValidators) {
    //   if (validator.isRequired) {
    //     return true;
    //   }
    // }
    let data = fieldValidators.some(e=> e.isValidators);
    return data ?? null;
  }



  toggleCheckbox(formFieldValueId: any) {

    if (this.selectedFormFieldValueIds.includes(formFieldValueId)) {
      this.selectedFormFieldValueIds = this.selectedFormFieldValueIds.filter(id => id !== formFieldValueId);
    } else {
      this.selectedFormFieldValueIds.push(formFieldValueId);
    }
  }



  onFormSubmit() {
    const formData = new FormData();
    var fileData = this.selectedFiles;
    const finalControls = [];
    const appointmentId = this.appoinmentId;
    const patientId = this.patientId;
    const tabId = this.currentTab.tabId;
    const groupTypeList = [];
    const MedicineData = [];
    const fileList = [];

    for (let row of this.allSections) {
      for (let e of row.formFields) {
        const fieldValue = this.currentFormGroup.controls[e.fieldName].value;
        let fieldValueAsString = fieldValue;

        if (e.fieldType === 'checkbox') {
          fieldValueAsString = this.selectedIds.join(', ');
        }

        if (row.groupType === 2 && fieldValueAsString) {
          const file = this.selectedFiles[MedicineData.length];
          if (file) {
            const fileName = file.name;
            formData.append('MedicineData', file, fileName);
            fieldValueAsString = fileName;
          }

        }

        finalControls.push({
          tabGroupId: row.tabGroupId,
          fieldId: e.fieldId,
          fieldName: e.fieldName,
          fieldValue: fieldValueAsString,
        });

        if (row.groupType === 1) {
          groupTypeList.push(finalControls[finalControls.length - 1]);
        } else if (row.groupType === 3) {
          MedicineData.push(this.parsedObject);
        }
      }
    }

      if (fileData) {
        for (let i = 0; i < fileData.length; i++) {
          const file = fileData[i];
          const fileName = file.name;
          var obj = {
            name: fileName,
            path: "",
          }
          fileList.push(obj);
          formData.append('File', file, fileName);
        }
      } else {
        formData.append('File', null);
      }
    

    const TabPostData = {
      id: this.dynamicData?.id || 0,
      patientId: patientId,
      patientAppointmentId: appointmentId,
      tabId: tabId,
      groupTypeList: [
        {
          groupType: this.allSections[0].groupType,
          MedicineData: MedicineData,
          documentData: fileList,
          tabData: JSON.stringify(finalControls),
        },
      ],
    };


    formData.append('jsonString', JSON.stringify(TabPostData));

    this.tabService.patientDyanamicCreateData(formData).subscribe((res: any) => {
      if (res.success) {
        const tabName = this.currentTab.tabName;
        this.toasterService.showSuccess(`Patient ${tabName} Added successfully!`, '');
        this.dynamicData.id = null;
        this.filesArray = [];
        this.selectedFiles = [];
        this.getFormFildsValuesById();
        this.getPatientDynamicData();
      }
    });
  }




  getFormFildsValuesById() {
    const selectedOptionId = this.dropdownFormControl.value;
    if (selectedOptionId) {
      let obj = {
        id: selectedOptionId
      };

      this.tabService.getFormFieldsValueById(obj).subscribe((res: any) => {
        if (res.success) {
        } else {
        }
      });
    } else {
    }
  }

  getPatientDynamicData() {
    if (!this.currentTab) {
      return;
    }

    let obj = {
      patientId: this.patientId,
      patientAppointmentId: this.appoinmentId,
      tabId: this.currentTab.tabId
    };

    this.tabService.getPatientDyanamicData(obj).subscribe((res: any) => {
      if (res.success) {
        this.dynamicData = res.result;
        var documentList = this.dynamicData.documentList;
        if (this.dynamicData && this.dynamicData.tabDataDetails) {
          for (const fieldData of this.dynamicData.tabDataDetails) {
            const fieldName = fieldData.fieldName;
            const fieldValue = fieldData.fieldValue;
            this.currentFormGroup.patchValue({
              [fieldName]: fieldName === "chooseFile" ? null : fieldValue,
            });
            console.log(this.currentFormGroup.controls[fieldName], fieldName, fieldValue);
            if (fieldName === "chooseFile") {
              this.dataSource.data = JSON.parse(this.dynamicData.tabDataDetails[0].fieldValue);
            } else if (fieldName === "checkx") {

            }
            // else if(){
            //   this.selection = 
            // }
          }
        }
      }
    });
  }


  resetForm() {
    this.currentFormGroup.reset();
    this.fileAttr = null;
  }
  selectedFiles: FileList[] | any[] = [];
  onFileSelect(event: any) {
    this.selectedFiles = event.target.files;
    this.filesArray = [];
    this.selectedFileNames = [];
    if (this.selectedFiles && this.selectedFiles.length > 0) {
      this.fileAttr = this.selectedFiles.length.toString();
      const selectedFileNames: string[] = [];
      for (let i = 0; i < this.selectedFiles.length; i++) {
        var extnew = this.selectedFiles[i].name.split('.').pop();
        var ext = String(extnew).toLowerCase();
        this.filesArray.push(this.selectedFiles[i]);
        selectedFileNames.push(this.selectedFiles[i].name);

      }
      this.fileAttr = selectedFileNames.join(', ');
    } else {
      this.fileAttr = 'Choose File';
    }
  }


  document(templateRef: TemplateRef<any>) {
    if (this.docElementRef) {
      this.docElementRef.nativeElement.value = '';
    }
    this.fileAttr = null;
    //  this.isLoading = false;
    const confirmDialog = this.dialog.open(templateRef, {
      width: '300px',
      height: '200px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {

      }
    });
  }
  save() {
    const filesArray = Array.from(this.selectedFiles);
    for (const file of filesArray) {
      var extnew = file.name.split('.').pop();
      var ext = String(extnew).toLowerCase();

      this.deserializedObject.push({ Name: file.name, path: null });

    }
    this.dataSource.data = this.deserializedObject
    // this.selectedFiles = [...this.filesArray,...this.selectedFiles]; 
  }

  download(path, name) {
    const a = document.createElement('a');
    var docPath = ConstantsRoutes.Main_URL + path;
    fetch(docPath)
      .then(response => response.blob())
      .then(blob => {
        const url = URL.createObjectURL(blob);
        a.href = url;
        a.download = name + '';
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
      })
      .catch(error => {
        console.error('Error fetching the file:', error);
      });
  }

  selection = [];
  getSelection(controlName, item) {
    if (this.selection.length <= 0) {
      this.selection = this.currentFormGroup.controls[controlName].value ? this.currentFormGroup.controls[controlName].value.split(',') : [];
      this.selection = this.selection.map((e) => { return { formFieldValueId: e.trim() } })
    }
    const indSelectedOrNot = this.selection.findIndex(s => s.formFieldValueId == item.formFieldValueId);
    return indSelectedOrNot !== -1;
  }

  changeHandler(event, item: any) {
    const id = item.formFieldValueId;
    const index = this.selection.findIndex(u => u.formFieldValueId === id);
    if (event.checked == true) {
      this.selection = [...this.selection, item];
    } else {
      this.selection = this.selection.splice(index, 1);

    }
    // 
    // if (index === -1) {

    // } else {

    this.selectedIds = this.selection.map(selectedItem => selectedItem.formFieldValueId);
    this.selectedIds = this.selectedIds.filter((element, index) => {
      return this.selectedIds.indexOf(element) === index;
    });
  }



}
export interface displayedColumns {
  documentName: string;
}
let documentData: displayedColumns[];
