import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientSymtomsComponent } from './patient-symtoms.component';

describe('PatientSymtomsComponent', () => {
  let component: PatientSymtomsComponent;
  let fixture: ComponentFixture<PatientSymtomsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientSymtomsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PatientSymtomsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
