import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
function compareNumber(a: number, b: number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

function compareString(a: string, b: string, isAsc: boolean) {
  return a.localeCompare(b, 'da-DK') * (isAsc ? 1 : -1);
}

@Component({
  selector: 'app-patient-symtoms',
  templateUrl: './patient-symtoms.component.html',
  styleUrls: ['./patient-symtoms.component.scss']
})
export class PatientSymtomsComponent {
  appoinmentId: any;
  patientForm!: FormGroup;
  patientData: any = [];
  genderList: any = [
    { id: 1, gender: 'Male' },
    { id: 2, gender: 'Female' },
  ];
  constructor(
    private fb: FormBuilder,
    private toasterService: ToasterService,
    private patientService: PatientService,
    private appoinmentService: AppoinmentService,
    private router: Router,
    private dialog: MatDialog,
    public hospitalService: HospitalService,
  ) {
    this.getPatientDetail();
    this.updateForm();
  }

  updateForm() {
    this.patientForm = this.fb.group({
      id: new FormControl(),
      symptomName: new FormControl({ value: null, disabled: true }),
      status: new FormControl({ value: null, disabled: true }),
      tenantId: new FormControl({ value: null, disabled: true }),
    });
  }

  getPatientDetail() {
    this.patientService.getSymptosMasterList().subscribe((res: any) => {
      this.patientData = res.result;
    });
  }

  backAppList() {
    this.router.navigate(['/pages/admin/appointment']);
  }

  cancelAppoinment() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CANCEL_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.CANCEL_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        let obj = {
          id: Number(this.appoinmentId),
        };
        this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(
              ConstantsMessage.APPOINMENT_CANCEL,
              ''
            );
          }
        });
        this.router
          .navigateByUrl('/', {
            skipLocationChange: true,
          })
          .then(() => {
            this.router.navigate(['pages/admin/appointment']);
          });
      }
    });
  }
}

