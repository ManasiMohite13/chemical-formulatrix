import { CdkPortal, DomPortalHost, PortalHost } from '@angular/cdk/portal';
import { AfterViewInit, ApplicationRef, Component, ComponentFactoryResolver, ElementRef, EventEmitter, Inject, Injector, Input, Optional, Output, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { ConstantsRoutes } from 'src/assets/config/constants-routes';

@Component({
  selector: 'app-print-prescription-page',
  templateUrl: './print-prescription-page.component.html',
  styleUrls: ['./print-prescription-page.component.scss'],
  providers: [DomPortalHost]
})
export class PrintPrescriptionPageComponent implements AfterViewInit {
  @Output() printCloseEvent: EventEmitter<any> = new EventEmitter();
  @Input() requestedForId: any = null;
  prescriptionData: any;
  doctorDetails: any;
  patientDetail: any;
  appointmentDetail: any;
  hospitalPic: any;
  btn: boolean = true;
  medicineList:any =[]=[];
  dyanamicData:any;
  addressDetails:any
  @ViewChild('printableContent') printableContent: ElementRef;
  @ViewChild(CdkPortal) portal: CdkPortal;
  host: PortalHost;


  private externalWindow: any = null;

  constructor(private appointmentService: AppoinmentService,
    private componentFactoryResolver: ComponentFactoryResolver,
    private applicationRef: ApplicationRef,
    private injector: Injector,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {
  }

  ngAfterViewInit() {
    this.externalWindow = window.open('', 'Print Reciept', '');
    this.host = new DomPortalHost(
      this.externalWindow.document.body,
      this.componentFactoryResolver,
      this.applicationRef,
      this.injector
    );
    this.host.attach(this.portal);
    this.externalWindow.onbeforeunload = () => {
      this.externalWindow.close()
      this.host.detach();
      this.printCloseEvent.emit(false)
    }

    this.externalWindow.onblur = () => {
    }
    this.getPrescriptionDetails();
  }

  getPrescriptionDetails() {
    let obj = {
      id: this.requestedForId
    }
    this.appointmentService.getPrintPrescriptionDeatils(obj).subscribe((res: any) => {
      if (res.success) {
        this.prescriptionData = res.result;
        this.medicineList = this.prescriptionData.medicineDetails;
        this.addressDetails = this.prescriptionData.addressDetails;
        this.appointmentDetail = this.prescriptionData.appointmentDetail
        this.doctorDetails = this.prescriptionData.doctorDetail;
        this.patientDetail = this.prescriptionData.patientDetail;
        this.hospitalPic = ConstantsRoutes.Main_URL + this.prescriptionData.hospitalLogo;
        this.dyanamicData = this.prescriptionData.dynamicDatas;
        console.log(' this.dyanamicData ', this.dyanamicData )
      }

    })
  }
  // printPage() {
  //   this.btn = false;
  //   document.getElementById('btn').hidden = true;
  //   window.print();
  // }
}
