import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintPrescriptionPageComponent } from './print-prescription-page.component';

describe('PrintPrescriptionPageComponent', () => {
  let component: PrintPrescriptionPageComponent;
  let fixture: ComponentFixture<PrintPrescriptionPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrintPrescriptionPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrintPrescriptionPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
