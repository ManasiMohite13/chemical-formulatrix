import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-plan',
  templateUrl: './patient-plan.component.html',
  styleUrls: ['./patient-plan.component.scss']
})
export class PatientPlanComponent {

}
