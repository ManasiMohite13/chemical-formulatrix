import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientPlanComponent } from './patient-plan.component';

describe('PatientPlanComponent', () => {
  let component: PatientPlanComponent;
  let fixture: ComponentFixture<PatientPlanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientPlanComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PatientPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
