import { DatePipe } from '@angular/common';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { AuthService } from 'src/app/shared/services/auth.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';

export interface PeriodicElement {
  medicineName: string;
  dosage: string;
  frequency: string;
  medicineNote: string;
}

const ELEMENT_DATA: PeriodicElement[] = [];

@Component({
  selector: 'app-patient-medicine',
  templateUrl: './patient-medicine.component.html',
  styleUrls: ['./patient-medicine.component.scss']
})
export class PatientMedicineComponent implements OnInit {
  medicineForm: FormGroup;
  private voDataSubject = new BehaviorSubject<any>(null);
  voData$ = this.voDataSubject.asObservable();
  displayedColumns: string[] = [
    'medicineName',
    'dosage',
    'frequency',
    'medicineNote',
    'action',
  ];
  frequencyOptions = [' 1', ' 2', ' 3'];
  selectedFrequency: string = '';
  dataSource = new MatTableDataSource<any>();
  medicineMasterList: any
  isLoading = true;
  patientId: any;
  appointmentId: any;
  medicineData: any
  maxDate = new Date();
  pageNumber: number = 1;
  VOForm: FormGroup;
  medicineListCopy:any
  isEditableNew: boolean = true;
  minDate = new Date(); 
  today = new Date ();
  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router, private _formBuilder: FormBuilder, private dialog: MatDialog, private toasterService: ToasterService, private http: HttpService, private patientService: PatientService) {
    this.patientId = Number(this.http.getDecryptedValue('patientId')),
    this.appointmentId = Number(this.http.getDecryptedValue('eventId'));
    this.getPatientMedicineByAppoinementId()
    this.getMasterMedicineList();
    this.createMedicineForm();
  }

  ngOnInit(): void {
    this.VOForm = this._formBuilder.group({
      VORows: this._formBuilder.array([]),
    });

    this.dataSource = new MatTableDataSource();
    this.dataSource.data = (this.VOForm.get('VORows') as FormArray).controls;
    this.dataSource.paginator = this.paginator;

    const filterPredicate = this.dataSource.filterPredicate;
    this.dataSource.filterPredicate = (data: AbstractControl, filter) => {
      return filterPredicate.call(this.dataSource, data.value, filter);
    };

  }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  goToPage() {
    this.paginator.pageIndex = this.pageNumber - 1;
    this.paginator.page.next({
      pageIndex: this.paginator.pageIndex,
      pageSize: this.paginator.pageSize,
      length: this.paginator.length,
    });
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.paginatorList = document.getElementsByClassName(
      'mat-paginator-range-label'
    );


  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  AddNewRow(dataToPopulate = null) {
    const control = this.VOForm.get('VORows') as FormArray;
    control.push(this.initiateVOForm(dataToPopulate));
    this.dataSource = new MatTableDataSource(control.controls);
  }

  EditSVO(VOFormElement, i) {
    VOFormElement.get('VORows').at(i).get('isEditable').patchValue(false);
  }

  saveVO(index = null) {
    let requestArray;
    if (index == null) {
      requestArray = this.VOForm.get('VORows').value;
    } else {
      const fArray = this.VOForm.get('VORows') as FormArray;
      requestArray = [fArray.at(index).value];
    }
    requestArray = requestArray[0];
    requestArray.patientId = this.patientId;
    requestArray.appointmentId = this.appointmentId;

    requestArray.id = this.medicineData[index]?.id || 0,
      this.authService.encryptKey('userType', requestArray);
    if (index !== null) {
      const fArray = this.VOForm.get('VORows') as FormArray;
      fArray.at(index).get('isEditable').patchValue(true);
    }
    this.voDataSubject.next(requestArray);
    const serializedObject = JSON.stringify(requestArray);
    localStorage.setItem('myObjectKey', serializedObject);
    this.patientService.createPatientMedicine(requestArray).subscribe((res: any) => {
      if (res.success) {
         this.toasterService.showSuccess(ConstantsMessage.CREATE_PATIENT_MEDICINE, '');
      
      
        if (index !== null) {
          const fArray = this.VOForm.get('VORows') as FormArray;
          fArray.at(index).get('isEditable').patchValue(true);
        }
      }
      else{
        this.toasterService.showError(res.errors ,'');
      }
    });
  }


  CancelSVO(VOFormElement, i) {
    VOFormElement.get('VORows').at(i).get('isEditable').patchValue(true);
  }

  deleteRo(index: number) {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CONFIRM,
        message: ConstantsMessage.DELETE_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        const control = this.VOForm.get('VORows') as FormArray;
        control.removeAt(index);
        this.dataSource.data = control.controls;
        this.toasterService.showSuccess(
          ConstantsMessage.TABLE_ROW_DELETE,
          ''
        );


      }
    });
  }
  deleteRow(rowIndex: number) {
    const vorowsArray = this.VOForm.get('VORows') as FormArray;
    vorowsArray.at(rowIndex).reset();
  }

  getPatientMedicineByAppoinementId() {
    let obj = {
      patientId: this.patientId,
      appointmentId: this.appointmentId,
    }
    this.patientService.getPatientMedicineByAppoinementId(obj).subscribe((res: any) => {
      if (res.success) {
        this.medicineData = res.result;
        this.medicineData.forEach(element => {
          this.AddNewRow(element);

        });
      }

    })
  }

  paginatorList: HTMLCollectionOf<Element>;
  idx: number;

  initiateVOForm(patchdata = null): FormGroup {
    return this.fb.group({
      patientId: new FormControl(patchdata ? patchdata.patientId : null),
      appointmentId: new FormControl(patchdata ? patchdata.appointmentId : null),
      medicineId: new FormControl(patchdata ? patchdata.medicineId : ''),
      frequency: new FormControl(patchdata ? patchdata.frequency : ''),
      dosage: new FormControl(patchdata ? patchdata.dosage : ''),
      medicineNote: new FormControl(patchdata ? patchdata.medicineNote : ''),
      isEditable: new FormControl(true),
    });
  }
  autoComplete(data) {
    this.medicineListCopy = this.medicineMasterList.filter(option => option.medicineName.toLowerCase().includes(data.target.value.toLowerCase()));
  }
  dateFilter = (date: Date): boolean => {
    return date >= this.minDate;
  }
  
  getMasterMedicineList() {
    this.patientService.createMedicineMasterList().subscribe((res:any) => {
      this.medicineMasterList = res.result;
      this.medicineListCopy = this.medicineMasterList;

    })
  }

  onChange(event: any) {    
    if(!this.medicineForm.value.salePrice){
      this.medicineForm.patchValue({salePrice: Number(event.target.value)});
    }
 };
  support(templateRef: TemplateRef<any>) {
    const confirmDialog = this.dialog.open(templateRef, {
      width: '550px',
      disableClose: true,

    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
      }
    });
  }
  createMedicineForm() {
    this.medicineForm = this.fb.group({
      itemName: new FormControl('',[Validators.required,Validators.pattern(ConstantsMessage.ONLY_ADDRESS)]),
      power: new FormControl(),
      brandName:new FormControl(),
      qty: new FormControl('',[Validators.min(1),Validators.pattern(ConstantsMessage.QTY_LENGTH)]),
      purchaseDate:new FormControl(new Date()),
      expiryDate: new FormControl(),
      purchasePrice:new FormControl('',[Validators.min(1),Validators.required,Validators.min(0)]),
      salePrice: new FormControl('',[Validators.min(1),Validators.min(0)]),
      description :new FormControl(),
    })
  }
  saveMedicineForm() {
    // let id = this.medicineForm.value.medicineName == null ? 0 : this.medicineForm.value.medicineName
    // let check = this.medicineListCopy.filter(a => a.medicineName == this.medicineForm.value.medicineName);
    // if (check.length > 0 && id == 0) {
    //   this.toasterService.showError("This medicine is already added", '');
    //   return;
    // }
    debugger
    const datePipe = new DatePipe('en-US');
    let obj = {
      itemName: this.medicineForm.value.itemName,
      power: this.medicineForm.value.power,
      brandName:this.medicineForm.value.brandName,
      qty: this.medicineForm.value.qty || Number,
      expiryDate: datePipe.transform(this.medicineForm.value.expiryDate, 'yyyy-MM-dd')||null,
      purchaseDate:this.medicineForm.value.purchaseDate || new Date(),
      purchasePrice:Number(this.medicineForm.value.purchasePrice),      
      salePrice:Number(this.medicineForm.value.salePrice),
      description : this.medicineForm.value.description,
    }
    this.patientService.createPatientMedicineMaster(obj).subscribe((res:any) => {
      if(res.success){
        this.toasterService.showSuccess(ConstantsMessage.CREATE_PATIENT_MEDICINE, '');
        this.medicineForm.reset()
        this.getMasterMedicineList();
        
      }
      else{
        this.toasterService.showError(res.errors
          ,' ');
      }

    })
  }
  resetForm(){
    this.medicineForm.reset()
   }
}