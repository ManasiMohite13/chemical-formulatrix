import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ConfirmDailogComponent } from 'src/app/pages/common/confirm-dailog/confirm-dailog.component';
import { AppoinmentService } from 'src/app/shared/services/appoinment.service';
import { HospitalService } from 'src/app/shared/services/hospital.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { PatientService } from 'src/app/shared/services/patient.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { AppointmentSource, AppointmentSourceName, AppointmentStatus, AppointmentStatusName } from 'src/assets/config/global-enums';
import { PaymentComponent } from '../../payment/payment.component';
import { ConstantsRoutes } from 'src/assets/config/constants-routes';
import { PrintPrescriptionPageComponent } from '../print-prescription-page/print-prescription-page.component';

@Component({
  selector: 'app-patient-basic-details',
  templateUrl: './patient-basic-details.component.html',
  styleUrls: ['./patient-basic-details.component.scss'],
})
export class PatientBasicDetailsComponent {
  // @ViewChild('printableContent') printableContent: ElementRef;

  public dataSource = new MatTableDataSource(patientHistory);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort = new MatSort();
  appointmentId: any;
  patientId: any;
  patientForm!: FormGroup;
  patientData: any = null;
  patientMedicineData:any;
  patientDetailData: any;
  openPrintpage = false;
  patientMedicine:any
  patientAppointmentHistory: any = [];
  noRecordsFoundMsg: string | undefined;
  appointmentSource = AppointmentSource;
  appointmentSourceName = AppointmentSourceName;
  appointmentStatus = AppointmentStatus;
  appointmentStatusName = AppointmentStatusName;

  displayedColumns: string[] = [
    'appointmentDateTime',
    'appointmentTime',
    'appointmentReason',
    'doctorName',
    'appointmentSource',
    'appointmentStatus'
  ];

  constructor(
    private toasterService: ToasterService,
    private patientService: PatientService,
    private appoinmentService: AppoinmentService,
    private router: Router,
    private http: HttpService,
    private dialogRef: MatDialog,
    private dialog: MatDialog,
    public hospitalService: HospitalService
  ) {
    this.patientId = Number(this.http.getDecryptedValue('patientId'));
    this.appointmentId = Number(this.http.getDecryptedValue('eventId'));
    if (this.patientId > 0 && this.appointmentId > 0) {
      this.getPatientHistroy();
    }
  }

  backAppList() {
    this.router.navigate(['/pages/admin/appointment']);
  }

  cancelAppoinment() {
    const confirmDialog = this.dialog.open(ConfirmDailogComponent, {
      data: {
        title: ConstantsMessage.CANCEL_CONFIRM_POPUP_TITLE,
        message: ConstantsMessage.CANCEL_CONFIRMATION_MESSAGE,
      },
      width: '420px',
      disableClose: true,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result === true) {
        let obj = {
          id: Number(this.appointmentId),
        };
        this.appoinmentService.cancelAppoinment(obj).subscribe((res: any) => {
          if (res.success) {
            this.toasterService.showSuccess(
              ConstantsMessage.APPOINMENT_CANCEL,
              ''
            );
          }
        });
        this.router
          .navigateByUrl('/', {
            skipLocationChange: true,
          })
          .then(() => {
            this.router.navigate(['pages/admin/appointment']);
          });
      }
    });
  }

  getPatientHistroy() {
    var obj = {
      patientId: this.patientId,
      appointmentId: this.appointmentId,
    }
    this.patientService.getPatientHistroy(obj).subscribe((res: any) => {
      if (res.success) {
        this.patientData = res.result;
        this.patientMedicine = this.patientData.patientAppointmentHistory;
        this.patientMedicineData = this.patientMedicine[0].patientMedicine;
        console.log('this.patientMedicine ',this.patientMedicineData)
        if (this.patientData.patientAppointmentHistory.length > 0) {
          patientHistory = this.patientData.patientAppointmentHistory;
          this.dataSource = new MatTableDataSource(patientHistory);
          if (this.patientData.patientAppointmentHistory.length > 0) {
            this.onHistoryClick(this.patientData.patientAppointmentHistory[0]);
          }
        }
        else {
          this.noRecordsFoundMsg = ConstantsMessage.EMPTY_RECORD_MESSAGE;
          this.dataSource = new MatTableDataSource(patientHistory);
        }
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });
  }

  download(path, name) {
    const a = document.createElement('a');
    var docPath = ConstantsRoutes.Main_URL + path;
    fetch(docPath)
      .then(response => response.blob())
      .then(blob => {
        const url = URL.createObjectURL(blob);
        a.href = url;
        a.download = name + '';
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
      })
      .catch(error => {
        console.error('Error fetching the file:', error);
      });
  }

  onHistoryClick(data) {
    this.patientDetailData = null;
    this.patientDetailData = data;
  }

  makePayment() {
    const confirmDialog = this.dialogRef.open(PaymentComponent, {
      width: '400px',
      disableClose: true,
      data: this.appointmentId,
    });
    confirmDialog.afterClosed().subscribe((result) => {
      if (result) {
        this.getPatientHistroy();
      }
    });
  }
  printPage() {
    this.openPrintpage = true;
    // const url = `/pages/admin/print-prescription-page?appointmentId=${this.appointmentId}`;
    // const newWindow = window.open(url, '_blank');
    // window.open('/pages/admin/print-prescription-page', '_blank');
  }
  
  @ViewChild('closeBtn') closeBtn: ElementRef
  disclose() {
    this.closeBtn.nativeElement.click()
  }
  
  
}

export interface displayedColumns {
  appointmentDateTime: string;
  appointmentReason: string;
  doctorName: string;
  appointmentSource: number;
  appointmentTime: string;
  appointmentStatus: number;
}
let patientHistory: displayedColumns[];