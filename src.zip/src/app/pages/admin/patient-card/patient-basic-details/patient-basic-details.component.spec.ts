import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientBasicDetailsComponent } from './patient-basic-details.component';

describe('PatientBasicDetailsComponent', () => {
  let component: PatientBasicDetailsComponent;
  let fixture: ComponentFixture<PatientBasicDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientBasicDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PatientBasicDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
