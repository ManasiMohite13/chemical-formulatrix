import { Component } from '@angular/core';

@Component({
  selector: 'app-add-appoinment',
  templateUrl: './add-appoinment.component.html',
  styleUrls: ['./add-appoinment.component.scss']
})
export class AddAppoinmentComponent {

}
