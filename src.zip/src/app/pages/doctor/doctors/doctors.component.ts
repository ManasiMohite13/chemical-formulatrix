import { Component } from '@angular/core';

@Component({
  selector: 'doctor-doctors',
  templateUrl: './doctors.component.html',
  styleUrls: ['./doctors.component.scss'],
})
export class DoctorsComponent {}
