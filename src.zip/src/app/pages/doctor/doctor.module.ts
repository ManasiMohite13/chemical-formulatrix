import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppoinmentsComponent } from './appoinments/appoinments.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DoctorsComponent } from './doctors/doctors.component';
import { PatientsComponent } from './patients/patients.component';
import { PaymentsComponent } from './payments/payments.component';
import { SettingsComponent } from './settings/settings.component';
import { DoctorComponent } from './doctor.component';
import { AppoinmentListComponent } from './appoinments/appoinment-list/appoinment-list.component';
import { AddAppoinmentComponent } from './appoinments/add-appoinment/add-appoinment.component';
import { DoctorListComponent } from './doctors/doctor-list/doctor-list.component';
import { AddDoctorsComponent } from './doctors/add-doctors/add-doctors.component';
import { PatientsListComponent } from './patients/patients-list/patients-list.component';
import { AddPatientsComponent } from './patients/add-patients/add-patients.component';
import { DoctorRoutingModule } from './doctor-routing.module';
import { EditAppoinmentsComponent } from './appoinments/edit-appoinments/edit-appoinments.component';
import { EditDoctorsComponent } from './doctors/edit-doctors/edit-doctors.component';
import { EditPatientsComponent } from './patients/edit-patients/edit-patients.component';

@NgModule({
  declarations: [
    AppoinmentsComponent,
    DashboardComponent,
    DoctorsComponent,
    PatientsComponent,
    PaymentsComponent,
    SettingsComponent,
    DoctorComponent,
    AppoinmentListComponent,
    AddAppoinmentComponent,
    DoctorListComponent,
    AddDoctorsComponent,
    PatientsListComponent,
    AddPatientsComponent,
    EditAppoinmentsComponent,
    EditDoctorsComponent,
    EditPatientsComponent,
  ],
  imports: [CommonModule, DoctorRoutingModule],
})
export class DoctorModule {}
