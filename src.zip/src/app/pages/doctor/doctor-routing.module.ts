import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppoinmentComponent } from '../admin/appoinment/appoinment.component';
import { AddDoctorComponent } from '../admin/doctors/add-doctor/add-doctor.component';
import { PaymentComponent } from '../admin/payment/payment.component';
import { AddAppoinmentComponent } from './appoinments/add-appoinment/add-appoinment.component';
import { AppoinmentListComponent } from './appoinments/appoinment-list/appoinment-list.component';
import { EditAppoinmentsComponent } from './appoinments/edit-appoinments/edit-appoinments.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DoctorComponent } from './doctor.component';
import { DoctorListComponent } from './doctors/doctor-list/doctor-list.component';
import { EditDoctorsComponent } from './doctors/edit-doctors/edit-doctors.component';
import { AddPatientsComponent } from './patients/add-patients/add-patients.component';
import { EditPatientsComponent } from './patients/edit-patients/edit-patients.component';
import { PatientsListComponent } from './patients/patients-list/patients-list.component';
import { PatientsComponent } from './patients/patients.component';
import { SettingsComponent } from './settings/settings.component';
import { NotFoundComponent } from '../common/confirm-dailog/404.component';

const routes: Routes = [
  {
    path: '',
    component: DoctorComponent,
    children: [
      {
        path: 'dahboard',
        component: DashboardComponent,
      },
      {
        path: 'appoinment',
        component: AppoinmentComponent,
      },
      {
        path: 'appoinment/appoinment-list',
        component: AppoinmentListComponent,
      },
      {
        path: 'appoinment/add-appoinment',
        component: AddAppoinmentComponent,
      },
      {
        path: 'appoinment/edit-appoinment',
        component: EditAppoinmentsComponent,
      },
      {
        path: 'doctor',
        component: DoctorComponent,
      },

      {
        path: 'doctor/doctor-list',
        component: DoctorListComponent,
      },
      {
        path: 'doctor/add-doctor',
        component: AddDoctorComponent,
        
      },
      {
        path: 'doctor/edit-doctor',
        component: EditDoctorsComponent,
      },
      {
        path: 'patient',
        component: PatientsComponent,
      },
      {
        path: 'patient/patient-list',
        component: PatientsListComponent,
      },
      {
        path: 'patients/add-patient',
        component: AddPatientsComponent,
      },
      {
        path: 'patients/edit-patient',
        component: EditPatientsComponent,
      },
      {
        path: 'doctor/payments',
        component: PaymentComponent,
      },
      {
        path: 'settings',
        component: SettingsComponent,
      },
      

      {
        path: '**',
        component: NotFoundComponent,
        data: {
          title: 'Not Found',
          head: 'Page not found',
          message: 'The page is deprecated, deleted, or does not exist at all',
          status: '404',
        },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DoctorRoutingModule {}
