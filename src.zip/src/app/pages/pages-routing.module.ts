import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../shared/guard/auth.guard';
import { PagesComponent } from './pages.component';
import { ProfileComponent } from './profile/profile.component';
import { NotFoundComponent } from './common/confirm-dailog/404.component';

const routes: Routes = [
  {
    path: '',
    component: PagesComponent,
    children: [
      {
        path: 'admin',
        loadChildren: () =>
          import('./admin/admin.module').then((m) => m.AdminModule),
           canActivate: [AuthGuard],
           data: {
            roles: [1,2,3,4,5],
         },
           

      },
      {
        path: 'doctor',
        loadChildren: () =>
          import('./doctor/doctor.module').then((m) => m.DoctorModule),
        canActivate: [AuthGuard],

      },
      {
        path: 'patient',
        loadChildren: () =>
          import('./patient/patient.module').then((m) => m.PatientModule),
      canActivate: [AuthGuard],

      },
      {
        path:'profile',
        component:ProfileComponent,
        canActivate: [AuthGuard],

      },
      {
        path: '**',
        component: NotFoundComponent,
        data: {
          title: 'Not Found',
          head: 'Page not found',
          message: 'The page is deprecated, deleted, or does not exist at all',
          status: '404',
        },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesRoutingModule {}
