import { NgModule } from "@angular/core";
import { HasPermissionDir } from "./directive/haspermission.directive";
import { PrintPrescriptionPageComponent } from "../pages/admin/patient-card/print-prescription-page/print-prescription-page.component";
import { CommonModule } from "@angular/common";
import { PortalModule } from "@angular/cdk/portal";

@NgModule({
declarations:[
    HasPermissionDir,
    PrintPrescriptionPageComponent
],
imports:[
    CommonModule,
    PortalModule,

],
exports:[
    HasPermissionDir,
    CommonModule,
    PrintPrescriptionPageComponent
]
})
export class SharedModule{}