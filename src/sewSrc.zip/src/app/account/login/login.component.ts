import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { ConstantsMessage } from 'src/assets/config/constants-messages';
import { Roles } from 'src/assets/config/global-enums';
import { ForgotPasswordComponent } from '../forgot-password/forgot-password.component';
import { fromEvent } from 'rxjs';
import { SessionService } from 'src/app/shared/services/session.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  hide: boolean = true;
  bmcDetail: any = [];
  subscription: any;
  control: any
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private toasterService: ToasterService,
    public dialog: MatDialog,
    public session: SessionService,
  ) { }

  ngOnInit(): void {
    this.createForm();
  }
  createForm() {
    this.loginForm = this.fb.group({
      email: new FormControl('', [
        Validators.required,
        Validators.email,
      ]),
      password: new FormControl('', [Validators.required]),
    });
  }
  get username() {
    return this.loginForm.controls['email'];
  }
  get password() {
    return this.loginForm.controls['password'];
  }
  submitForm() {
    this.username.markAsDirty();
    this.username.updateValueAndValidity();
    this.password.markAsDirty();
    this.password.updateValueAndValidity();
    if (this.username.invalid || this.password.invalid) {
      return;
    }

    this.authService.signIn(this.username.value, this.password.value).subscribe(
      (res: any) => {
        if (res.success) {
          localStorage.clear();
          sessionStorage.clear();
          this.authService.setupUserCreds(res.result);
          this.authService.encryptKey('userId', res.result.id);
          this.authService.encryptKey('roleId', res.result.roleId);
          this.authService.encryptKey('userType', res.result.userType);
          localStorage.setItem('tenantId', res.result.tenantId); 

          if(res.result.hospitalPic)
         {  localStorage.setItem('hospitalPic', res.result.hospitalPic); }

          this.authService.getRolePermissionList().then((

          ) => {
            if (res.result?.roleId == 1 || res.result?.roleId == 2) {
              if (res.result?.roleId == 1) {
                this.router.navigate(['/pages/admin/hospital']);
              } else if (res.result?.roleId == 2) {
                this.router.navigate(['/pages/admin/support']);

              }
            }
            else if (res.result?.roleId == 3 || res.result?.roleId == 5) {
              this.router.navigate(['/pages/admin/appointment']);
            } else {
              this.router.navigate(['/pages/admin/patient/patient-profile']);
            }
          })

        } else {
          this.toasterService.showError(res.errors, '');
        }
      },
      (error) => {
        this.toasterService.showError(ConstantsMessage.INVALID_MESSAGE, '');
      }
    );
  }
  trimInput(controlName: string) {
    this.control = this.loginForm.get(controlName);
    if (this.control.value && typeof this.control.value === 'string') {
      this.control.setValue(this.control.value.trim());
    }
  }


  // openForgotPasswordWindow() {
  //   const dialogRef = this.dialog.open(ForgotPasswordComponent, {
  //     width: '420px',
  //     height: '200px',
  //     disableClose: true,
  //   });
  // }
  register(){
    this.router.navigate(['pages/account/register'])
  }

  hideShowPassword() {
    this.hide = !this.hide;
  }
  openSignUp() {
    this.router.navigate(['/sign-up']);
  }
  ngOnDestroy() {
    history.pushState(null, '', location.href);

    this.subscription = fromEvent(window, 'popstate').subscribe(_ => {
      history.pushState(null, '', location.href);
    });
  }

  // ngAfterViewInit() {
  //     document.getElementById('preloader').classList.add('hide');
  // }
}
