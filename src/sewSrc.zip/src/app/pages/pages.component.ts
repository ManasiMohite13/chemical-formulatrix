import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, OnInit, TemplateRef } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { map, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs/internal/Observable';
import { AuthService } from '../shared/services/auth.service';
import { SessionService } from '../shared/services/session.service';
import { ToasterService } from '../shared/services/toaster.service';
import { UserService } from '../shared/services/user.service';
import { HttpService } from '../shared/services/http.service';
import { HighlightState } from '../shared/interfaces';
import { Title } from '@angular/platform-browser';
import { RoleService } from '../shared/services/role.service';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss'],
})
export class PagesComponent implements OnInit {
  highlightState: HighlightState;
  category: string;
  supportForm!: FormGroup;
  molesForm:FormGroup;
  settingsData: any;
  matchingElements: any;
   moles: number;

apiURL ='localhost:8080/getMolecularToEmpiricalRecords';
data:any;

  perodicTable = [
    { name: 'H', AtomicMass: 1.0079 },
    { name: 'He', AtomicMass: 4.0026 },
    { name: 'Li', AtomicMass: 6.941 },
    { name: 'Be', AtomicMass: 9.0122 },
    { name: 'B', AtomicMass: 10.81 },
    { name: 'C', AtomicMass: 12.011 },
    { name: 'N', AtomicMass: 14.007 },
    { name: 'O', AtomicMass: 15.999 },
    { name: 'F', AtomicMass: 18.998 },
    { name: 'Ne', AtomicMass: 20.180 },
    { name: 'Na', AtomicMass: 22.990 },
    { name: 'Mg', AtomicMass: 24.305 },
    { name: 'Al', AtomicMass: 26.982 },
    { name: 'Si', AtomicMass: 28.085 },
    { name: 'P', AtomicMass: 30.974 },
    { name: 'S', AtomicMass: 32.06 },
    { name: 'Cl', AtomicMass: 35.45 },
    { name: 'Ar', AtomicMass: 39.948 },
    { name: 'K', AtomicMass: 39.098 },
    { name: 'Ca', AtomicMass: 40.078 },
    { name: 'Sc', AtomicMass: 44.956 },
    { name: 'Ti', AtomicMass: 47.867 },
    { name: 'V', AtomicMass: 50.942 },
    { name: 'Cr', AtomicMass: 51.996 },
    { name: 'Mn', AtomicMass: 54.938 },
    { name: 'Fe', AtomicMass: 55.845 },
    { name: 'Co', AtomicMass: 58.933 },
    { name: 'Ni', AtomicMass: 58.693 },
    { name: 'Cu', AtomicMass: 63.546 },
    { name: 'Zn', AtomicMass: 65.38 },
    { name: 'Ga', AtomicMass: 69.723 },
    { name: 'Ge', AtomicMass: 72.630 },
    { name: 'As', AtomicMass: 74.922 },
    { name: 'Se', AtomicMass: 78.971 },
    { name: 'Br', AtomicMass: 79.904 },
    { name: 'Kr', AtomicMass: 83.798 },
    { name: 'Rb', AtomicMass: 85.468 },
    { name: 'Sr', AtomicMass: 87.62 },
    { name: 'Y', AtomicMass: 88.906 },
    { name: 'Zr', AtomicMass: 91.224 },
    { name: 'Nb', AtomicMass: 92.906 },
    { name: 'Mo', AtomicMass: 95.95 },
    { name: 'Tc', AtomicMass: 98 },
    { name: 'Ru', AtomicMass: 101.07 },
    { name: 'Rh', AtomicMass: 102.91 },
    { name: 'Pd', AtomicMass: 106.42 },
    { name: 'Ag', AtomicMass: 107.87 },
    { name: 'Cd', AtomicMass: 112.41 },
    { name: 'In', AtomicMass: 114.82 },
    { name: 'Sn', AtomicMass: 118.71 },
    { name: 'Sb', AtomicMass: 121.76 },
    { name: 'Te', AtomicMass: 127.60 },
    { name: 'I', AtomicMass: 126.90 },
    { name: 'Xe', AtomicMass: 131.29 },
    { name: 'Cs', AtomicMass: 132.91 },
    { name: 'Ba', AtomicMass: 137.33 },
    { name: 'La', AtomicMass: 138.91 },
    { name: 'Ce', AtomicMass: 140.12 },
    { name: 'Pr', AtomicMass: 140.91 },
    { name: 'Nd', AtomicMass: 144.24 },
    { name: 'Pm', AtomicMass: 145 },
    { name: 'Sm', AtomicMass: 150.36 },
    { name: 'Eu', AtomicMass: 151.96 },
    { name: 'Gd', AtomicMass: 157.25 },
    { name: 'Tb', AtomicMass: 158.93 },
    { name: 'Dy', AtomicMass: 162.50 },
    { name: 'Ho', AtomicMass: 164.93 },
    { name: 'Er', AtomicMass: 167.26 },
    { name: 'Tm', AtomicMass: 168.93 },
    { name: 'Yb', AtomicMass: 173.05 },
    { name: 'Lu', AtomicMass: 174.97 },
    { name: 'Hf', AtomicMass: 178.49 },
    { name: 'Ta', AtomicMass: 180.95 },
    { name: 'W', AtomicMass: 183.84 },
    { name: 'Re', AtomicMass: 186.21 },
    { name: 'Os', AtomicMass: 186.21 },
    { name: 'Ir', AtomicMass: 192.22 },
    { name: 'Pt', AtomicMass: 195.08 },
    { name: 'Au', AtomicMass: 196.97 },
    { name: 'Hg', AtomicMass: 200.59 },
    { name: 'Tl', AtomicMass: 204.38 },
    { name: 'Pb', AtomicMass: 207.2 },
    { name: 'Bi', AtomicMass: 208.98 },
    { name: 'Po', AtomicMass: 209 },
    { name: 'At', AtomicMass: 210 },
    { name: 'Rn', AtomicMass: 222 },
    { name: 'Fr', AtomicMass: 223 },
    { name: 'Ra', AtomicMass: 226 },
    { name: 'Ac', AtomicMass: 227 },
    { name: 'Th', AtomicMass: 232.04 },
    { name: 'Pa', AtomicMass: 231.04 },
    { name: 'U', AtomicMass: 238.03 },
    { name: 'Np', AtomicMass: 237 },
    { name: 'Pu', AtomicMass: 244 },
    { name: 'Am', AtomicMass: 243 },
    { name: 'Cm', AtomicMass: 247 },
    { name: 'Bk', AtomicMass: 247 },
    { name: 'Cf', AtomicMass: 251 },
    { name: 'Es', AtomicMass: 252 },
    { name: 'Fm', AtomicMass: 257 },
    { name: 'Md', AtomicMass: 258 },
    { name: 'No', AtomicMass: 259 },
    { name: 'Lr', AtomicMass: 262 },
    { name: 'Rf', AtomicMass: 267 },
    { name: 'Db', AtomicMass: 270 },
    { name: 'Sg', AtomicMass: 271 },
    { name: 'Bh', AtomicMass: 270 },
    { name: 'Hs', AtomicMass: 277 },
    { name: 'Mt', AtomicMass: 276 },
    { name: 'Ds', AtomicMass: 281 },
    { name: 'Rg', AtomicMass: 280 },
    { name: 'Cn', AtomicMass: 285 },
    { name: 'Nh', AtomicMass: 284 },
    { name: 'Fl', AtomicMass: 289 },
    { name: 'Mc', AtomicMass: 288 },
    { name: 'Lv', AtomicMass: 293 },
    { name: 'Ts', AtomicMass: 294 },
    { name: 'Og', AtomicMass: 294 },
  ]
  electronicConfiguration = [
    { name: 'Hydrogen (H)', elect: '1s¹' },
    { name: 'Helium (He)', elect: '1s²' },
    { name: 'Lithium (Li)', elect: '1s² 2s¹' },
    { name: 'Beryllium (Be)', elect: '1s² 2s²' },
    { name: 'Boron (B)', elect: '1s² 2s² 2p¹' },
    { name: ' Carbon (C)', elect: '1s² 2s² 2p²' },
    { name: 'Nitrogen (N)', elect: '1s² 2s² 2p³' },
    { name: 'Oxygen (O)', elect: '1s² 2s² 2p⁴' },
    { name: 'Fluorine (F)', elect: '1s² 2s² 2p⁵' },
    { name: 'Neon (Ne)', elect: '1s² 2s² 2p⁶' },
    { name: 'Sodium (Na)', elect: '1s² 2s² 2p⁶ 3s¹' },
    { name: 'Magnesium (Mg)', elect: '1s² 2s² 2p⁶ 3s²' },
    { name: 'Aluminum (Al):', elect: '1s² 2s² 2p⁶ 3s² 3p¹' },
    { name: 'Silicon (Si)', elect: '1s² 2s² 2p⁶ 3s² 3p²' },
    { name: 'Phosphorus (P):', elect: '1s² 2s² 2p⁶ 3s² 3p³' },
    { name: 'Sulfur (S)', elect: '1s² 2s² 2p⁶ 3s² 3p⁴' },
    { name: 'Chlorine (Cl)', elect: '1s² 2s² 2p⁶ 3s² 3p⁵' },
    { name: 'Argon (Ar)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶' },
    { name: 'Potassium (K)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s¹' },
    { name: 'Calcium (Ca)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s²' },
    { name: 'Scandium (Sc)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹' },
    { name: 'Titanium (Ti)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d²' },
    { name: 'Vanadium (V)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d³' },
    { name: 'Chromium (Cr)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s¹ 3d⁵' },
    { name: 'Manganese (Mn)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d⁵' },
    { name: 'Iron (Fe)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d⁶' },
    { name: 'Cobalt (Co)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d⁷' },
    { name: ' Nickel (Ni)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d⁸' },
    { name: 'Copper (Cu)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s¹ 3d⁹' },
    { name: 'Zinc (Zn)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰' },
    { name: 'Gallium (Ga)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p¹' },
    { name: 'Germanium (Ge)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p²' },
    { name: 'Arsenic (As)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p³' },
    { name: 'Selenium (Se)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁴' },
    { name: 'Bromine (Br)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁵' },
    { name: 'Krypton (Kr)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶' },
    { name: 'Rubidium (Rb)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s¹' },
    { name: 'Strontium (Sr)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s²' },
    { name: 'Yttrium (Y)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹' },
    { name: 'Zirconium (Zr)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d²' },
    { name: 'Niobium (Nb)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d³' },
    { name: 'Molybdenum (Mo)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d⁴' },
    { name: 'Technetium (Tc)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d⁵' },
    { name: 'Ruthenium (Ru)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d⁶' },
    { name: 'Rhodium (Rh):', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d⁷' },
    { name: 'Palladium (Pd)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d⁸' },
    { name: 'Silver (Ag)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s¹ 4d¹⁰' },
    { name: 'Cadmium (Cd)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰' },
    { name: 'Indium (In)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p¹' },
    { name: 'Tin (Sn)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p²' },
    { name: 'Antimony (Sb)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p³' },
    { name: 'Tellurium (Te)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁴' },
    { name: 'Iodine (I)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁵' },
    { name: 'Xenon (Xe)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶' },
    { name: 'Cesium (Cs)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s¹' },
    { name: 'Barium (Ba)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s²' },
    { name: 'Lanthanum (La)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d¹' },
    { name: 'Cerium (Ce)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d²' },
    { name: 'Praseodymium (Pr)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d³' },
    { name: 'Neodymium (Nd)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d⁴' },
    { name: 'Promethium (Pm)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d⁵' },
    { name: 'Samarium (Sm)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d⁶' },
    { name: 'Europium (Eu)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d⁷' },
    { name: 'Gadolinium (Gd)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d⁸' },
    { name: 'Terbium (Tb)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d⁹' },
    { name: 'Dysprosium (Dy)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d¹⁰' },
    { name: 'Holmium (Ho)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d¹¹' },
    { name: 'Erbium (Er)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d¹²' },
    { name: 'Thulium (Tm)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d¹³' },
    { name: 'Ytterbium (Yb)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 5d¹⁴' },
    { name: 'Lutetium (Lu)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹' },
    { name: 'Hafnium (Hf)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d²' },
    { name: 'Tantalum (Ta)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d³' },
    { name: 'Tungsten (W)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d⁴' },
    { name: 'Rhenium (Re)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d⁵' },
    { name: 'Osmium (Os)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d⁶' },
    { name: 'Iridium (Ir)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d⁷' },
    { name: 'Platinum (Pt)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d⁸' },
    { name: 'Gold (Au)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰' },
    { name: 'Mercury (Hg)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p¹' },
    { name: 'Thallium (Tl)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p²' },
    { name: 'Lead (Pb)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p³' },
    { name: 'Bismuth (Bi)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁴' },
    { name: 'Polonium (Po)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁵' },
    { name: 'Astatine (At)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶' },
    { name: 'Radon (Rn)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s¹' },
    { name: 'Francium (Fr)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s²' },
    { name: 'Radium (Ra)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 6d¹' },
    { name: 'Actinium (Ac)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 6d²' },
    { name: 'Thorium (Th)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁰ 6d²' },
    { name: 'Uranium (U)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f³ 6d¹⁰' },
    { name: 'Neptunium (Np)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁴ 6d¹⁰' },
    { name: 'Plutonium (Pu)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁶ 6d¹⁰' },
    { name: 'Americium (Am)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁷ 6d¹⁰' },
    { name: 'Curium (Cm)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁷ 6d¹⁰' },
    { name: 'Berkelium (Bk)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁹ 6d¹⁰' },
    { name: 'Californium (Cf)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁰ 6d¹⁰' },
    { name: 'Einsteinium (Es)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹¹ 6d¹⁰' },
    { name: 'Fermium (Fm)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹² 6d¹⁰' },
    { name: 'Mendelevium (Md)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹³ 6d¹⁰' },
    { name: 'Nobelium (No)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰' },
    { name: 'Lawrencium (Lr)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p¹' },
    { name: 'Rutherfordium (Rf)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d² 7p¹' },
    { name: 'Dubnium (Db)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d³ 7p¹' },
    { name: 'Seaborgium (Sg)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹' },
    { name: 'Bohrium (Bh)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁵ 7p¹' },
    { name: 'Hassium (Hs)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁶ 7p¹' },
    { name: 'Meitnerium (Mt)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁷ 7p¹' },
    { name: 'Darmstadtium (Ds)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁸ 7p¹' },
    { name: 'Roentgenium (Rg)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁹ 7p¹' },
    { name: 'Copernicium (Cn)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p¹' },
    { name: 'Nihonium (Nh)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p¹ 8s¹' },
    { name: 'Flerovium (Fl)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p² 8s¹' },
    { name: 'Moscovium (Mc)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p³ 8s¹' },
    { name: 'Livermorium (Lv)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p⁴ 8s¹' },
    { name: 'Tennessine (Ts)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p⁵ 8s¹' },
    { name: 'Oganesson (Og)', elect: '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p⁶ 8s¹' },

  ];
  molecularToEmpirical = [
    { compound: 'Aspirin:', molecularFor: 'C9H8O4' },
    { compound: 'Glucose:', molecularFor: 'C6H12O6' },
    { compound: 'Water:', molecularFor: 'H2O' },
    { compound: 'Ammonia:', molecularFor: 'NH3' },
  ];
  showFirstLetter: any;
  firstLetter: any;
  atomicMass: any;
  totalPer: any;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private breakpointObserver: BreakpointObserver,
    private authService: AuthService,
    private dialog: MatDialog,
    private sessionService: SessionService,
    private toasterService: ToasterService,
    private userService: UserService,
    private httpService: HttpService,
    titleService: Title,
    public roleService:RoleService
  ) {
  
    this.createForms();
    titleService.setTitle('Periodic Table');
    this.createForm();
  
  }
  highlightElement(highlightState: HighlightState) {
    this.highlightState = highlightState;
  }
  

  setCurrentAtomCategory(category: string) {
    this.category = category;
  }
  isHandset$: Observable<boolean> = this.breakpointObserver
    .observe(Breakpoints.Handset)
    .pipe(
      map((result) => result.matches),
      shareReplay()
    );
  ngOnInit(): void { }

  createForm() {
    this.supportForm = this.fb.group({
      calculatePer: new FormControl(),
      empFormula:new FormControl(),

    })
  }
  createForms(){
    this.molesForm = this.fb.group({
      volume :new FormControl(),
      massGiven:new FormControl(),
      moleculesGiven:new FormControl(),
      chemicalCompund:new FormControl(),
    })
  }
  submitSupportForm() {
    this.roleService.getpostManUrl().subscribe((res:any)=>{
      console.log(res)
    })
    let inputFormula = this.supportForm.value.calculatePer;
    let elementsInFormula = inputFormula.match(/[A-Z][a-z]?[0-9]*/g) || []; // Allow for numbers after the element symbols
    this.matchingElements = [];
    elementsInFormula.forEach(inputElement => {
      let matches = inputElement.match(/[A-Za-z]+|[0-9]+/g);
      let elementSymbol = matches[0];
      let elementCount = matches.length > 1 ? parseInt(matches[1]) : 1;

      let matchingElement = this.perodicTable.find(element => element.name.startsWith(elementSymbol));
      if (matchingElement) {
        this.matchingElements.push({ ...matchingElement, count: elementCount });
      }
    });

    if (this.matchingElements.length > 0) {
      console.log('Elements found:');
      this.matchingElements.forEach(element => {
        console.log(`${element.name} - Atomic Mass: ${element.AtomicMass} - Count: ${element.count}`);
      });

      // Calculate percentage composition
      let totalAtomicMass = this.matchingElements.reduce((total, element) => total + (element.AtomicMass * element.count), 0);
      this.atomicMass = totalAtomicMass.toFixed(4);
      console.log(`Total Atomic Mass: ${this.atomicMass}`);

      console.log('Percentage Composition:');
      this.matchingElements.forEach(element => {
        let percentage = ((element.AtomicMass * element.count) / totalAtomicMass) * 100;
        console.log(`${element.name} - Percentage: ${percentage.toFixed(2)}%`);
      });
    } else {
      console.log(`No elements found in the periodic table for the given formula: ${inputFormula}`);
    }
  }

  submitEmpForm() {
    const molecularFormula = this.supportForm.get('empFormula').value;
    const empiricalFormula = this.convertToEmpirical(molecularFormula);
    this.supportForm.get('empFormula').setValue(empiricalFormula);
  }

 submitMolesForm() {
    const volume = this.molesForm.get('volume').value;
    const avagadroNumber = 6.022*10^23;
    const moleculesGivenInput = this.molesForm.get('moleculesGiven').value;
    const moleculesGiven = parseFloat(moleculesGivenInput);
    const avogadroNumber = 6.022e23;

    console.log('moleculesGivenInput:', moleculesGivenInput);
    console.log('moleculesGiven:', moleculesGiven);

    const moles = moleculesGiven / avogadroNumber;

    console.log('Number of moles:', moles);

    

    const constantValue = 22.4;
    const numberOfMoles = volume / constantValue;
    const massGiven = this.molesForm.get('massGiven').value;

    console.log('Number of moles:', numberOfMoles);
    let inputFormula = this.molesForm.value.chemicalCompund;
    let elementsInFormula = inputFormula.match(/[A-Z][a-z]?[0-9]*/g) || []; // Allow for numbers after the element symbols
    this.matchingElements = [];
    elementsInFormula.forEach(inputElement => {
      let matches = inputElement.match(/[A-Za-z]+|[0-9]+/g);
      let elementSymbol = matches[0];
      let elementCount = matches.length > 1 ? parseInt(matches[1]) : 1;
      let matchingElement = this.perodicTable.find(element => element.name.startsWith(elementSymbol));
      if (matchingElement) {
        this.matchingElements.push({ ...matchingElement, count: elementCount });
      }
    });

    if (this.matchingElements.length > 0) {
      console.log('Elements found:');
      this.matchingElements.forEach(element => {
        console.log(`${element.name} - Atomic Mass: ${element.AtomicMass} - Count: ${element.count}`);
      });

      // Calculate percentage composition
      let totalAtomicMass = this.matchingElements.reduce((total, element) => total + (element.AtomicMass * element.count), 0);
      this.atomicMass = totalAtomicMass.toFixed(4);
      console.log(`Total Atomic Mass: ${this.atomicMass}`);

      console.log('Percentage Composition:');
      this.matchingElements.forEach(element => {
        let percentage = ((element.AtomicMass * element.count) / totalAtomicMass) * 100;
        console.log(`${element.name} - Percentage: ${percentage.toFixed(2)}%`);
      });
    } else {
      console.log(`No elements found in the periodic table for the given formula: ${inputFormula}`);
    }

    const totalAotoMicMass = massGiven / this.atomicMass ;
    console.log('totalAotoMicMass',totalAotoMicMass)
   console.log('API',this.apiURL)
}



  reset(){
    this.molesForm.reset();
  }

  convertToEmpirical(molecularFormula: string): string {
    // Implement your conversion logic here
    // This is a very basic example and may not cover all cases

    // Split the formula into individual elements and their counts
    const elements = molecularFormula.match(/[A-Z][a-z]*\d*/g) || [];

    // Calculate the greatest common divisor (GCD) of the counts
    const gcd = this.calculateGCD(elements.map((element) => this.getElementCount(element)));

    // Divide each count by the GCD to get the empirical formula
    const empiricalElements = elements.map((element) =>
      this.divideElementCount(element, gcd)
    );

    // Join the elements to form the empirical formula
    return empiricalElements.join('');
  }

  private getElementCount(element: string): number {
    const countMatch = element.match(/\d+/);
    return countMatch ? parseInt(countMatch[0], 10) : 1;
  }

  private calculateGCD(numbers: number[]): number {
    return numbers.reduce((a, b) => this.gcd(a, b), numbers[0]);
  }

  private gcd(a: number, b: number): number {
    return b === 0 ? a : this.gcd(b, a % b);
  }

  private divideElementCount(element: string, divisor: number): string {
    const count = this.getElementCount(element);
    return count > 1 ? element.replace(/\d+/, (num) => (parseInt(num, 10) / divisor).toString()) : element;
  }
  
  manageHospital() {
    this.authService.encryptKey('isManageProfile', 0);
    this.router.navigate(['pages/admin/hospital/edit-hospital']);
  }

  manageForms() {
    this.router.navigate(['pages/admin/manage-forms']);
  }


  support(templateRef: TemplateRef<any>) {
    this.dialog.open(templateRef, {
      width: "100%",
      height: "100%",
      disableClose: true

    })
    this.supportForm.reset();
  }
  composition(templateRef: TemplateRef<any>) {
    this.dialog.open(templateRef, {
      width: "100%",
      height: "100%",
      disableClose: true

    })
    this.supportForm.reset();

  }

  electrnicConfi(templateRef: TemplateRef<any>) {
    this.dialog.open(templateRef, {
      width: "100%",
      height: "100%",
      disableClose: true

    })
    this.supportForm.reset();

  }
  molecularFormula(templateRef: TemplateRef<any>) {
    this.dialog.open(templateRef, {
      width: "100%",
      height: "100%",
      disableClose: true

    })
    this.supportForm.reset();

  }
  mole(templateRef: TemplateRef<any>) {
    this.dialog.open(templateRef, {
      width: "100%",
      height: "100%",
      disableClose: true

    })
    this.supportForm.reset();

  }
  onLogout() {
    localStorage.clear();
    this.authService.logout();
    this.router.navigate(['/']);
  }
  getProfile() {
    this.router.navigate(['/pages/profile/']);
  }

  setHeader() {
    let path = this.router.url.split('/')[2];
    switch (
    decodeURIComponent(path)
    // case PageTitle.dashboard: {
    //   this.title = 'Dashboard';
    //   break;
    // }
    // case PageTitle.user: {
    //   this.title = 'Manage User';
    //   break;
    // }
    // case PageTitle.subscription: {
    //   this.title = 'Subscription Plan';
    //   break;
    // }
    // case PageTitle.supplier: {
    //   this.title = 'Supplier List';
    //   break;
    // }

    // case PageTitle.customer: {
    //   this.title = 'Customer List';
    //   break;
    // }
    // case PageTitle.tickets: {
    //   this.title = 'Support Ticket List';
    //   break;
    // }
    // case PageTitle.terms: {
    //   this.title = 'Terms & Conditions';
    //   break;
    // }
    // case PageTitle.profile: {
    //   this.title = 'Profile';
    //   break;
    // }
    // case PageTitle.rental: {
    //   this.title = 'Rental Management';
    //   break;
    // }
    // case PageTitle.linkbusiness: {
    //   this.title = 'Manage Linked Business';
    //   break;
    // }
    ) {
    }
  }
}
